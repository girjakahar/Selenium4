package crosssellingproduct;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.MetalBedFrame;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class MetalBedCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(MetalBedCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	    @Test
		public void crossSellingMetalBed() throws Exception
		{
	    	
	    	driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      log.info("Website opened Successfully");
		      
	     wait = new WebDriverWait(driver, 10);		    	   
	     //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	     ProductDetails productdetail = new ProductDetails(driver);
		 wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		 //Thread.sleep(3000);
		 productdetail.closeoffer();
	     log.info("Closing the offer modal");
  	      
		  Header websiteHeader = new Header(driver);    	     
	      websiteHeader.metalBedFrameProduct();
		  log.info("Metal Bed product detail page is opened");
		  
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		  	   
    	   MetalBedFrame metalBedFrameproduct = new MetalBedFrame(driver);		   
		   productdetail.scrollToDefaultAddToCart();
		   log.info("Scroll to add to cart button");
		   
		   metalBedFrameproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   Thread.sleep(1000);
		   CartSlider cart = new CartSlider(driver);	   
		   cart.closecartSlider().click();
		   log.info("Clicked on cross icon of cart slider and close the cart Slider");
		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		   Actions move =new Actions(driver);
		   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section");
		   
			/*
			 * productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
		   //productdetail.CrossSellOriginalMattressCategoryField().click();
		   log.info("Clicked on category field for Original mattress");
		   
		   move.moveToElement(productdetail.crossSellOriginalMattressKingCategory()).click().build().perform();
		   log.info("Scrolled down to King category and click on that category");
	   
		   productdetail.crossSellOriginalMattressSizeField().click();
		   log.info("Clicked on Size field");
		   
		   productdetail.crossSellOriginalMattressKing75x72x6().click();
		   log.info("Clicked on one Size option from the dropdown field");
		   
			/*
			 * productdetail.crossSellAddToCartOriginalMattressKing75x72x6().click();
			 * log.info("Clicked on Add to cart button of Original mattress product");
			 * 
			 * productdetail.crossSellSingleComforter().click();
			 * log.info("Clicked on Add to cart button of cross sell comforter product");
			 * 
			 * productdetail.crossSellNextproduct().click();
			 * log.info("Click on next product icon in cross selling product section");
			 * 
			 * productdetail.crossCloudPillow().click();
			 * log.info("Clicked on Add to cart button of cross sell Cloud pillow product");
			 * 
			 * Thread.sleep(1000); productdetail.crossSellNextproduct().click();
			 * log.info("Click on next product icon in cross selling product section");
			 */
		   
		   //productdetail.crossSellAddtocartSingleProtector72x36().click();
		   log.info("Clicked on Add to cart button of cross sell Single category Protector product");
	
           Thread.sleep(1000);
		   websiteHeader.cartIcon().click();
		   log.info("Click on cart icon");
		   
           //Thread.sleep(1000);
		   wait.until(ExpectedConditions.visibilityOf(cart.originalMattressKingCategory75x72x6ProductAddedInCart()));
		   boolean productname = cart.originalMattressKingCategory75x72x6ProductAddedInCart().isDisplayed();
		   
			if(productname) 
			{
				log.info("Single category Ohayo Bed Product and cross selling products is added in cart");
			}else
			{
				log.info("Single category Ohayo Bed Product and cross selling products is added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
