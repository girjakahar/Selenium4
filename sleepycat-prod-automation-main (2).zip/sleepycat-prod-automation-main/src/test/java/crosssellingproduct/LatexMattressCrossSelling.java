package crosssellingproduct;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.LatexMattress;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class LatexMattressCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(LatexMattressCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	    @Test
		public void crossSellingLatexMattress() throws Exception
		{
	    	
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
	      //wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	      
		    //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
		      
	      //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	      //Thread.sleep(3000);
		  productdetail.closeoffer();
		  log.info("Closing the offer modal");
  	   
		  Header websiteHeader = new Header(driver);  	   
		  websiteHeader.mattHeader();
		   log.info("Clicked on Mattress header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteHeader.hybridLatexMattressMenu()));
		   websiteHeader.hybridLatexMattressMenu().click();
		   log.info("Clicked on Latex Mattress menu option");
		   
		   productdetail.queenCategory().click();
		   log.info("Clicked on Queen category option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
		   //productdetail.sizeDropdown().click();
		   log.info("Clicked on sizedropdown field");
		   
		   LatexMattress latexmattressproduct = new LatexMattress(driver);
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", latexmattressproduct.queenLatex78x60x6());
		   //latexmattressproduct.singleLatex72x36x6().click();
		   log.info("Clicked on one size option from the dropdown");
		  	   
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");
    	   CartSlider cart = new CartSlider(driver);
 	       wait.until(ExpectedConditions.visibilityOf(productdetail.singleCategory()));
		   Actions move =new Actions(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section before it is loaded");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellGreyColorProtector()));
		   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section after it is loaded");
		   
		   productdetail.crossSellChangeMultipleOptionWhiteProtectorAddToCartButton();
		   
		   /*wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellGreyColorProtector()));
		   productdetail.crossSellGreyColorProtector().click();
		   log.info("Clicked on cross Sell Gray color option in Protector");
		   
           Thread.sleep(1000);
		   productdetail.crossSellProtectorCategoryField().click();
		   log.info("Clicked on category field for Protector");
		   
	  	   productdetail.crossSellQueenCategoryProtector().click();
		   log.info("Clicked on cross Sell Queen Category option in Protector");
	
		   productdetail.crossSellProtectorSizeField().click();
		   log.info("Clicked on cross Sell Protector Size Field");
	  	   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellQueenProtector78x60()));
		   productdetail.crossSellQueenProtector78x60().click();
		   log.info("Click on one size option from dropdown");
		   
		   productdetail.crossSellAddToCartQueenProtector78x60().click();
		   log.info("Click on add to cart product button of Protector");
		   
           Thread.sleep(1000);
		   productdetail.crossSellFittedBedSheetCategoryField().click();
		   log.info("Clicked on cross Sell Fitted Bed Sheet Category field");
		   
           Thread.sleep(1000);
		   productdetail.crossSellFittedBedSheetKingCategoryField().click();
		   log.info("Clicked on King Category for Fitted Bed Sheet");
		   
	  	   productdetail.crossSellFittedBedSheetCategoryField().click();
		   log.info("Again Clicked on cross Sell Fitted Bed Sheet Category field");
	
		   productdetail.crossSellFittedBedSheetQueenCategoryField().click();
		   log.info("Clicked on Queen Category for Fitted Bed Sheet");
	  	   
		   productdetail.crossSellFittedBedSheetDolphinGrayColor().click();
		   log.info("Click on Dolphin Gray Color for fitted Bed sheet product");
		   
		   productdetail.crossSellFittedBedSheetTwilightBlueColor().click();
		   log.info("Click on Twilight Blue Color for fitted Bed sheet product");
		   
		   productdetail.crossSellFittedBedSheetButterScoutchCreamColor().click();
		   log.info("Click on ButterScoutch Cream Color for fitted Bed sheet product");
		   
		   Thread.sleep(2000);
		   productdetail.crossSellAddToCartButtonForQueenFittedBedSheetButterScoutchCream().click();
		   log.info("Click on add to cart product button of Queen FittedBed sheet product");*/
		   
		   productdetail.crossSellChangeMultipleOptionFittedBedSheetAddToCartButton();
		   
		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-80)", "");
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   productdetail.crossSellCloudPillowChangeMultipleOptionAddToCartButton();
	  	   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellCloudPillowCategoryField()));
			 * productdetail.crossSellCloudPillowCategoryField().click();
			 * log.info("Clicked on category field for cloud pillow");
			 * 
			 * productdetail.crossSellPresidentCategoryCloudPillow().click();
			 * log.info("Clicked on President type option from the dropdown");
			 * 
			 * productdetail.crossSellPackFieldOfCloudPillow().click();
			 * log.info("Clicked on Pack field for cloud pillow");
			 * 
			 * productdetail.crossSellPackFourOfCloudPillow().click();
			 * log.info("Clicked on Pack of 4 option from dropdown");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to two");
			 * 
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to Three");
			 * 
			 * productdetail.crossSellCloudPillowDecreaseQuantity().click();
			 * log.info("Decrement quantity to two");
			 * 
			 * productdetail.crossSellAddtocartPresidentCloudPillowSet4().click();
			 * log.info("Clicked on add to cart button of Cloud pillow");
			 */
		   
           Thread.sleep(2000);
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellComforterCategoryField()));
		   productdetail.crossSellComforterChangeMultipleOptionAddToCartButton();
		   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   productdetail.closeoffer();
	       log.info("Closing the offer modal");
			  
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellSoftTouchMemoryPillowCategoryField()));
		   productdetail.crossSellSoftTouchMemoryPillowChangeMultipleOptionAddToCartButton();

		   Thread.sleep(1000);
		   websiteHeader.cartIcon().click();
		   log.info("Click on cart icon");
		   
		   //Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.butterScoutchCreamColorQueenFittedBedSheetProductAddedInCart()));
		   boolean productname = cart.butterScoutchCreamColorQueenFittedBedSheetProductAddedInCart().isDisplayed();
		   
		   if(productname) 
			{
				log.info("King category latex Mattress and cross sell products are added in cart");
			}else
			{
				log.info("King category latex Mattress and cross sell products are not added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
