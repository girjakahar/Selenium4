package crosssellingproduct;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class PillowCasesCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(PillowCasesCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	   @Test
		public void crossSellingPillowCases() throws Exception
		{
		   
		 //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
		   //wait = new WebDriverWait(driver, 10);		    	   
		   //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		      
		    //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
			   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
    	  
		  Header websiteHeader = new Header(driver); 
		  websiteHeader.beddingHeader();
		   log.info("Clicked on Bedding header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteHeader.pillowCaseMenu()));
		   websiteHeader.pillowCaseMenu().click();
		   log.info("Clicked on pillowCase Menu option");
		   
		   //productdetail.defaultAddToCart();
		   //log.info("Scroll to default add to cart");
		   
		  	   
		   CartSlider cart = new CartSlider(driver);	   		 
		   Actions move =new Actions(driver);
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section before it is loaded");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.CrossSellLuxeComforterCategoryField()));
		   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section after it is loaded");
		   
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");
		   
		   productdetail.crossSellChangeMultipleOptionLuxeComforterAddToCartButton();
		   
			/*
			 * productdetail.CrossSellLuxeComforterCategoryField().click();
			 * log.info("Clicked on category field for Luxe Comforter");
			 * 
			 * productdetail.crossSellLuxeComforterDoubleCategoryField().click();
			 * log.info("Clicked on Double category for Luxe Comforter");
			 * 
			 * productdetail.CrossSellLuxeComforterCategoryField().click();
			 * log.info("Clicked again on category field for Luxe Comforter");
			 * 
			 * productdetail.crossSellLuxeComforterSingleCategoryField().click();
			 * log.info("Clicked on Single category for Luxe Comforter");
			 * 
			 * productdetail.crossSellAddToCartButtonForSingleLuxeComforter().click();
			 * log.info("Click on add to cart product button of Single Luxe comforter");
			 * 
			 * Thread.sleep(2000);
			 * move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform
			 * ();
			 * productdetail.crossSellAddToCartButtonForSingleWhiteColorComforter().click();
			 * log.info("Click on add to cart product button of Comforter");
			 */
		   
		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");
			productdetail.crossSellDefaultWhiteColorAddToCartButtonforComforter();
		   //productdetail.crossSellDefaultAddToCartButtonforComforter();
		   
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellCloudPillowCategoryField()));
		   productdetail.crossSellCloudPillowChangeMultipleOptionAddToCartButton();
		   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellCloudPillowCategoryField()));
			 * productdetail.crossSellCloudPillowCategoryField().click();
			 * log.info("Clicked on category field of cloud pillow");
			 * 
			 * productdetail.crossSellPresidentCategoryCloudPillow().click();
			 * log.info("Clicked on President category of cloud pillow");
			 * 
			 * Thread.sleep(2000); productdetail.crossSellPackFieldOfCloudPillow().click();
			 * log.info("Clicked on pack field of cloud pillow");
			 * 
			 * productdetail.crossSellPackFourOfCloudPillow().click();
			 * log.info("Clicked on Pack of 4 option from dropdown");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to two");
			 * 
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to Three");
			 * 
			 * productdetail.crossSellCloudPillowDecreaseQuantity().click();
			 * log.info("Decrement quantity to two");
			 * 
			 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddtocartPresidentCloudPillowSet4());
			 * //productdetail.crossSellAddtocartPresidentCloudPillowSet4().click();
			 * log.info("Clicked on add to cart button of Cloud pillow");
			 */
		   
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellAddToCartButtonForCuddlePillow()));
		   productdetail.crossSellDefaultAddToCartButtonforCuddlepillow();
		   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellAddToCartButtonForCuddlePillow()));
			 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddToCartButtonForCuddlePillow());
			 * //productdetail.crossSellAddToCartButtonForCuddlePillow().click();
			 * log.info("Click on Add to cart button for cuddle pillow");
			 */
		   
           Thread.sleep(1000);
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellSoftTouchMemoryPillowCategoryField()));
		   productdetail.crossSellSoftTouchMemoryPillowChangeMultipleOptionAddToCartButton();
		
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellSoftTouchMemoryPillowCategoryField()));
			 * productdetail.crossSellSoftTouchMemoryPillowCategoryField().click();
			 * log.info("Clicked on category field for Memory pillow");
			 * 
			 * productdetail.crossSellSoftTouchMemoryPillowPresidentCategory().click();
			 * log.info("Clicked on President type option from the dropdown");
			 * 
			 * productdetail.crossSellSoftTouchMemoryPillowPackField().click();
			 * log.info("Clicked on Pack field for Memory pillow");
			 * 
			 * productdetail.crossSellSoftTouchMemoryPillowPackOfTwo().click();
			 * log.info("Clicked on Pack of 2 option from dropdown");
			 * 
			 * productdetail.crossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo().click
			 * (); log.info("Clicked on Add to cart button of Memory pillow");
			 */

		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteHeader.cartIcon());
		   //websiteHeader.cartIcon().click();
		   log.info("Click on cart icon");
		   
           //Thread.sleep(1000);
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryCuddlePillowProductAddedInCart()));
		   boolean productname = cart.standardCategoryCuddlePillowProductAddedInCart().isDisplayed();
		   
			
			if(productname) 
			{
				log.info("Luxe Comforter,Reversible Comforter ,Cloud pillow,Cuddle pillow and SoftTouch Memory Foam pillow cross sell products are added in cart");
			}else
			{
				log.info("Luxe Comforter,Reversible Comforter ,Cloud pillow,Cuddle pillow and SoftTouch Memory Foam pillow cross sell products are not added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
