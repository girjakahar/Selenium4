package crosssellingproduct;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class BabyCribSheetCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(BabyCribSheetCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	   @Test
		public void crossSellingBabyCribSheet() throws Exception
		{
		   
		 //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
		   //wait = new WebDriverWait(driver, 10);		    	   
		   //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		      
		      //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
			   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
    	  
		  Header websiteHeader = new Header(driver); 
		  websiteHeader.babyHeader();
	 	   log.info("Click on baby menu in header");
	 	   
	 	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.babyCribSheetMenu()));
	 	  websiteHeader.babyCribSheetMenu().click();;
		   log.info("Clicked on Baby CribSheet menu option ");
		  	   
		   CartSlider cart = new CartSlider(driver);
		   
		   Actions move =new Actions(driver);
		   ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section before it is loaded");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellBabyHeadPillowIncrementQuantity()));
		   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section after it is loaded");
		   
		   productdetail.crossSellDefaultBabyHeadPillowAddToCartButton();
			
			/*
			 * ((JavascriptExecutor) driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddToCartButtonForBabyHeadPillow());
			 * log.info("Clicked on cross Sell Add to cart button for Baby Head Pillow");
			 */
		   
		   Thread.sleep(3000);
		   productdetail.crossSellDefaultBabyBolsterPillowAddToCartButton();

			/*
			 * ((JavascriptExecutor) driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddToCartButtonForBabyBolsterPillow());
			 * log.info("Clicked on cross Sell Add to cart button for Baby Bolster pillow");
			 */	   
	  	   
		   ((JavascriptExecutor) driver).executeScript("arguments[0].click();", productdetail.crossSellNextproduct());
		   //productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
	  	  ((JavascriptExecutor) driver).executeScript("arguments[0].click();", productdetail.crossSellBabyComforterIncrementQuantity());
		   log.info("Clicked on plus icon and increment the Baby Comforter quantity to Two");
		   
		   ((JavascriptExecutor) driver).executeScript("arguments[0].click();", productdetail.crossSellBabyComforterIncrementQuantity());
		   log.info("Clicked on plus icon and increment the Baby Comforter quantity to Three");
		   
		   ((JavascriptExecutor) driver).executeScript("arguments[0].click();", productdetail.crossSellBabyComforterDecreaseQuantity());
		   log.info("Clicked on minus icon and decrement the Baby Comforter quantity to Two");
		   
		   productdetail.crossSellDefaultBabyComforterAddToCartButton();
		   
			/*
			 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddToCartButtonForBabyComforter());
			 * log.info("Clicked on cross Sell Add to cart button for Baby Comforter");
			 */

		   Thread.sleep(1000);
		   //header.cartIcon().click();
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteHeader.cartIcon());
		   log.info("Click on cart icon");
			   
	           Thread.sleep(2000);
			   boolean productname = cart.standardCategoryBabyHeadPillowProductAddedInCart().isDisplayed();
			   
				
				if(productname) 
				{
					log.info("Baby Head Pillow ,Bolster pillow and Comforter cross sell products are added in cart");
				}else
				{
					log.info("Baby Head Pillow ,Bolster pillow and Comforter cross sell products are not added in cart");
				}	
			}

}
