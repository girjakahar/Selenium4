package crosssellingproduct;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class SoftTouchMemoryFoamPillowCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(SoftTouchMemoryFoamPillowCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	   @Test
		public void crossSellingMemoryFoamPillow() throws Exception
		{
		   
		 //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
		   //wait = new WebDriverWait(driver, 10);		    	   
		   //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		   
		    //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
			   
		      
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
    	  
		  Header websiteHeader = new Header(driver); 
		  websiteHeader.pillowHeader();
		   log.info("Clicked on Pillow header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteHeader.softTouchMemoryFoamMenu()));
		   websiteHeader.softTouchMemoryFoamMenu().click();
		   log.info("Clicked on softTouchMemoryFoam Menu option");
		  	   
		   CartSlider cart = new CartSlider(driver);	   		 
		   Actions move =new Actions(driver);
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section before it is loaded");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellPillowCaseTypeField()));
		   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section after it is loaded");

		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");	   
			productdetail.crossSellChangeMultipleOptionPillowCaseAddToCartButton();

			/*
			 * productdetail.crossSellPillowCaseTypeField().click();
			 * log.info("Clicked on Type field for pillow Cases");
			 * 
			 * productdetail.crossSellPresidentPillowCases().click();
			 * log.info("Clicked on President pillow cases type from drodown");
			 * 
			 * productdetail.crossSellPillowCaseTypeField().click();
			 * log.info("Clicked on Type field for pillow Cases");
			 * 
			 * productdetail.crossSellStandardPillowCases().click();
			 * log.info("Clicked on Standard pillow cases type from drodown");
			 * 
			 * productdetail.crossSellPillowCaseTypeField().click();
			 * log.info("Clicked on Type field for pillow Cases");
			 * 
			 * productdetail.crossSellCuddleTypePillowCases().click();
			 * log.info("Clicked on Cuddle pillow cases type from drodown");
			 * 
			 * productdetail.crossSellDolPhinGrayCuddlePillowcaseColor().click();
			 * log.info("Clicked on Dolphin Gray Cuddle pillow cases color option");
			 */
			 
   
			/*
			 * productdetail.crossSellPillowCasesPackField().click();
			 * log.info("Clicked on Pack field for pillow cases");
			 * 
			 * productdetail.crossSellPillowCasePackOfFour().click();
			 * log.info("Clicked on Pack of Four option from dropdown");
			 * 
			 * productdetail.crossSellPillowCasesPackField().click();
			 * log.info("Clicked on Pack field for pillow cases");
			 * 
			 * productdetail.crossSellPillowCasePackOfOne().click();
			 * log.info("Clicked on Pack of one option from dropdown");
			 * 
			 * productdetail.crossSellPillowCasesPackField().click();
			 * log.info("Clicked on Pack field for pillow cases");
			 * 
			 * productdetail.crossSellPillowCasePackOfTwo().click();
			 * log.info("Clicked on Pack of Two option from dropdown");
			 */   	   		   
		   
			Thread.sleep(2000);
			((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
			wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellAddToCartButtonForSingleWhiteColorComforter()));
			//productdetail.crossSellDefaultAddToCartButtonforComforter();
			productdetail.crossSellDefaultWhiteColorAddToCartButtonforComforter();

			/*
			 * //productdetail.crossSellAddToCartMemoryPillowTypePillowcasePackOfFour().
			 * click(); ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo
			 * ());
			 * log.info("Clicked on add to cart button of Cuddle pillow Cases Pack of One");
			 */
		   
		   Thread.sleep(3000);
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellAddToCartButtonForCuddlePillow()));
			productdetail.crossSellDefaultAddToCartButtonforCuddlepillow();
		   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellAddToCartButtonForSingleWhiteColorComforter()));
			 * productdetail.crossSellAddToCartButtonForSingleWhiteColorComforter().click();
			 * log.info("Click on add to cart product button of comforter");
			 * 
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellAddToCartButtonForCuddlePillow()));
			 * productdetail.crossSellAddToCartButtonForCuddlePillow().click();
			 * log.info("Click on add to cart product button of cuddle pillow");
			 * 
			 * //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()
			 * )); productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   Thread.sleep(1000);
		    productdetail.crossSellDefaultGrayProtectorAddToCartButton();
		    //productdetail.crossSellDefaultWhiteProtectorAddToCartButton();
		   
			/*
			 * productdetail.crossSellAddtocartSingleWhiteProtector72x36().click();
			 * //productdetail.crossSellAddtocartSingleProtector72x36().click();
			 * log.info("Clicked on add to cart product of Protector");
			 */

		   websiteHeader.cartIcon().click();
		   log.info("Click on cart icon");
		   
           //Thread.sleep(1000);
		   wait.until(ExpectedConditions.visibilityOf(cart.dolPhinGrayColorCuddlePillowCasePackofOneProductAddedInCart()));
		   boolean productname = cart.dolPhinGrayColorCuddlePillowCasePackofOneProductAddedInCart().isDisplayed();
		   
			
			if(productname) 
			{
				log.info("Pillow case,Comforter,Cuddle and Protector cross sell products are added in cart");
			}else
			{
				log.info("Pillow case,Comforter,Cuddle and Protector cross sell products are added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
