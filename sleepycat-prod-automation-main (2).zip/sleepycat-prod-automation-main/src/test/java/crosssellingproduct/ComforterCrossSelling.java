package crosssellingproduct;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class ComforterCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(ComforterCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	   @Test
		public void crossSellingComforter() throws Exception
		{
		   
		 //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
		   //wait = new WebDriverWait(driver, 10);		    	   
		   //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		      
		    //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
			   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
    	  
		  Header websiteHeader = new Header(driver); 
		  websiteHeader.beddingHeader();
		  log.info("Clicked on bedding header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteHeader.comforterMenu()));
		   websiteHeader.comforterMenu().click();
		   log.info("Clicked on comforter menu option");
		  	   
		   CartSlider cart = new CartSlider(driver);	   		 
		   Actions move =new Actions(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section before it is loaded");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellDuvetCoverDolphinGrayColor()));
		   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section after it is loaded");
		   
		   productdetail.crossSellChangeMultipleOptionCouplePillowAddToCartButton();
		   
			/*
			 * productdetail.crossSellDuvetCoverTwilightBlueColor().click();
			 * log.info("Click on Twilight Blue Color for Duvet Cover product");
			 * 
			 * productdetail.crossSellDuvetCoverButterScoutchCreamColor().click();
			 * log.info("Click on ButterScoutch Cream Color for Duvet Cover product");
			 * 
			 * productdetail.crossSellDuvetCoverDolphinGrayColor().click();
			 * log.info("Click on Dolphin Gray Color for Duvet Cover product");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellDuvetCoverIncrementQuantity().click();
			 * log.info("Increment quantity to two");
			 * 
			 * productdetail.crossSellDuvetCoverIncrementQuantity().click();
			 * log.info("Increment quantity to Three");
			 * 
			 * productdetail.crossSellDuvetCoverDecreaseQuantity().click();
			 * log.info("Decrement quantity to two");
			 * 
			 * productdetail.crossSellAddToCartButtonForDoubleDolphinGrayDuvetCover().click(
			 * ); log.info("Clicked on add to cart button of Duvet Cover");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellFittedBedSheetCategoryField().click();
			 * log.info("Clicked on cross Sell Fitted Bed Sheet Category field");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellFittedBedSheetKingCategoryField().click();
			 * log.info("Clicked on King Category for Fitted Bed Sheet");
			 * 
			 * productdetail.crossSellFittedBedSheetCategoryField().click();
			 * log.info("Again Clicked on cross Sell Fitted Bed Sheet Category field");
			 * 
			 * productdetail.crossSellFittedBedSheetQueenCategoryField().click();
			 * log.info("Clicked on Queen Category for Fitted Bed Sheet");
			 * 
			 * productdetail.crossSellFittedBedSheetDolphinGrayColor().click();
			 * log.info("Click on Dolphin Gray Color for fitted Bed sheet product");
			 * 
			 * productdetail.crossSellFittedBedSheetTwilightBlueColor().click();
			 * log.info("Click on Twilight Blue Color for fitted Bed sheet product");
			 * 
			 * productdetail.crossSellFittedBedSheetButterScoutchCreamColor().click();
			 * log.info("Click on ButterScoutch Cream Color for fitted Bed sheet product");
			 * 
			 * Thread.sleep(2000); productdetail.
			 * crossSellAddToCartButtonForQueenFittedBedSheetButterScoutchCream().click();
			 * log.
			 * info("Click on add to cart product button of Queen FittedBed sheet product");
			 */
		   
			Thread.sleep(2000);
			((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-80)", "");
		    productdetail.crossSellChangeMultipleOptionDuvetCoverAddToCartButton();
			
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
			productdetail.crossSellChangeMultipleOptionFittedBedSheetAddToCartButton();
			
			productdetail.crossSellNextproduct().click();
			log.info("Click on next product icon in cross selling product section");
		   
			productdetail.crossSellChangeMultipleOptionPillowCaseAddToCartButton();
		   
			/*
			 * productdetail.crossSellPillowCaseTypeField().click();
			 * log.info("Clicked on Type field for pillow Cases");
			 * 
			 * productdetail.crossSellPresidentPillowCases().click();
			 * log.info("Clicked on President pillow cases type from drodown");
			 * 
			 * productdetail.crossSellPillowCaseTypeField().click();
			 * log.info("Clicked on Type field for pillow Cases");
			 * 
			 * productdetail.crossSellStandardPillowCases().click();
			 * log.info("Clicked on Standard pillow cases type from drodown");
			 * 
			 * productdetail.crossSellPillowCaseTypeField().click();
			 * log.info("Clicked on Type field for pillow Cases");
			 * 
			 * productdetail.crossSellCuddleTypePillowCases().click();
			 * log.info("Clicked on Cuddle pillow cases type from drodown");
			 */
			 		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
			/*
			 * productdetail.crossSellPillowCasesPackField().click();
			 * log.info("Clicked on Pack field for pillow cases");
			 * 
			 * productdetail.crossSellPillowCasePackOfFour().click();
			 * log.info("Clicked on Pack of Four option from dropdown");
			 * 
			 * productdetail.crossSellPillowCasesPackField().click();
			 * log.info("Clicked on Pack field for pillow cases");
			 * 
			 * productdetail.crossSellPillowCasePackOfOne().click();
			 * log.info("Clicked on Pack of one option from dropdown");
			 * 
			 * productdetail.crossSellPillowCasesPackField().click();
			 * log.info("Clicked on Pack field for pillow cases");
			 * 
			 * productdetail.crossSellPillowCasePackOfTwo().click();
			 * log.info("Clicked on Pack of Two option from dropdown");
			 */   	   		   
		      
			/*
			 * Thread.sleep(1000);
			 * productdetail.crossSellTwilightBlueCuddlePillowcaseColor().click();
			 * log.info("Clicked on Twilight blue color for pillow Cases");
			 * 
			 * productdetail.crossSellButterscoutchCreamCuddlePillowcaseColor().click();
			 * log.info("Clicked on Butterscoutch Cream color for pillow Cases");
			 * 
			 * productdetail.crossSellDolPhinGrayCuddlePillowcaseColor().click();
			 * log.info("Clicked on Dolphin Gray color for pillow Cases");
			 * 
			 * //productdetail.crossSellAddToCartMemoryPillowTypePillowcasePackOfFour().
			 * click(); ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.crossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo
			 * ());
			 * log.info("Clicked on add to cart button of Cuddle pillow Cases Pack of Two");
			 */
		   
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
			productdetail.crossSellCloudPillowCategoryField();
		   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellCloudPillowCategoryField()));
			 * productdetail.crossSellCloudPillowCategoryField().click();
			 * log.info("Clicked on category field for cloud pillow");
			 * 
			 * productdetail.crossSellPresidentCategoryCloudPillow().click();
			 * log.info("Clicked on President type option from the dropdown");
			 */
		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
			/*
			 * productdetail.crossSellPackFieldOfCloudPillow().click();
			 * log.info("Clicked on Pack field for cloud pillow");
			 * 
			 * productdetail.crossSellPackFourOfCloudPillow().click();
			 * log.info("Clicked on Pack of 4 option from dropdown");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to two");
			 * 
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to Three");
			 * 
			 * productdetail.crossSellCloudPillowDecreaseQuantity().click();
			 * log.info("Decrement quantity to two");
			 * 
			 * productdetail.crossSellAddtocartPresidentCloudPillowSet4().click();
			 * log.info("Clicked on add to cart button of Cloud pillow");
			 */
		   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");

           Thread.sleep(1000);
		   websiteHeader.cartIcon().click();
		   log.info("Click on cart icon");
		   
           Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.dolPhinGrayColorDoubleDuvetCoverProductAddedInCart()));
		   boolean productname = cart.dolPhinGrayColorDoubleDuvetCoverProductAddedInCart().isDisplayed();
		   
			
			if(productname) 
			{
				log.info("Couple Pillow ,Duvet cover,Fitted bed sheet,Pillow case and Cloud pillow cross sell products are added in cart");
			}else
			{
				log.info("Couple Pillow ,Duvet cover,Fitted bed sheet,Pillow case and Cloud pillow cross sell products are not added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
