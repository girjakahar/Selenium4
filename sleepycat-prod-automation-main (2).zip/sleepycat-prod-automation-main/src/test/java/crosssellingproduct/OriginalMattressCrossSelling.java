package crosssellingproduct;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
class OriginalMattressCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(OriginalMattressCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	   @Test
		public void crossSellingOriginalMattress() throws Exception
		{
		   
		 //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
		   //wait = new WebDriverWait(driver, 10);		    	   
		   //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		      
		    //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
		      
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
    	   
		   Actions move =new Actions(driver);
		  OriginalMattress originalMattressproduct = new OriginalMattress(driver);
		  Header websiteHeader = new Header(driver);  	   
		  websiteHeader.mattHeader();
		   log.info("Clicked on Mattress header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteHeader.originalMattressMenu()));
		   websiteHeader.originalMattressMenu().click();
		   log.info("Clicked on Original Mattress menu option");
		  
		  productdetail.customCategory().click();
		  log.info("Click on Custom category");
		  
		  Thread.sleep(2000);
		  productdetail.queenCategory().click();
		  log.info("Click on Queen category");
		  
		  originalMattressproduct.eightInchHeight().click();
		  log.info("Click on Eight Inch Height Option");
		  
		  ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,250)", "");	
		  log.info("Scroll to Size dropdown option");

		  productdetail.sizeDropdown().click();
		  log.info("Click on Size dropdown option");
		  
		  //move.moveToElement(originalMattressproduct.originalQueenCategory78x60x8()).click().build().perform();
		  move.moveToElement(originalMattressproduct.originalQueenCategory78x60x8()).build().perform();
		  originalMattressproduct.originalQueenCategory78x60x8().click();
		  log.info("Click on one Size option from dropdown option");
		  	   		   
	       //productdetail.scrollToDefaultAddToCart();
		   //log.info("Scroll to add to cart button");
		   
	       //originalMattressproduct.addToCart();
		   //log.info("Clicked on add to cart button");
		   
           Thread.sleep(2000);
		   CartSlider cart = new CartSlider(driver);	   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(cart.closecartSlider()));
			 * cart.closecartSlider().click();
			 * log.info("Clicked on cross icon of cart slider and close the cart Slider");
			 */
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		  // move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		   log.info("Scrolled down to cross selling product section before it is loaded");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellGreyColorProtector()));
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.crossSellProductsTitle());
		   //move.moveToElement(productdetail.crossSellGreyColorProtector()).build().perform();
		   log.info("Scrolled down to cross selling product section after it is loaded");
		   
		   //((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
		   productdetail.crossSellChangeMultipleOptionWhiteProtectorAddToCartButton();
		   
			/*
			 * productdetail.crossSellGreyColorProtector().click();
			 * log.info("Clicked on cross Sell Gray color option in Protector");
			 * 
			 * productdetail.crossSellWhiteColorProtector().click();
			 * log.info("Clicked on cross Sell White color option in Protector");
			 * 
			 * productdetail.crossSellGreyColorProtector().click();
			 * log.info("Clicked on cross Sell Gray color option in Protector");
			 * 
			 * Thread.sleep(1000); productdetail.crossSellProtectorCategoryField().click();
			 * log.info("Clicked on category field for Protector");
			 * 
			 * productdetail.crossSellQueenCategoryProtector().click();
			 * log.info("Clicked on cross Sell Queen Category option in Protector");
			 * 
			 * productdetail.crossSellProtectorSizeField().click();
			 * log.info("Clicked on cross Sell Protector Size Field");
			 * 
			 * productdetail.crossSellQueenProtector78x60().click();
			 * log.info("Click on one size option from dropdown");
			 * 
			 * productdetail.crossSellAddToCartQueenProtector78x60().click();
			 * log.info("Click on add to cart product button of Protector");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellFittedBedSheetCategoryField().click();
			 * log.info("Clicked on cross Sell Fitted Bed Sheet Category field");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellFittedBedSheetKingCategoryField().click();
			 * log.info("Clicked on King Category for Fitted Bed Sheet");
			 * 
			 * productdetail.crossSellFittedBedSheetCategoryField().click();
			 * log.info("Again Clicked on cross Sell Fitted Bed Sheet Category field");
			 * 
			 * productdetail.crossSellFittedBedSheetQueenCategoryField().click();
			 * log.info("Clicked on Queen Category for Fitted Bed Sheet");
			 * 
			 * productdetail.crossSellFittedBedSheetDolphinGrayColor().click();
			 * log.info("Click on Dolphin Gray Color for fitted Bed sheet product");
			 * 
			 * productdetail.crossSellFittedBedSheetButterScoutchCreamColor().click();
			 * log.info("Click on ButterScoutch Cream Color for fitted Bed sheet product");
			 * 
			 * productdetail.crossSellFittedBedSheetTwilightBlueColor().click();
			 * log.info("Click on Twilight Blue Color for fitted Bed sheet product");
			 * 
			 * productdetail.crossSellAddToCartButtonForQueenFittedBedSheetTwilightBlue().
			 * click(); log.
			 * info("Click on add to cart product button of Queen FittedBed sheet product");
			 */
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
		   productdetail.crossSellChangeMultipleOptionFittedBedSheetAddToCartButton();
		   
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
		   Thread.sleep(2000);
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
	  	   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellCloudPillowCategoryField()));
		   productdetail.crossSellCloudPillowChangeMultipleOptionAddToCartButton();
		   
			/*
			 * productdetail.crossSellCloudPillowCategoryField().click();
			 * log.info("Clicked on category field for cloud pillow");
			 * 
			 * productdetail.crossSellPresidentCategoryCloudPillow().click();
			 * log.info("Clicked on President type option from the dropdown");
			 * 
			 * productdetail.crossSellPackFieldOfCloudPillow().click();
			 * log.info("Clicked on Pack field for cloud pillow");
			 * 
			 * productdetail.crossSellPackFourOfCloudPillow().click();
			 * log.info("Clicked on Pack of 4 option from dropdown");
			 * 
			 * Thread.sleep(1000);
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to two");
			 * 
			 * productdetail.crossSellCloudPillowIncrementQuantity().click();
			 * log.info("Increment quantity to Three");
			 * 
			 * productdetail.crossSellCloudPillowDecreaseQuantity().click();
			 * log.info("Decrement quantity to two");
			 * 
			 * productdetail.crossSellAddtocartPresidentCloudPillowSet4().click();
			 * log.info("Clicked on add to cart button of Cloud pillow");
			 * 
			 * //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()
			 * )); productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellComforterCategoryField()));
		   productdetail.crossSellComforterChangeMultipleOptionAddToCartButton();
		   
			/*
			 * productdetail.crossSellComforterCategoryField().click();
			 * log.info("Clicked on category field for Comforter");
			 * 
			 * productdetail.crossSellDoubleCategoryComforter().click();
			 * log.info("Clicked on cross Sell Double Category Comforter option");
			 * 
			 * productdetail.crossSellComforterPinkColor().click();
			 * log.info("Clicked on cross Sell Comforter Pink Color option");
			 * 
			 * productdetail.crossSellAddToCartButtonForDoubleCategoryPinkComforter().click(
			 * ); log.info("Click on add to cart product button of Comforter");
			 */
	
		   Thread.sleep(1000);
		   productdetail.crossSellNextproduct().click();
		   log.info("Click on next product icon in cross selling product section");
		   
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellSoftTouchMemoryPillowCategoryField()));
		   productdetail.crossSellSoftTouchMemoryPillowChangeMultipleOptionAddToCartButton();
	       
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.
			 * crossSellSoftTouchMemoryPillowCategoryField()));
			 * productdetail.crossSellSoftTouchMemoryPillowCategoryField().click();
			 * log.info("Clicked on category field for Memory pillow");
			 * 
			 * productdetail.crossSellSoftTouchMemoryPillowPresidentCategory().click();
			 * log.info("Clicked on President type option from the dropdown");
			 * 
			 * productdetail.crossSellSoftTouchMemoryPillowPackField().click();
			 * log.info("Clicked on Pack field for Memory pillow");
			 * 
			 * productdetail.crossSellSoftTouchMemoryPillowPackOfTwo().click();
			 * log.info("Clicked on Pack of 2 option from dropdown");
			 * 
			 * productdetail.crossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo().click
			 * (); log.
			 * info("Click on add to cart product button of President Memory pillow Pack of 2"
			 * );
			 */

           Thread.sleep(2000);
		   websiteHeader.cartIcon().click();
		   log.info("Click on cart icon");
		   
		   wait.until(ExpectedConditions.visibilityOf(cart.presidentCategoryCloudPillowPackOfFourProductAddedInCart()));
		   boolean productname = cart.presidentCategoryCloudPillowPackOfFourProductAddedInCart().isDisplayed();
		   
			
			if(productname) 
			{
				log.info("Single category Original Mattress and cross sell products are added in cart");
			}else
			{
				log.info("Single category Original Mattress and cross sell products are not added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
