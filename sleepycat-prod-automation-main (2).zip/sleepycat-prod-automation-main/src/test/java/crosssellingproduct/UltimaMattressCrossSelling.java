package crosssellingproduct;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class UltimaMattressCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(UltimaMattressCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	@Test
	public void crossSellingUltima() throws Exception
	{
		
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	      
      //wait = new WebDriverWait(driver, 10);		    	   
	  //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	      
	    //Declare and initialise a fluent wait
		   FluentWait wait = new FluentWait(driver);
		   //Specify the timout of the wait
		   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		   //Sepcify polling time
		   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		   //Specify what exceptions to ignore
		   wait.ignoring(NoSuchElementException.class);
		   wait.ignoring(StaleElementReferenceException.class);
	      
	  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	  //Thread.sleep(3000);
	  productdetail.closeoffer();
	  log.info("Closing the offer modal");
 	   
	   Header websiteHeader = new Header(driver);  	   
	   websiteHeader.mattHeader();
	   log.info("Clicked on Mattress header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.ultimaMattressMenu()));
	   websiteHeader.ultimaMattressMenu().click();
	   log.info("Clicked on Ultima Mattress menu option");
		  	   
	   CartSlider cart = new CartSlider(driver);	   
	   
	   Actions move =new Actions(driver);
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
	   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
	   log.info("Scrolled down to cross selling product section before it is loaded");
	   
	   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellCloudPillowCategoryField()));
	   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
	   log.info("Scrolled down to cross selling product section after it is loaded");
	   
	   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");	   
		productdetail.crossSellCloudPillowChangeMultipleOptionAddToCartButton();;
	   
		/*
		 * productdetail.crossSellGreyColorProtector().click();
		 * log.info("Clicked on cross Sell Gray color option in Protector");
		 * 
		 * Thread.sleep(1000); productdetail.crossSellProtectorCategoryField().click();
		 * log.info("Clicked on category field for Protector");
		 * 
		 * productdetail.crossSellQueenCategoryProtector().click();
		 * log.info("Clicked on cross Sell Queen Category option in Protector");
		 * 
		 * productdetail.crossSellProtectorSizeField().click();
		 * log.info("Clicked on cross Sell Protector Size Field");
		 * 
		 * productdetail.crossSellQueenProtector78x60().click();
		 * log.info("Click on one size option from dropdown");
		 * 
		 * productdetail.crossSellAddToCartQueenProtector78x60().click();
		 * log.info("Click on add to cart product button of Protector");
		 * 
		 * productdetail.crossSellAddToCartButtonForQueenFittedBedSheetTwilightBlue().
		 * click();
		 * //productdetail.crossSellAddToCartButtonForQueenFittedBedSheetDolphinGray().
		 * click(); log.
		 * info("Click on add to cart product button of Queen FittedBed sheet product");
		 * 
		 * Thread.sleep(2000); productdetail.crossSellNextproduct().click();
		 * log.info("Click on next product icon in cross selling product section");
		 */
	   
		/*
		 * wait.until(ExpectedConditions.visibilityOf(productdetail.
		 * crossSellCloudPillowCategoryField()));
		 * productdetail.crossSellCloudPillowCategoryField().click();
		 * log.info("Clicked on category field for cloud pillow");
		 * 
		 * productdetail.crossSellPresidentCategoryCloudPillow().click();
		 * log.info("Clicked on President type option from the dropdown");
		 * 
		 * productdetail.crossSellPackFieldOfCloudPillow().click();
		 * log.info("Click on pack field of cloud pillow");
		 * 
		 * productdetail.CrossSellPackTwoOfCloudPillow().click();
		 * log.info("Click on pack of two option from dropdown");
		 * 
		 * Thread.sleep(1000);
		 * productdetail.crossSellAddtocartPresidentCloudPillowSet2().click();
		 * log.info("Click on add to cart product button of Cloud pillow");
		 */
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
		wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellComforterCategoryField()));
		productdetail.crossSellComforterChangeMultipleOptionAddToCartButton();
	   
       Thread.sleep(2000);
	   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-50)", "");	   
	   productdetail.crossSellNextproduct().click();
	   log.info("Click on next product icon in cross selling product section");
	   
	   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellSoftTouchMemoryPillowCategoryField()));
		productdetail.crossSellSoftTouchMemoryPillowChangeMultipleOptionAddToCartButton();
		/*
		 * wait.until(ExpectedConditions.visibilityOf(productdetail.
		 * crossSellAddToCartButtonForSingleWhiteColorComforter()));
		 * productdetail.crossSellAddToCartButtonForSingleWhiteColorComforter().click();
		 * log.info("Click on add to cart product button of Comforter");
		 * 
		 * //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()
		 * )); productdetail.closeoffer(); log.info("Closing the offer modal");
		 */
	   
		/*
		 * wait.until(ExpectedConditions.visibilityOf(productdetail.
		 * crossSellAddToCartStandardSoftTouchMemoryPillowPackOne()));
		 * productdetail.crossSellAddToCartStandardSoftTouchMemoryPillowPackOne().click(
		 * ); log.
		 * info("Click on add to cart product button of SoftTouch MemoryFoam pillow button"
		 * );
		 */

	   Thread.sleep(1000);
	   websiteHeader.cartIcon().click();
	   log.info("Click on cart icon");
	   
	   Thread.sleep(2000);
	   wait.until(ExpectedConditions.visibilityOf(cart.presidentCategorySoftTouchMemoryPillowPackOfTwoProductAddedInCart()));
	   boolean productname = cart.presidentCategorySoftTouchMemoryPillowPackOfTwoProductAddedInCart().isDisplayed();
	   
		
		if(productname) 
		{
			log.info("Cross sell products present on Ultima mattress page is added in cart");
		}else
		{
			log.info("Cross sell products present on Ultima mattress page is not added in cart");
		}	
	}
	
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
