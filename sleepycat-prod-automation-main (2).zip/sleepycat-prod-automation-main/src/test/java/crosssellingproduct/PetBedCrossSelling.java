package crosssellingproduct;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups = { "RegressionTest" })
public class PetBedCrossSelling extends BaseTest {

	// static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log = LogManager.getLogger(PetBedCrossSelling.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */

	@Test
	public void crossSellingPetBed() throws Exception {
		// driver.get(prop.getProperty("url"));
		// driver.get("https://sleepycat.in/");
		// log.info("Website opened Successfully");

		wait = new WebDriverWait(driver, 10);
		// driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		// wait = new WebDriverWait(driver, 10);
		// driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;

		// Declare and initialise a fluent wait
		FluentWait wait = new FluentWait(driver);
		// Specify the timout of the wait
		wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		// Sepcify polling time
		wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		// Specify what exceptions to ignore
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		// wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		// Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteHeader = new Header(driver);
		websiteHeader.dogBedHeader();
		log.info("Clicked on DogBed header option");
		   
		wait.until(ExpectedConditions.visibilityOf(websiteHeader.dogBedOriginalMenu()));
		websiteHeader.dogBedOriginalMenu().click();
		log.info("Clicked on petBed Menu option");

		CartSlider cart = new CartSlider(driver);
		Actions move = new Actions(driver);
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		//move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		log.info("Scrolled down to cross selling product section before it is loaded");

		wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellComforterCategoryField()));
		move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
		log.info("Scrolled down to cross selling product section after it is loaded");

		productdetail.crossSellDefaultWhiteColorAddToCartButtonforComforter();
		//productdetail.crossSellDefaultAddToCartButtonforComforter();

		/*
		 * productdetail.crossSellAddToCartButtonForSingleWhiteColorComforter().click();
		 * log.info("Clicked on Add to cart button of Single Conforter");
		 * 
		 * //Thread.sleep(1000);
		 * //productdetail.crossSellCloudPillowCategoryField().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellCloudPillowCategoryField());
		 * log.info("Clicked on category field for cloud pillow");
		 * 
		 * 
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 * 
		 * 
		 * //productdetail.crossSellPresidentCategoryCloudPillow().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellPresidentCategoryCloudPillow());
		 * log.info("Clicked on President type option from the dropdown");
		 * 
		 * //productdetail.crossSellPackFieldOfCloudPillow().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellPackFieldOfCloudPillow());
		 * log.info("Clicked on Pack field for cloud pillow");
		 * 
		 * 
		 * productdetail.closeoffer(); log.info("Closing the offer modal");
		 * 
		 * 
		 * //productdetail.crossSellPackFourOfCloudPillow().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellPackFourOfCloudPillow());
		 * log.info("Clicked on Pack of 4 option from dropdown");
		 * 
		 * Thread.sleep(1000);
		 * //productdetail.crossSellCloudPillowIncrementQuantity().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellCloudPillowIncrementQuantity());
		 * log.info("Increment quantity to two");
		 * 
		 * //productdetail.crossSellCloudPillowIncrementQuantity().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellCloudPillowIncrementQuantity());
		 * log.info("Increment quantity to Three");
		 * 
		 * //productdetail.crossSellCloudPillowDecreaseQuantity().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellCloudPillowDecreaseQuantity());
		 * log.info("Decrement quantity to two");
		 * 
		 * //productdetail.crossSellAddtocartPresidentCloudPillowSet4().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellAddtocartPresidentCloudPillowSet4());
		 * log.info("Clicked on add to cart button of Cloud pillow");
		 */

		productdetail.crossSellCloudPillowChangeMultipleOptionAddToCartButton();

		// productdetail.crossSellNextproduct().click();
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", productdetail.crossSellNextproduct());
		log.info("Click on next product icon in cross selling product section");
		
		wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellSoftTouchMemoryPillowCategoryField()));
		productdetail.crossSellSoftTouchMemoryPillowChangeMultipleOptionAddToCartButton();

		/*
		 * Thread.sleep(3000);
		 * productdetail.crossSellSoftTouchMemoryPillowCategoryField().click();
		 * log.info("Clicked on category field for Memory pillow");
		 * 
		 * productdetail.crossSellSoftTouchMemoryPillowPresidentCategory().click();
		 * log.info("Clicked on President type option from the dropdown");
		 * 
		 * productdetail.crossSellSoftTouchMemoryPillowPackField().click();
		 * log.info("Clicked on Pack field for Memory pillow");
		 * 
		 * productdetail.crossSellSoftTouchMemoryPillowPackOfTwo().click();
		 * log.info("Clicked on Pack of 2 option from dropdown");
		 * 
		 * productdetail.crossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo().click
		 * (); log.
		 * info("Click on add to cart product button of President Memory pillow Pack of 2"
		 * );
		 */

		Thread.sleep(1000);
		websiteHeader.cartIcon().click();
		log.info("Click on cart icon");

		// Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOf(cart.singleCategoryWhiteColorComforterProductAddedInCart()));
		//wait.until(ExpectedConditions.visibilityOf(cart.singleCategoryAcidLimeColorComforterProductAddedInCart()));
		boolean productname = cart.singleCategoryWhiteColorComforterProductAddedInCart().isDisplayed();

		if (productname) {
			log.info("Comforter,Cloud and Memory Foam pillow cross sell products are added in cart");
		} else {
			log.info("Comforter,Cloud and Memory Foam pillow cross sell products are added in cart");
		}
	}

	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
