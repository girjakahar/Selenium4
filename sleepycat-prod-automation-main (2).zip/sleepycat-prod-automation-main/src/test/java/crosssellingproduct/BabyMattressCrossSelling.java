package crosssellingproduct;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class BabyMattressCrossSelling extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(BabyMattressCrossSelling.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
    public void crossSellingBabyMattress() throws Exception
	{
    	
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
    	//wait = new WebDriverWait(driver, 10);		    	   
	    //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	    
	       //Declare and initialise a fluent wait
		   FluentWait wait = new FluentWait(driver);
		   //Specify the timout of the wait
		   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		   //Sepcify polling time
		   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		   //Specify what exceptions to ignore
		   wait.ignoring(NoSuchElementException.class);
		   wait.ignoring(StaleElementReferenceException.class);
	      
	    //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	   //Thread.sleep(3000);
       productdetail.closeoffer();
	   log.info("Closing the offer modal");
 	   
       Header websiteHeader = new Header(driver); 
	   CartSlider cart = new CartSlider(driver);	   
	   websiteHeader.mattHeader();
 	   log.info("Click on Mattress menu in header");

 	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.babyMattressMenu()));		   
 	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteHeader.babyMattressMenu());
	   log.info("Click on Baby Mattress menu option");
		  	   
	   Actions move =new Actions(driver);
	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
	   //move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
	   log.info("Scrolled down to cross selling product section before it is loaded");
	   
	   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellComforterCategoryField()));
	   move.moveToElement(productdetail.CrossSellFreeShippingText()).build().perform();
	   log.info("Scrolled down to cross selling product section after it is loaded");
	   
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
	   
	   productdetail.crossSellComforterCategoryField().click();
	   log.info("Clicked on category field for Comforter");
	   
  	   productdetail.crossSellDoubleCategoryComforter().click();
	   log.info("Clicked on cross Sell Double Category Comforter option");
	   
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
	   
	   Thread.sleep(3000);
	   productdetail.crossSellComforterCoffeeColor().click();
	   log.info("Clicked on cross Sell Comforter coffee Color option");	   
	   
	   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellAddToCartButtonForDoubleCategoryCoffeeComforter()));
	   productdetail.crossSellAddToCartButtonForDoubleCategoryCoffeeComforter().click();
	   log.info("Click on add to cart product button of Comforter");
	   
	   Thread.sleep(3000);
	   productdetail.crossSellAddToCartButtonForCuddlePillow().click();
	   log.info("Click on add to cart product button of Cuddle pillow");
	   
	   Thread.sleep(2000);
	   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-80)", "");
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.crossSellNextproduct());
	   productdetail.crossSellNextproduct().click();
	   log.info("Click on next product icon in cross selling product section");
	
	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer())); 
	   productdetail.closeoffer(); 
	   log.info("Closing the offer modal");		 
	   
	   Thread.sleep(2000);
	   productdetail.crossSellCloudPillowCategoryField().click();
	   log.info("Clicked on category field for cloud pillow");
		 	   
	   productdetail.crossSellPresidentCategoryCloudPillow().click();
	   log.info("Clicked on President type option from the dropdown");
	   
	   productdetail.crossSellPackFieldOfCloudPillow().click();
	   log.info("Clicked on Pack field for cloud pillow");
	   
	   productdetail.CrossSellPackTwoOfCloudPillow().click();
	   log.info("Clicked on Pack of 2 option from dropdown");
	   
       Thread.sleep(4000);
	   productdetail.crossSellCloudPillowIncrementQuantity().click();
	   log.info("Increment quantity to two");
	   
	   productdetail.crossSellCloudPillowIncrementQuantity().click();
	   log.info("Increment quantity to Three");
	   
	   productdetail.crossSellCloudPillowDecreaseQuantity().click();
	   log.info("Decrement quantity to two");	   		   
	   
	   productdetail.crossSellAddtocartPresidentCloudPillowSet2().click();
	   log.info("Clicked on add to cart button of Cloud pillow");
	   
	   //Thread.sleep(5000);
	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
       productdetail.closeoffer();
	   log.info("Closing the offer modal");

	   websiteHeader.cartIcon().click();
	   log.info("Click on cart icon");
	   
	   wait.until(ExpectedConditions.visibilityOf(cart.doubleCategoryCoffeColorComforterProductAddedInCart()));
	   boolean productname = cart.doubleCategoryCoffeColorComforterProductAddedInCart().isDisplayed();
		
		if(productname) 
		{
			log.info("Cross selling Comforter,Cuddle and Cloud pillow Products is added in cart");
		}else
		{
			log.info("Cross selling Comforter,Cuddle and Cloud pillow Products is added in cart");
		}	
	}
    
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
