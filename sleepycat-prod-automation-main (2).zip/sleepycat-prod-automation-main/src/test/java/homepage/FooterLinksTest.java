package homepage;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Utility.LinkVerification;
import base.BaseTest;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class FooterLinksTest extends BaseTest {		
	
	//public RemoteWebDriver driver;
	public static Logger log =LogManager.getLogger(FooterLinksTest.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * 
	 * }
	 */
	@Test
	public void Footerlink() throws Exception
	{
		
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
		
	    driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		   productdetail.closeoffer();
		   log.info("Closing the offer modal");

		List<WebElement> links=driver.findElements(By.xpath("//div[@class='footer-links-section']//a"));//this is only for footer only
		//List<WebElement> links=driver.findElements(By.xpath("//div[@class='footer-links-section footer_menu']//a"));//this is only for footer only
		log.info("Total Footerlink are "+links.size());
		
		for(int i=0;i<links.size();i++)
		{
			
			WebElement footerLinksElement= links.get(i);
			
			String url=footerLinksElement.getAttribute("href");
			
			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);
			
		}
		log.info("Footer links are done");

	}

}
