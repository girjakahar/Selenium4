package homepage;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.LinkVerification;
import base.BaseTest;
import pageobject.Homepage;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class NewFromSleepyCatProductSection extends BaseTest {

	public static Logger log = LogManager.getLogger(NewFromSleepyCatProductSection.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException { driver =
	 * initializeChrome(); log.info("Starting driver"); }
	 */

	@Test(priority=1)	
	public void ohayoBedProductLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
		
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
	   ProductDetails productdetail = new ProductDetails(driver);
	   Thread.sleep(3000);
	   productdetail.closeoffer();
	   log.info("Closing the offer modal");

		Homepage home = new Homepage(driver);
		home.ohayoBedProductInNewfromSleepycatSection();
		log.info("Scroll to Ohayo Bed Product and Clicked on this product");

		String mattressurl = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(mattressurl);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=2)	
	public void weightedBlanketProductLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
		
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	 

		Homepage home = new Homepage(driver);
		home.weightedBlanketProductInNewfromSleepycatSection();
		log.info("Scroll to Weighted Balnket Product and Clicked on this product");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=3)	
	public void petBedProductLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
		
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	 

		Homepage home = new Homepage(driver);
		home.petBedProductInNewfromSleepycatSection();
		log.info("Scroll to PetBed Product and Clicked on this product");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=4)	
	public void cuddlePillowProductLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
		
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	 

		Homepage home = new Homepage(driver);
		home.cuddlePillowProductInNewfromSleepycatSection();
		log.info("Scroll to Cuddle Pillow Product and Clicked on this product");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the opened url");

	}
	
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
