package homepage;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.Header;
import pageobject.LoginPage;
import pageobject.ProductDetails;
import pageobject.ReviewOrder;
import pageobject.TrackOrder;

@Test(groups= {"RegressionTest"})

public class ReviewModalTesting extends BaseTest {
	
	static WebDriverWait wait;
	
	public static Logger log =LogManager.getLogger(ReviewModalTesting.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver"); }
	 */	
	@Test
	public void reviewModalTest() throws Exception
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
		
		wait = new WebDriverWait(driver, 10);		    	   
	    //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	    //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	    //Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		   
		Header websiteheader = new Header(driver);
		websiteheader.moreHeader();
		log.info("More menu is opened");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.review()));
		   websiteheader.review().click();
		   log.info("Clicked on Review menu option");

		/*
		 * LoginPage loginpage = new LoginPage(driver);
		 * loginpage.switchingToChildWindow();;
		 * log.info("Switching to Review Order Page");
		 */
        
	    Thread.sleep(3000);
		ReviewOrder review = new ReviewOrder(driver);
	    wait.until(ExpectedConditions.visibilityOf(review.wrieReviewButton()));
		review.wrieReviewButton().click();
		log.info("Click on Write review button");
        
	    wait.until(ExpectedConditions.visibilityOf(review.submitReviewModal()));
	    boolean reviewModal = review.submitReviewModal().isDisplayed();
	    
	    if(reviewModal) 
		{
			log.info("Write Product Review Modal is displayed");
		}else
		{
			log.info("Write Product Review Modal is not displayed");
		}
	    
	    wait.until(ExpectedConditions.visibilityOf(review.selectProductNameDropdown()));
        Select Productname = new Select(review.selectProductNameDropdown());
        Productname.selectByValue("weighted_blanket");
	    
	}    
	/*
	 * @AfterTest public void close() { driver.quit(); log.info("Driver is closed");
	 * }
	 */

}
