package homepage;

import org.testng.annotations.Test;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Utility.LinkVerification;
import base.BaseTest;
import pageobject.Header;
import pageobject.ProductDetails;


@Test(groups = { "RegressionTest" })
public class HeaderLinksTest extends BaseTest {

	// public RemoteWebDriver driver;
	public static Logger log = LogManager.getLogger(HeaderLinksTest.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * 
	 * }
	 */

	@Test
	public void mattressHeaderLink() throws Exception {

		// driver.get(prop.getProperty("url"));
		// driver.get("https://sleepycat.in/");
		// log.info("Website opened Successfully");

		// driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.mattHeader();
		log.info("Clicked on Mattress header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer mattressMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Mattress Header menu links are done");

	}

	@Test
	public void pillowsHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.pillowHeader();
		log.info("Clicked on Pillow header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer pillowMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Pillow products Submenu links are done");

	}

	@Test
	public void bedHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.bedHeader();
		log.info("Clicked on bed header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer bedMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Bed products Submenu links are done");

	}

	@Test
	public void beddingHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.beddingHeader();
		log.info("Clicked on bedding header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer beddingMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Bedding products Submenu links are done");

	}

	@Test
	public void babyRangeHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.babyHeader();
		log.info("Clicked on baby header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer babyMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Baby Range Submenu links are done");
	}

	@Test
	public void dogBedHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.dogBedHeader();
		log.info("Clicked on Dog Bed header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer dogbedMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Dog Bed Submenu links are done");

	}

	@Test
	public void bundleHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.bundleHeader();
		log.info("Clicked on Bundle header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer bundleMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Bundle Submenu links are done");
	}

	@Test
	public void limitedEditionHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.limitedEditionHeader();
		log.info("Clicked on Limited Edition header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer limited_editionMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Limited Edition Submenu links are done");

	}

	@Test
	public void helpMeChooseHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.helpMeChooseHeader();
		log.info("Clicked on help Me Choose Header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer help_me_chooseMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		log.info("Help Me Choose Submenu links are done");

	}

	@Test
	public void moreHeaderlinks() throws Exception 
	{
		ProductDetails productdetail = new ProductDetails(driver);
		productdetail.openWebsite();
		log.info("open the website");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Header websiteheader = new Header(driver);
		websiteheader.moreHeader();
		log.info("Clicked on More header option");

		List<WebElement> links = driver.findElements(By.xpath("//div[@class='navMenuBdyContainer moreMenu']//a"));
	
		log.info("Total Headerlink are " + links.size());

		for (int i = 0; i < links.size(); i++) {

			WebElement headerLinksElement = links.get(i);

			String url = headerLinksElement.getAttribute("href");

			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);

		}
		
		log.info("More Submenu links are done");

	}

	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
