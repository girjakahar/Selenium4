package homepage;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.LinkVerification;
import base.BaseTest;
import pageobject.Homepage;
import pageobject.LoginPage;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class SocialMedia extends BaseTest
{
	//public RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(SocialMedia.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	@Test
	public void socialMediaLinks() throws Exception
	{
		driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      log.info("Website opened Successfully");
									  
      driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
      ProductDetails productdetail = new ProductDetails(driver);
	   productdetail.closeoffer();
	   log.info("Closing the offer modal");
	  	   
	   List<WebElement> links=driver.findElements(By.xpath("//div[@class='d-flex social_share_footer_2']//a"));//This is for checking Header only
	    log.info("Total Social media links are "+links.size());

		for(int i=0;i<links.size();i++)
		{
			
			WebElement medialinkselement= links.get(i);
			
			String url=medialinkselement.getAttribute("href");
			
			LinkVerification response = new LinkVerification(driver);
			response.verifyLinkActive(url);
			
		}
		log.info("Header links are done");
	   
	}
	
	/*
	 * @AfterTest public void close() throws IOException { driver.quit();
	 * log.info("Driver is closed"); }
	 */
	 

}
