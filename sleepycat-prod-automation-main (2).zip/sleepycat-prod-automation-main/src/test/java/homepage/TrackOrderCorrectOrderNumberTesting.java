package homepage;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.Header;
import pageobject.LoginPage;
import pageobject.ProductDetails;
import pageobject.TrackOrder;

@Test(groups= {"RegressionTest"})

public class TrackOrderCorrectOrderNumberTesting extends BaseTest {
	
	static WebDriverWait wait;
	
	public static Logger log =LogManager.getLogger(TrackOrderCorrectOrderNumberTesting.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver"); }
	 */
	
	@Test
	public void trackOrderCorrectOrderNumberTesting() throws Exception
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	    //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	    //Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		   
		Header websiteheader = new Header(driver);
		websiteheader.moreHeader();
		log.info("More menu is opened");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.trackOrder()));
		   websiteheader.trackOrder().click();
		log.info("Click on Track order option");

		//LoginPage loginpage = new LoginPage(driver);
		//loginpage.switchingToChildWindow();;
		//log.info("Switching to Track Order Page");
        
		TrackOrder trackorderdetail = new TrackOrder(driver);
		trackorderdetail.orderNumber().sendKeys("942513");
		log.info("Order Number is addded");

		trackorderdetail.trackOrderSubmitButton().click();
		log.info("Click on Submit button");

	    wait.until(ExpectedConditions.visibilityOf(trackorderdetail.orderNumberDetails()));
	    boolean orderdetails = trackorderdetail.orderNumberDetails().isDisplayed();
	    
	    if(orderdetails) 
		{
			log.info("Order Details for this order will get displayed");
		}else
		{
			log.info("Order Details for this order will not get displayed");
		}
	}    
	/*
	 * @AfterTest public void close() { driver.quit(); log.info("Driver is closed");
	 * }
	 */

}
