package homepage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.ContactUsPage;
import pageobject.Header;
import pageobject.LoginPage;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class EmptycartTest extends BaseTest {
	
	static WebDriverWait wait;
	
	public static Logger log =LogManager.getLogger(EmptycartTest.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver"); }
	 */
	
	@Test
	public void emptycartTest() throws Exception
	{
		
		
		wait = new WebDriverWait(driver, 10);		    	   
	    //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	    ProductDetails productdetail = new ProductDetails(driver);
	    productdetail.openWebsite();
	       log.info("open the website");
	       
	    //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	    //Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		   
		Header websiteheader = new Header(driver);
	  	CartSlider cart = new CartSlider(driver);   
		websiteheader.cartIcon().click();
		log.info("Click on cartIcon shown on the homepage");

	    wait.until(ExpectedConditions.visibilityOf(cart.shopNowButtonInCartSlider()));
	    boolean blankCart = cart.shopNowButtonInCartSlider().isDisplayed();
	    
	    if(blankCart) 
		{
			log.info("Shop now button is displayed and Cart is blank when open without adding any product");
		}else
		{
			log.info("Shop now button is not showing and Cart is not blank when open without adding any product");
		}
	}

}
