package homepage;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.LinkVerification;
import base.BaseTest;
import pageobject.Homepage;
import pageobject.ProductDetails;

@Test(groups = { "SanityTest", "RegressionTest" })
public class BannerLinking extends BaseTest {

	static WebDriverWait wait;

	public static Logger log = LogManager.getLogger(BannerLinking.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException { driver =
	 * initializeChrome(); log.info("Starting driver"); }
	 */

	@Test(priority = 1)
	public void firstBanner() throws Exception 
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
		//wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		// Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		Thread.sleep(1000);
		Homepage home = new Homepage(driver);
		WebElement firstDotBanner = driver.findElementByXPath("//div[@class='owl-dots']/button[1]");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", firstDotBanner);
		// Actions bannerlink =new Actions(driver);
		// bannerlink.moveToElement(home.firstBanner()).build().perform();
		// home.firstBanner().click();
		log.info("Clicked on first banner dot icon");

		((JavascriptExecutor) driver).executeScript("arguments[0].click();", home.firstBanner());
		log.info("Clicked on first banner image");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the First banner url");

	}

	@Test(priority = 2)
	public void secondBanner() throws Exception {
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully for secondBanner");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ProductDetails productdetail = new ProductDetails(driver);
		// productdetail.closeoffer();
		// log.info("Closing the offer modal");

		Homepage home = new Homepage(driver);
		/*
		 * home.nextbanner().click();
		 * log.info("Clicked on next banner icon on first banner");
		 */

		WebElement secondDotBanner = driver.findElementByXPath("//div[@class='owl-dots']/button[2]");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", secondDotBanner);
		log.info("Clicked on Second banner dot icon");

		((JavascriptExecutor) driver).executeScript("arguments[0].click();", home.secondBanner());
		// home.secondBanner().click();
		log.info("Clicked on Second banner Image");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the Second banner url");

	}

	@Test(priority = 3)
	public void thirdBanner() throws Exception {

		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully for thirdBanner");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ProductDetails productdetail = new ProductDetails(driver);
		// productdetail.closeoffer();
		// log.info("Closing the offer modal");

		Homepage home = new Homepage(driver);
		// home.nextbanner().click();
		// log.info("Clicked on next banner icon on first banner");

		// home.nextbanner().click();
		// log.info("Clicked on next banner icon on Second banner");

		WebElement thirdDotBanner = driver.findElementByXPath("//div[@class='owl-dots']/button[3]");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", thirdDotBanner);
		log.info("Clicked on Third banner dot icon");

		((JavascriptExecutor) driver).executeScript("arguments[0].click();", home.thirdBanner());
		// home.thirdBanner().click();
		log.info("Clicked on Third banner Image");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the Third banner url");

	}

	
	  @Test(priority=4) public void fourthBanner() throws Exception {
	  
	  driver.get(prop.getProperty("url"));
	  log.info("Website opened Successfully for fourthBanner");
	  
	  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
	  ProductDetails productdetail = new ProductDetails(driver);
	  //productdetail.closeoffer(); //log.info("Closing the offer modal");
	  
	  Homepage home = new Homepage(driver);
	  
		/*
		 * home.nextbanner().click();
		 * log.info("Clicked on next banner icon on first banner");
		 * 
		 * home.nextbanner().click();
		 * log.info("Clicked on next banner icon on Second banner");
		 * 
		 * home.nextbanner().click();
		 * log.info("Clicked on next banner icon on third banner");
		 */
	  
	  
	  WebElement fourthDotBanner =
	  driver.findElementByXPath("//div[@class='owl-dots']/button[4]");
	  ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
	  fourthDotBanner); log.info("Clicked on Fourth banner dot icon");
	  
	  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", home.fourthBanner()); 
	  //home.fourthBanner().click();
	  log.info("Clicked on Fourth banner Image");
	  
	  String url = driver.getCurrentUrl(); log.info("Fetching the current url");
	  
	  LinkVerification response = new LinkVerification(driver);
	  response.verifyLinkActive(url);
	  log.info("checking the response code for the fourth banner url");
	  
	  }
	 

	/*
	 * @Test(priority=5) public void fifthBanner() throws Exception {
	 * 
	 * driver.get(prop.getProperty("url"));
	 * log.info("Website opened Successfully for fourthBanner");
	 * 
	 * driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
	 * ProductDetails productdetail = new ProductDetails(driver);
	 * //productdetail.closeoffer(); //log.info("Closing the offer modal");
	 * 
	 * Homepage home = new Homepage(driver); WebElement fourthDotBanner =
	 * driver.findElementByXPath("//div[@class='owl-dots']/button[5]");
	 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
	 * fourthDotBanner); log.info("Clicked on fifth banner dot icon");
	 * 
	 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
	 * home.fifthBanner()); //home.fifthBanner().click();
	 * log.info("Clicked on fifth banner Image");
	 * 
	 * String url = driver.getCurrentUrl(); log.info("Fetching the current url");
	 * 
	 * LinkVerification response = new LinkVerification(driver);
	 * response.verifyLinkActive(url);
	 * log.info("checking the response code for the Fifth banner url");
	 * 
	 * }
	 */

	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
