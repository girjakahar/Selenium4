package homepage;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.LinkVerification;
import base.BaseTest;
import pageobject.Homepage;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class BrowseOurDreamySleepRangeSection extends BaseTest {

	public static Logger log = LogManager.getLogger(BrowseOurDreamySleepRangeSection.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException { driver =
	 * initializeChrome(); log.info("Starting driver"); }
	 */

	
	@Test(priority=1)	
	public void mattressCategoryLink() throws Exception 
	{						  
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	   Thread.sleep(3000);
	   productdetail.closeoffer();
	   log.info("Closing the offer modal");

		Homepage home = new Homepage(driver);
		home.mattressCategoryInSleepCategorySection();
		log.info("Scroll to mattress category and Clicked on Mattress category");

		String mattressurl = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(mattressurl);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=2)	
	public void pillowsCategoryLink() throws Exception 
	{				
		
        ProductDetails productdetail = new ProductDetails(driver);

		productdetail.openWebsite();
	       log.info("open the website");
		
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	 

		Homepage home = new Homepage(driver);
		home.pillowsCategoryInSleepCategorySection();
		log.info("Scroll to Pillows category and Clicked on Pillows category");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=3)	
	public void beddingCategoryLink() throws Exception 
	{						  
		ProductDetails productdetail = new ProductDetails(driver);

		productdetail.openWebsite();
	       log.info("open the website");
		
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	 

		Homepage home = new Homepage(driver);
		home.beddingCategoryInSleepCategorySection();
		log.info("Scroll to Bedding category and Clicked on Bedding category");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=4)	
	public void bundleRangeLink() throws Exception 
	{						  
		ProductDetails productdetail = new ProductDetails(driver);

		productdetail.openWebsite();
	       log.info("open the website");
		
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	 

		Homepage home = new Homepage(driver);
		home.bundleCategoryInSleepCategorySection();
		log.info("Scroll to Bundle category and Clicked on that category image");

		String url = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(url);
		log.info("checking the response code for the opened url");

	}
	
	
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
