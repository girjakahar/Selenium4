package homepage;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import login.CorrectLoginTest;
import pageobject.Header;
import pageobject.LoginPage;
import pageobject.ProductDetails;
import pageobject.TrackOrder;

@Test(groups= {"RegressionTest"})

public class TrackOrderIncorrectOrderNumberTesting extends BaseTest {
	
	static WebDriverWait wait;
	
	public static Logger log =LogManager.getLogger(TrackOrderIncorrectOrderNumberTesting.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver"); }
	 */
	
	@Test
	public void trackOrderIncorrectOrderNumberTesting() throws Exception
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	    //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	    //Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		   
		Header websiteheader = new Header(driver);
		websiteheader.moreHeader();
		log.info("More menu is opened");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.trackOrder()));
		   websiteheader.trackOrder().click();
		log.info("Click on Track order option");

		/*
		 * LoginPage loginpage = new LoginPage(driver);
		 * loginpage.switchingToChildWindow();;
		 * log.info("Switching to Track Order Page");
		 */
        
		TrackOrder trackorderdetail = new TrackOrder(driver);
		trackorderdetail.orderNumber().sendKeys("jbj2j232");
		log.info("Order Number is addded");

		trackorderdetail.trackOrderSubmitButton().click();
		log.info("Click on Submit button");

	    wait.until(ExpectedConditions.visibilityOf(trackorderdetail.orderDetailsNotFoundMessage()));
	    boolean orderdetailnotfound = trackorderdetail.orderDetailsNotFoundMessage().isDisplayed();
	    
	    if(orderdetailnotfound) 
		{
			log.info("Order Details not Found info message is displayed");
		}else
		{
			log.info("Order Details not Found info message is not displayed");
		}
	    
	    Thread.sleep(2000);
	    trackorderdetail.tryAgainOption().click();
	    log.info("Click on Try Again option Link");
	    
	    boolean ordernumberfield = trackorderdetail.orderNumber().isDisplayed();

	    if(ordernumberfield) 
		{
			log.info("Order Number field is displayed again");
		}else
		{
			log.info("Order Number field is Not displayed again");
		}
	    
	}

	/*
	 * @AfterTest public void close() { driver.quit(); log.info("Driver is closed");
	 * }
	 */

}
