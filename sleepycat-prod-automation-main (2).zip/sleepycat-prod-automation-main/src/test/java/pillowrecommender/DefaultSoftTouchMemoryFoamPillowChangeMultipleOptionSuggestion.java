package pillowrecommender;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.Homepage;
import pageobject.PillowRecommender;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultSoftTouchMemoryFoamPillowChangeMultipleOptionSuggestion extends BaseTest {
	
	static WebDriverWait wait;
	
public static Logger log =LogManager.getLogger(DefaultSoftTouchMemoryFoamPillowChangeMultipleOptionSuggestion.class);
	
/*
 * @BeforeTest public void startingDriver() throws IOException {
 * driver=initializeChrome(); log.info("Starting driver");
 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
 * }
 */
	
	@Test	
	public void softTouchMemoryFoamPillowChangeMultipleOptionSuggestion() throws Exception
	{
		
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	      
		//wait = new WebDriverWait(driver, 10);				  
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	      
	    //Declare and initialise a fluent wait
		   FluentWait wait = new FluentWait(driver);
		   //Specify the timout of the wait
		   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		   //Sepcify polling time
		   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		   //Specify what exceptions to ignore
		   wait.ignoring(NoSuchElementException.class);
		   wait.ignoring(StaleElementReferenceException.class);
		   
		//Thread.sleep(3000);
		//wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		
		Header websiteHeader = new Header(driver);  	   
		websiteHeader.pillowHeader();
	  	log.info("All Pillow menu is opened");
	  	   
	 	wait.until(ExpectedConditions.visibilityOf(websiteHeader.pillowRecommenderMenu()));
	 	websiteHeader.pillowRecommenderMenu().click();
		log.info("Click on Pillow Recommender menu and open this page");
		   
		Homepage home = new Homepage(driver);
	  	CartSlider cart = new CartSlider(driver);
	  	PillowRecommender pillowrecommender = new PillowRecommender(driver);
	  	pillowrecommender.proAdultThirtyToFoutyFive().click();
		log.info("Click on pro Adult Thirty To Fouty Five option for Let's start easy. What's your age group? question");
		
		Thread.sleep(2000);
		pillowrecommender.firstNextbutton().click();
		log.info("Click on first next question button");
		
		//Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.idealSixToEightHoursOption()));
		pillowrecommender.idealSixToEightHoursOption().click();
		log.info("Click on ideal Six To Eight Hours Option for Count your daily nighttime snooze hours for us! question");
		
		Thread.sleep(2000);
		pillowrecommender.secondNextbutton().click();
		log.info("Click on Second next question button");
		
		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.itsDifferentEverydayOption()));
		pillowrecommender.sideOption().click();
		log.info("Click on Side Option for You're usually found waking up on your? question");

		Thread.sleep(2000);
		pillowrecommender.thirdNextbuttonOption().click();
		log.info("Click on Third next question button");
		
		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.supportedAroundTheHeadAndNeckOption()));
		pillowrecommender.allOfTheAboveOption().click();
		log.info("Click on all Of The Above option for How do you want your pillow to make you feel? question");
		
		Thread.sleep(2000);
		pillowrecommender.fourthNextbutton().click();
		log.info("Click on Fourth next question button");
		
		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.mediumSoftOption()));
		pillowrecommender.firmOption().click();
		log.info("Click on firm Option for Squishy or firm? How would you like your pillow to feel? question");
		
		Thread.sleep(2000);
		pillowrecommender.submit().click();
		log.info("Click on Submit button");
		
		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.enterEmailField()));
		pillowrecommender.enterEmailField().sendKeys("Test@test.com");
		log.info("Click on Enter Email field and enter the email id");
		
		Thread.sleep(2000);
		pillowrecommender.signUpButton().click();
		log.info("Click on Signup Button");
		
		   Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossSellSoftTouchMemoryPillowCategoryField()));
	  	   productdetail.crossSellSoftTouchMemoryPillowCategoryField().click();
		   log.info("Clicked on category field for SoftTouch Memory pillow");
		   
		   productdetail.crossSellSoftTouchMemoryPillowPresidentCategory().click();
		   log.info("Clicked on President type option from the dropdown");
		   
		   productdetail.crossSellSoftTouchMemoryPillowPackField().click();
		   log.info("Clicked on Pack field for SoftTouch Memory pillow");
		   
		   productdetail.crossSellSoftTouchMemoryPillowPackOfTwo().click();
		   log.info("Clicked on Pack of 2 option from dropdown");
		   
           Thread.sleep(1000);
		   productdetail.crossSellSoftTouchMemoryPillowIncrementQuantity().click();
		   log.info("Increment quantity to two");
		   
		   productdetail.crossSellSoftTouchMemoryPillowIncrementQuantity().click();
		   log.info("Increment quantity to Three");
		   
		   productdetail.crossSellSoftTouchMemoryPillowDecreaseQuantity().click();
		   log.info("Decrement quantity to two");

		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.softTouchMemoryFoamPillowAddToCartButton()));
		pillowrecommender.softTouchMemoryFoamPillowAddToCartButton().click();
		log.info("Click on Default add to cart button on Pillow Recommnder Result page");
		
		wait.until(ExpectedConditions.visibilityOf(pillowrecommender.itemAddedToCartMessage()));
		websiteHeader.cartIcon().click();
	  	log.info("Clicked on Cart icon");
		
		wait.until(ExpectedConditions.visibilityOf(cart.softTouchMemoryFoamPillowProductAddedInCartSlider()));
		boolean mattresssuggestion = cart.softTouchMemoryFoamPillowProductAddedInCartSlider().isDisplayed();
		   
		  if(mattresssuggestion) 
			{
				log.info("SoftTouch MemoryFoam Pillow Product is recommended and is added in cart slider");
			}else
			{
				log.info("SoftTouch MemoryFoam Pillow Product is recommended but it is not added in cart slider");
			}     
	     			
	}

	/*
	 * @AfterTest public void close() { driver.quit(); log.info("Driver is closed");
	 * }
	 */

}
