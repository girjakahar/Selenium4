package pillowpageproducts;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import addtocartproducts.SoftTouchMemoryFoamPillowProductDetailsChanges;
import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.SoftTouchMemoryFoamPillow;
import pageobject.PillowsPage;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class PillowsPageMemoryPillowAddtocart extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(PillowsPageMemoryPillowAddtocart.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void memoryFoamPillowAddToCartPillowPage() throws Exception
		{
		 
		 driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      log.info("Website opened Successfully");
	      
		   wait = new WebDriverWait(driver, 10);		    	   
	       //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	       ProductDetails productdetail = new ProductDetails(driver);
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");

	  	   CartSlider cart = new CartSlider(driver);
		   Header websiteheader = new Header(driver);
		   websiteheader.pillowMenulinkOnHeader();
		   log.info("Pillows page contaning pillow Products is opened");
		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		   PillowsPage pillowdetail = new PillowsPage(driver);
		   pillowdetail.typeSelectionInMemoryFaomPillow();
		   log.info("Scroll to Type Field of Memory Pillow and click on President Type field");
		   
		   pillowdetail.packSelectionInMemoryFaomPillow();
		   log.info("Scroll to Pack Field and Select the Pack of 2 option from dropdown");
		   
		   pillowdetail.quantitySelectInMemoryFaomPillow();
		   log.info("Scroll to Quantity Field and Select one quantity from dropdown");
		   
		   pillowdetail.presidentMemoryFoamPillowPackOfTwoAddToCartButton().click();
		   log.info("Scroll to Add to cart button and click on add to cart button");
		   
		   
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
