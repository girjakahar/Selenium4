package Order;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class MattressSizeGuideImageTestInCartSlider extends BaseTest {
	
	static WebDriverWait wait;
	//static RemoteWebDriver driver;
	public static Logger log =LogManager.getLogger(MattressSizeGuideImageTestInCartSlider.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	@Test
	public void mattressSizeImageTest() throws Exception
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	  wait = new WebDriverWait(driver, 10);
	  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	  productdetail.closeoffer();
	  log.info("Closing the offer modal");
       
	   Header websiteheader = new Header(driver);
  	   CartSlider cart = new CartSlider(driver);
       
  	   websiteheader.mattHeader();
	  log.info("Clicked on Mattress header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteheader.originalMattressMenu()));
	   websiteheader.originalMattressMenu().click();
	   log.info("Clicked on Original Mattress menu option");
	    
  	   OriginalMattress originalmattressproduct = new OriginalMattress(driver);
  	    productdetail.kingCategory().click();
		log.info("Clicked on King category option");

		//((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.sizeDropdown());
		 //log.info("Scrolled down to size dropdown option");
		 ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,80)", ""); 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
		 //productdetail.sizeDropdown().click();
	     log.info("Clicked on size dropdown option");
	     
		 ((JavascriptExecutor)driver).executeScript("arguments[0].click();", originalmattressproduct.kingOriginal78x72x6());
	     //originalmattressproduct.originalQueen72x60x6().click();
	     log.info("Clicked on one size option from drop down field");
  	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
	   log.info("Scroll to cross selling product section");
	   
	   originalmattressproduct.addToCart();
	   log.info("Clicked on add to cart button");
	   
		wait.until(ExpectedConditions.visibilityOf(cart.mattressHelpGuideLinkText()));
		cart.mattressHelpGuideLinkText().click();
		log.info("Clicked on help Mattress guide link");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		
		wait.until(ExpectedConditions.visibilityOf(cart.mattressGuideImage()));
		boolean mattressguideimage = cart.mattressHelpGuideLinkText().isDisplayed();

		if(mattressguideimage) 
		{
			log.info("Mattress Guide Image is displayed");
		}else
		{
			log.info("Mattress Guide Image is not displayed");
		}

}
    
/*
 * @AfterTest public void closeDriver() throws IOException { driver.quit();
 * log.info("Driver is closed");
 * 
 * }
 */

}
