package Order;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
public class CartHandling extends BaseTest {
	
	static WebDriverWait wait;
	//static RemoteWebDriver driver;
	public static Logger log =LogManager.getLogger(CartHandling.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	@Test
	public void cartHandling() throws Exception
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	  //wait = new WebDriverWait(driver, 10);
	  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	  
	   //Declare and initialise a fluent wait
	   FluentWait wait = new FluentWait(driver);
	   //Specify the timout of the wait
	   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
	   //Sepcify polling time
	   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
	   //Specify what exceptions to ignore
	   wait.ignoring(NoSuchElementException.class);
	   wait.ignoring(StaleElementReferenceException.class);
	   
	  productdetail.closeoffer();
	  log.info("Closing the offer modal");
       
	   Header websiteheader = new Header(driver);
  	   CartSlider cart = new CartSlider(driver);
       
	   wait.until(ExpectedConditions.visibilityOf(websiteheader.cartIcon()));
  	   websiteheader.cartIcon().click();
  	   log.info("Clicked on Cart icon");
	    
  	   Thread.sleep(2000);
	   wait.until(ExpectedConditions.visibilityOf(cart.defaultAddtoCartStandardPackOfOneCloudPillow()));
  	   cart.defaultAddtoCartStandardPackOfOneCloudPillow().click();
  	   log.info("Click on Add to cart button cloud pillow");
	   
  	   Thread.sleep(3000);
	   wait.until(ExpectedConditions.visibilityOf(cart.incrementQuantity()));
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.incrementQuantity());
	   //cart.incrementQuantity().click();
  	   log.info("Increment product quantity");
       
  	   Thread.sleep(2000);
  	   WebElement decreasequantitysign = cart.decreseQuantity();
	   wait.until(ExpectedConditions.visibilityOf(decreasequantitysign));
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", decreasequantitysign);
	   //decreasequantitysign.click();
  	   log.info("Decrese quantity by one");

  	   Thread.sleep(1000);
	   wait.until(ExpectedConditions.visibilityOf(cart.removeProduct()));
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.removeProduct());
	   //cart.removeProduct().click();
  	   log.info("Clicked on remove product icon from cart slider ");

}
    
/*
 * @AfterTest public void closeDriver() throws IOException { driver.quit();
 * log.info("Driver is closed");
 * 
 * }
 */

}
