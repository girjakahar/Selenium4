package Order;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.CheckoutPage;
import pageobject.Header;
import pageobject.LatexMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class SnapmintPaymnetgateway extends BaseTest {
	
//static RemoteWebDriver driver;
static WebDriverWait wait;
public static Logger log =LogManager.getLogger(SnapmintPaymnetgateway.class);


/*
 * @BeforeTest public void startingDriver() throws IOException {
 * driver=initializeChrome(); log.info("Starting driver");
 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
 * }
 */


@Test
public void snapmintPaymnetgateway() throws Exception
{
	//driver.get(prop.getProperty("url"));
    //driver.get("https://sleepycat.in/");
    //log.info("Website opened Successfully");
  	
    wait = new WebDriverWait(driver, 10);		    	   
    //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
    ProductDetails productdetail = new ProductDetails(driver);
    productdetail.openWebsite();
     log.info("open the website");
    
   //wait = new WebDriverWait(driver, 10);  					  
   //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
    
    FluentWait wait = new FluentWait(driver);
	   //Specify the timout of the wait
	   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
	   //Sepcify polling time
	   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
	   //Specify what exceptions to ignore
	   wait.ignoring(NoSuchElementException.class);
	   wait.ignoring(StaleElementReferenceException.class);
	   
   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
   productdetail.closeoffer();
   log.info("Closing the offer modal");

   Header websiteheader = new Header(driver);
   CartSlider cart = new CartSlider(driver);
   
   websiteheader.mattHeader();
   log.info("Clicked on Mattress header option");
   
   wait.until(ExpectedConditions.visibilityOf(websiteheader.hybridLatexMattressMenu()));
   websiteheader.hybridLatexMattressMenu().click();
   log.info("Clicked on Latex Mattress menu option");
   
   productdetail.queenCategory().click();
   log.info("Clicked on Queen category option");
   
   LatexMattress latexMattressproduct = new LatexMattress(driver);
   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
   log.info("Scroll to cross selling product section");
   
   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
   //productdetail.sizeDropdown().click();
   log.info("Clicked on sizedropdown field");
   
   LatexMattress latexmattressproduct = new LatexMattress(driver);
   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", latexmattressproduct.queenLatex78x60x6());
   //latexmattressproduct.singleLatex72x36x6().click();
   log.info("Clicked on one size option from the dropdown");
   
   latexMattressproduct.addToCart();
   log.info("Clicked on add to cart button");
   
   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
   productdetail.closeoffer();
   log.info("Closing the offer modal");
	
    wait.until(ExpectedConditions.visibilityOf(cart.secureCheckout()));
   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.secureCheckout());
   //cart.secureCheckout().click();
   log.info("Clicked on Secure checkout button");
   
   Thread.sleep(2000);
   CheckoutPage Checkout = new CheckoutPage(driver);
   Checkout.billingFirstName().sendKeys("Test");
   log.info("First name is entered");
   
   Checkout.billingLastName().sendKeys("sel");
   log.info("last name is entered");
   
   Checkout.billingEmail().sendKeys("Test@red.com");
   log.info("Email id is entered");
   
   Checkout.billingPhone().sendKeys("8888888888");
   log.info("Phone number is entered");
   
   Checkout.whatsappCheckbox().click();
   log.info("Notification checkbox is checked");
   
   Checkout.continueShipping().click();
   log.info("Clicked on continue to shopping button");
   
   Checkout.street().sendKeys("Street");
   log.info("Street name is entered");
   
   Checkout.house().sendKeys("House");
   log.info("House name is entered");
   
   Checkout.billing_Postcode().sendKeys("400101");
   log.info("Pincode is entered");
   
   Checkout.billing_City().sendKeys("Mumbai");
   log.info("City is added");
   
   Checkout.selectState();
   log.info("State is selected");
   
   Thread.sleep(2000);
   Actions name =new Actions(driver);
   name.moveToElement(Checkout.snapmintRadioOption()).build().perform();
   //((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", Checkout.snapmintRadioOption());
   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", Checkout.snapmintRadioOption());
   Checkout.snapmintRadioOption().click();
   log.info("Snapmint radio option is selected");
   
   Thread.sleep(2000);
   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", Checkout.Place_Order());
   //Checkout.Place_Order().click();
   log.info("Clicked on Place order button"); 
	
    Thread.sleep(3000);
    wait.until(ExpectedConditions.visibilityOf(Checkout.snapmintGateway()));
    boolean paymentGateway = Checkout.snapmintGateway().isDisplayed();
	
	if(paymentGateway) 
	{
		log.info("Snapmint payment gateway is displayed");
	}else
	{
		log.info("Snapmint payment gateway is not displayed");
	}

}

/*
 * @AfterTest public void closeDriver() throws IOException { driver.quit();
 * log.info("Driver is closed"); }
 */

}
