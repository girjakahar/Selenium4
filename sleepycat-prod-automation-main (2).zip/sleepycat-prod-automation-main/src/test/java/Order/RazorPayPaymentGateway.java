package Order;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.CheckoutPage;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.UltimaMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
public class RazorPayPaymentGateway extends BaseTest {
	
//static RemoteWebDriver driver;
static WebDriverWait wait;
public static Logger log =LogManager.getLogger(RazorPayPaymentGateway.class);


/*
 * @BeforeTest public void startingDriver() throws IOException {
 * driver=initializeChrome(); log.info("Starting driver");
 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
 * }
 */

@Test
public void razorPayPaymentGateway() throws Exception
{
	
	//driver.get(prop.getProperty("url"));
    //driver.get("https://sleepycat.in/");
    //log.info("Website opened Successfully");
  	
    wait = new WebDriverWait(driver, 10);		    	   
    //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
    ProductDetails productdetail = new ProductDetails(driver);
    productdetail.openWebsite();
     log.info("open the website");
     
   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
   productdetail.closeoffer();
   log.info("Closing the offer modal");

   Header websiteheader = new Header(driver);
   CartSlider cart = new CartSlider(driver);
   
   websiteheader.mattHeader();
   log.info("Clicked on Mattress header option");
   
   wait.until(ExpectedConditions.visibilityOf(websiteheader.ultimaMattressMenu()));
   websiteheader.ultimaMattressMenu().click();
   log.info("Clicked on Ultima Mattress menu option");

   wait.until(ExpectedConditions.visibilityOf(productdetail.singleCategory()));
   UltimaMattress ultimaMattress = new UltimaMattress(driver);
   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
   log.info("Scroll to cross selling product section");
   
   //productdetail.sizeDropdown().click();
   //log.info("Clicked on sizedropdown field");
   
   //ultimaMattress.singleUltima72x36x8().click();
   //log.info("Clicked on one size option from the dropdown");
	
   ultimaMattress.defaultAddToCart();
   log.info("Clicked on add to cart button");   
	
   Thread.sleep(2000);
   wait.until(ExpectedConditions.visibilityOf(cart.secureCheckout()));
   cart.secureCheckout().click();
   log.info("Clicked on Secure checkout button");
   
   Thread.sleep(2000);
   CheckoutPage Checkout = new CheckoutPage(driver);
   Checkout.billingFirstName().sendKeys("Test");
   log.info("First name is entered");
   
   Checkout.billingLastName().sendKeys("sel");
   log.info("last name is entered");
   
   Checkout.billingEmail().sendKeys("Test@red.com");
   log.info("Email id is entered");
   
   Checkout.billingPhone().sendKeys("8888888888");
   log.info("Phone number is entered");
   
   Checkout.whatsappCheckbox().click();
   log.info("Notification checkbox is checked");
   
   Checkout.continueShipping().click();
   log.info("Clicked on continue to shopping button");
   
   Checkout.street().sendKeys("Street");
   log.info("Street name is entered");
   
   Checkout.house().sendKeys("House");
   log.info("House name is entered");
   
   Checkout.billing_Postcode().sendKeys("400101");
   log.info("Pincode is entered");
   
   Checkout.billing_City().sendKeys("Mumbai");
   log.info("City is added");
   
   Checkout.selectState();
   log.info("State is selected");
   
   Thread.sleep(2000);
   Checkout.Place_Order().click();
   log.info("Clicked on Place order button");
   
   Thread.sleep(6000);
   WebElement iframe1=driver.findElement(By.xpath("(//*[@class='razorpay-checkout-frame'])[2]"));
   wait.until(ExpectedConditions.visibilityOf(Checkout.razorpayFrame()));
   driver.switchTo().frame(Checkout.razorpayFrame());
   log.info("Switching to Razorpay Frame");
	
    wait.until(ExpectedConditions.visibilityOf(Checkout.razorpayFrame()));
    boolean paymentGateway = Checkout.razorpayFrame().isDisplayed();
	
	if(paymentGateway) 
	{
		log.info("Razorpay is displayed");
	}else
	{
		log.info("Razorpay is not displayed");
	}

}

/*
 * @AfterTest public void closeDriver() throws IOException { driver.quit();
 * log.info("Driver is closed"); }
 */

}
