package Order;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class CrossSellingProductsInCart extends BaseTest {
	
	static WebDriverWait wait;
	//static RemoteWebDriver driver;
	public static Logger log =LogManager.getLogger(CrossSellingProductsInCart.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	@Test
	public void crossSellingProductsInCart() throws Exception
	{
		
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	  //wait = new WebDriverWait(driver, 10);
	  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	  
	   //Declare and initialise a fluent wait
	   FluentWait wait = new FluentWait(driver);
	   //Specify the timout of the wait
	   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
	   //Sepcify polling time
	   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
	   //Specify what exceptions to ignore
	   wait.ignoring(NoSuchElementException.class);
	   wait.ignoring(StaleElementReferenceException.class);
	   
	  productdetail.closeoffer();
	  log.info("Closing the offer modal");
       
	   Header websiteheader = new Header(driver);
  	   CartSlider cart = new CartSlider(driver);
       
	   wait.until(ExpectedConditions.visibilityOf(websiteheader.cartIcon()));
  	   websiteheader.cartIcon().click();
  	   log.info("Clicked on Cart icon");
	    
  	   Thread.sleep(1000);
	   wait.until(ExpectedConditions.visibilityOf(cart.crossSellFittedBedSheetCategoryFieldInCartSlider()));
	   cart.crossSellFittedBedSheetCategoryFieldInCartSlider().click();
	   log.info("Click on category field of Fitted bed sheet");
	   
	   wait.until(ExpectedConditions.visibilityOf(cart.crossSellFittedBedSheetKingCategoryFieldInCartSlider()));
	   cart.crossSellFittedBedSheetKingCategoryFieldInCartSlider().click();
	   log.info("Click on King category field of Fitted bed sheet");
	   
	   cart.crossSellFittedBedSheetCategoryFieldInCartSlider().click();
	   log.info("Click again on category field of Fitted bed sheet");
	   
	   wait.until(ExpectedConditions.visibilityOf(cart.crossSellFittedBedSheetQueenCategoryFieldInCartSlider()));
	   cart.crossSellFittedBedSheetQueenCategoryFieldInCartSlider().click();
	   log.info("Click on Queen category field of Fitted bed sheet");
	   
	   wait.until(ExpectedConditions.visibilityOf(cart.crossSellFittedBedSheetButterScoutchCreamColorInCartSlider()));
	   cart.crossSellFittedBedSheetButterScoutchCreamColorInCartSlider().click();
	   log.info("Click on ButterScoutchCream color option for fitted bed sheet");
	   
	   cart.crossSellFittedBedSheetTwilightBlueColorInCartSlider().click();
	   log.info("Click on Twilight Blue color option for fitted bed sheet");
	   
	   cart.crossSellFittedBedSheetDolphinGrayColorInCartSlider().click();
	   log.info("Click on Dolphin Gray color option for fitted bed sheet");
	   
	   cart.crossSellAddToCartButtonForQueenFittedBedSheetDolphinGrayInCartSlider().click();
	   log.info("Click on Dolphin Gray color Queen category Add to cart button for fitted bed sheet");
	   
	    Thread.sleep(1000);
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellCartCloudPillowCategoryFieldInCartSlider());
	   cart.crossSellCartCloudPillowCategoryFieldInCartSlider().click();
	   log.info("Click on category field of Cloud pillow");
	   
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellPresidentCategoryCloudPillowInCartSlider());
	   cart.crossSellPresidentCategoryCloudPillowInCartSlider().click();
	   log.info("Click on President category field of Cloud pillow");
	   
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellPackFieldOfCloudPillowInCartSlider());
	   cart.crossSellPackFieldOfCloudPillowInCartSlider().click();
	   log.info("Click on Pack field of Cloud Pillow");
	   
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellPackFourOfCloudPillowInCartSlider());
	   cart.crossSellPackFourOfCloudPillowInCartSlider().click();
	   log.info("Click on pack of Four field of Cloud pillow");
	   
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.presidentCategoryCloudPillow32x20SetOfFourProductAddedInCart());
	   cart.crossSellAddToCartButtonForPresidentPackOfFourCloudPillowInCartSlider().click();
	   log.info("Click on Add to cart button for Cloud pillow when category is President");
	   
	   //Thread.sleep(2000);
	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	   productdetail.closeoffer();
	   log.info("Closing the offer modal");
	   
	   //wait.until(ExpectedConditions.visibilityOf(websiteheader.cartIcon()));
	   //websiteheader.cartIcon().click();
	   //log.info("Clicked on Cart icon");
	   
	   Thread.sleep(1000);
	   cart.nextCrossProduct().click();
	   log.info("Click on Next product icon in cart slider");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellSoftTouchMemoryPillowPackFieldInCartSlider());
	   //cart.crossSellSoftTouchMemoryPillowPackFieldInCartSlider().click();
	   log.info("Click on Pack field of SoftTouch Memory Pillow");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellSoftTouchMemoryPillowPackOfFourInCartSlider());
	   //cart.crossSellSoftTouchMemoryPillowPackOfFourInCartSlider().click();
	   log.info("Click on Pack of Four option for SoftTouch memory pillow product");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellSoftTouchAddToCartStandardMemoryPillowPackOfFourInCartSlider());
	   //cart.crossSellAddToCartButtonForContourSoftTouchPillowPackOfFour().click();
	   log.info("Click on Add to cart button of SoftTouch memory pillow product when pack is 4 and category is Standard");
	   
	   Thread.sleep(1000);
	   cart.nextCrossProduct().click();
	   log.info("Click on Next product icon in cart slider");
 
	   wait.until(ExpectedConditions.visibilityOf(cart.crossSellComforterCoffeeColorInCartSlider()));
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellComforterCoffeeColorInCartSlider());
	   //cart.crossSellComforterCoffeeColorInCartSlider().click();
	   log.info("Click on Coffee Color option for comforter");
	   
	   Thread.sleep(1000);
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellComforterCategoryFieldInCartSlider());
	   //cart.crossSellComforterCategoryFieldInCartSlider().click();
	   log.info("Click on category field of comforter");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellDoubleCategoryComforterInCartSlider());
	   //cart.crossSellDoubleCategoryComforterInCartSlider().click();
	   log.info("Click on double category field of comforter");
   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellComforterCoffeeColorInCartSlider());
     //cart.crossSellComforterCoffeeColorInCartSlider().click();
	   log.info("Click on Coffee Color option for comforter");

	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", cart.crossSellAddToCartButtonForDoubleCategoryCoffeeComforterInCartSlider());
	   //cart.crossSellAddToCartButtonForDoubleCategoryCoffeeComforterInCartSlider().click();
	   log.info("Clicked on Add to cart button for comforter when categpry is double and color is coffee");
	   
	   wait.until(ExpectedConditions.visibilityOf(cart.doubleCategoryCoffeColorComforterProductAddedInCart()));
	   boolean productname = cart.doubleCategoryCoffeColorComforterProductAddedInCart().isDisplayed();
		
		if(productname) 
		{
			log.info("All Cross selling product avilable in cart slider is added in cart");
		}else
		{
			log.info("All Cross selling product avilable in cart slider is Not added in cart");
		}
   

}
    
/*
 * @AfterTest public void closeDriver() throws IOException { driver.quit();
 * log.info("Driver is closed");
 * 
 * }
 */

}
