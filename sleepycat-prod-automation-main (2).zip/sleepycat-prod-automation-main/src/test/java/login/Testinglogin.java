package login;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.Header;
import pageobject.ProductDetails;

public class Testinglogin extends BaseTest {
	
	static WebDriverWait wait;
	
	public static Logger log =LogManager.getLogger(CorrectLoginTest.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * 
	 * }
	 */
	
	@Test	
	public void correctLogin() throws Exception
	{
		
		driver.get("https://www.azafashions.com/");
		log.info("Website opened Successfully");
	
		
	      Thread.sleep(3000);
		  driver.findElementByXPath("//div[@class='close-signup']").click();
		  log.info("Closing the registration pop up");

		  driver.findElementByXPath("(//a[text()='Login'])[2]").click();
		  log.info("Click on login option");
		  
		  driver.findElementByXPath("(//input[@id='email'])[2]").sendKeys("Test@test.com");
		  log.info("Click on Email field and add the email");
		  
		  driver.findElementByXPath("//input[@id='userPass']").sendKeys("test@789");
		  log.info("Click on  password field and add the password");
		  
		  driver.findElementByXPath("//input[@class='signIn-button login-btn']").click();
		  log.info("Click on Sign in button");



	}
	
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
