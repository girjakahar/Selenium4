package mattressrecommender;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.Homepage;
import pageobject.MattressRecommender;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})


public class RetryFlowForMattressRecommender extends BaseTest {
	
	static WebDriverWait wait;
	
public static Logger log =LogManager.getLogger(RetryFlowForMattressRecommender.class);
	
/*
 * @BeforeTest public void startingDriver() throws IOException {
 * driver=initializeChrome(); log.info("Starting driver");
 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
 * }
 */
	
	@Test	
	public void retryFlowForMattressRecommender() throws Exception
	{
		
		driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      log.info("Website opened Successfully");
	      
		wait = new WebDriverWait(driver, 10);				  
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		ProductDetails productdetail = new ProductDetails(driver);
		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		   
		Homepage home = new Homepage(driver);
		MattressRecommender mattressrecommender = new MattressRecommender(driver);
		home.findMatchSection();
		log.info("Click on find your Match button");
		
		//wait.until(ExpectedConditions.visibilityOf(mattressrecommender.ageBracketEighteenToTwentyNine()));
		//mattressrecommender.ageBracketEighteenToTwentyNine().click();
		log.info("Click on Which age bracket do you fall in? option");
		
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
		
		mattressrecommender.firstNextbutton().click();
		log.info("Click on first next question button");
		
		//mattressrecommender.meMyPartnerAndKidsOption().click();
		log.info("Click on Who will be sleeping on the mattress? option");
		
		mattressrecommender.secondNextbutton().click();
		log.info("Click on Second next question button");
		
		/*
		 * Thread.sleep(3000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
		
		mattressrecommender.nightSweatsOption().click();
		log.info("Click on Which of these keeps you up at night? option");
		
		mattressrecommender.thirdNextbuttonOption().click();
		log.info("Click on Third next question button");
		
		/*
		 * productdetail.closeoffer(); log.info("Closing the offer modal");
		 */
		
		//mattressrecommender.cottonMattressOption().click();
		log.info("Click on Which type of mattress do you currently use? option");
		
		mattressrecommender.fourthNextbutton().click();
		log.info("Click on Fourth next question button");
		
		//mattressrecommender.softAsAHotelBedOption().click();
		log.info("Click on How soft or firm would you like your mattress? option");
		
		mattressrecommender.fifthNextbuttonOption().click();
		log.info("Click on fifth next question button");
		
		//mattressrecommender.sideOption().click();
		log.info("Click on What’s your favorite sleeping position? option");
		
		mattressrecommender.submit().click();
		log.info("Click on Submit button");
		
		Thread.sleep(3000);
	    log.info(driver.getCurrentUrl());
		
		//mattressrecommender.retryLinkForMattressRecommender();
		log.info("Clicked on retry link option");
		
	    log.info(driver.getCurrentUrl());
	     
	     Assert.assertEquals(driver.getCurrentUrl(),"https://sleepycat.in/mattress-recommender" );
	     			
	}

	/*
	 * @AfterTest public void close() { driver.quit(); log.info("Driver is closed");
	 * }
	 */

}
