package mattressrecommender;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.Homepage;
import pageobject.MattressRecommender;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class OriginalMattressSuggestion extends BaseTest {
	
	static WebDriverWait wait;
	
public static Logger log =LogManager.getLogger(OriginalMattressSuggestion.class);
	
/*
 * @BeforeTest public void startingDriver() throws IOException {
 * driver=initializeChrome(); log.info("Starting driver");
 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
 * }
 */
	
	@Test	
	public void originalMattressSuggestion() throws Exception
	{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	      
		//wait = new WebDriverWait(driver, 10);				  
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	      
	    //Declare and initialise a fluent wait
		   FluentWait wait = new FluentWait(driver);
		   //Specify the timout of the wait
		   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		   //Sepcify polling time
		   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		   //Specify what exceptions to ignore
		   wait.ignoring(NoSuchElementException.class);
		   wait.ignoring(StaleElementReferenceException.class);
		   
		//Thread.sleep(3000);
		//wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		productdetail.closeoffer();
		log.info("Closing the offer modal");
		   
		Header websiteHeader = new Header(driver);  	   
		websiteHeader.mattHeader();
	  	log.info("All Mattress menu is opened");
	  	   
	 	wait.until(ExpectedConditions.visibilityOf(websiteHeader.mattressRecommenderMenu()));
	 	websiteHeader.mattressRecommenderMenu().click();
		log.info("Click on Mattress Recommender menu and open this page");
		   
		Homepage home = new Homepage(driver);
	  	CartSlider cart = new CartSlider(driver);
		MattressRecommender mattressrecommender = new MattressRecommender(driver);
		mattressrecommender.betweenThirtyAndFourtyFive().click();
		log.info("Click on between Thirty And Fourty Five option for Where do you fall on the age meter? question");
		
		Thread.sleep(2000);
		mattressrecommender.firstNextbutton().click();
		log.info("Click on first next question button");
		
		//Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.goodolCoirOrCottonOption()));
		mattressrecommender.goodolCoirOrCottonOption().click();
		log.info("Click on Good coir cotton option for What type of mattress you are using currently? question");
		
		Thread.sleep(2000);
		mattressrecommender.secondNextbutton().click();
		log.info("Click on Second next question button");
		
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.achesAndPainsOption()));
		mattressrecommender.achesAndPainsOption().click();
		log.info("Click on aches And Pains Option for Tired of counting sheep & still no sleep? Tell us why. question");

		Thread.sleep(2000);
		mattressrecommender.thirdNextbuttonOption().click();
		log.info("Click on Third next question button");
		
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.keepsChangingOption()));
		mattressrecommender.keepsChangingOption().click();
		log.info("Click on the keeps Changing Option for Which position are you often found sleeping in? question");

		Thread.sleep(2000);
		mattressrecommender.fourthNextbutton().click();
		log.info("Click on Fourth next question button");
		
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.comfortAndSupportOption()));
		mattressrecommender.comfortAndSupportOption().click();
		log.info("Click on Comfy and Support option for Picture your dream mattress. How does it feel? * question");
		
		Thread.sleep(2000);
		mattressrecommender.fifthNextbuttonOption().click();
		log.info("Click on Fifth next question button");
		
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.mediumSoftOption()));
		mattressrecommender.mediumSoftOption().click();
		log.info("Click on medium Soft Option for Finally, what's your mattress type? * question");
		
		Thread.sleep(2000);
		mattressrecommender.submit().click();
		log.info("Click on Submit button");
		
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.enterEmailField()));
		mattressrecommender.enterEmailField().sendKeys("Test@test.com");
		log.info("Click on Enter Email field and enter the email id");
		
		Thread.sleep(2000);
		mattressrecommender.signUpButton().click();
		log.info("Click on Signup Button");
		
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.originalMattressAddToCartButton()));
		mattressrecommender.originalMattressAddToCartButton().click();
		log.info("Click on Default add to cart button on Mattress Recommnder Result page");
		
		wait.until(ExpectedConditions.visibilityOf(mattressrecommender.itemAddedToCartMessage()));
		websiteHeader.cartIcon().click();
	  	log.info("Clicked on Cart icon");
		
		wait.until(ExpectedConditions.visibilityOf(cart.originalMattressProductAddedInCartSlider()));
		boolean mattresssuggestion = cart.originalMattressProductAddedInCartSlider().isDisplayed();
		   
		  if(mattresssuggestion) 
			{
				log.info("Original mattress Product is recommended and is added in cart slider");
			}else
			{
				log.info("Original mattress Product is recommended but it is not added in cart slider");
			}
	     			
	}

	/*
	 * @AfterTest public void close() { driver.quit(); log.info("Driver is closed");
	 * }
	 */

}
