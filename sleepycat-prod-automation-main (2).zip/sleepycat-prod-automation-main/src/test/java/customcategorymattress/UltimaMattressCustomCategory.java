package customcategorymattress;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.UltimaMattress;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class UltimaMattressCustomCategory extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(UltimaMattressCustomCategory.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void ultimaMattessCustomAddToCart() throws Exception
	{
    	
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
       //Thread.sleep(3000);
	   productdetail.closeoffer();
	   log.info("Closing the offer modal");
  	   CartSlider cart = new CartSlider(driver);   

   	   Header websiteHeader = new Header(driver);  	   
   	   websiteHeader.mattHeader();
	   log.info("Clicked on Mattress header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.ultimaMattressMenu()));
	   websiteHeader.ultimaMattressMenu().click();
	   log.info("Clicked on Ultima Mattress menu option");
 	   
	   UltimaMattress plusmattressproduct = new UltimaMattress(driver);
	   JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].click();", productdetail.customCategory());
	   
	   //productdetail.customCategory().click();
	   log.info("Clicked on Custom category option");
	   
	   productdetail.customLength().sendKeys("90");
	   log.info("Length value is entered");
	   
	   Thread.sleep(1000);
  	   boolean lengthvalidation =productdetail.lenghtError().isDisplayed();
  	   if(lengthvalidation) 
  	   {  
	      log.info("Incorrect length value added message is displyed");
  	   }else 
  	   {
 	      log.info("Incorrect length value is added message is not displyed");
  	   }
  	   
  	   productdetail.customLength().clear();
	   log.info("Length value added is removed");
	   
	   //Thread.sleep(2000);
	   productdetail.customLength().sendKeys("77");
	   log.info("Length value is entered again");	   
	   
	   productdetail.customWidth().sendKeys("75");
	   log.info("Width value is entered");
	   
	   Thread.sleep(1000);
  	   boolean widthvalidation =productdetail.widthError().isDisplayed();
  	   if(widthvalidation) 
  	   {  
	      log.info("Incorrect Width value added message is displyed");
  	   }else 
  	   {
 	      log.info("Incorrect Width value is added message is not displyed");
  	   } 
	  
  	   productdetail.customWidth().clear();
	   log.info("Width value added is removed");

	   //Thread.sleep(2000);
	   productdetail.customWidth().sendKeys("60");
	   log.info("Width value is entered again");
	    
		/*
		 * Actions Scrolltotext = new Actions(driver);
		 * Scrolltotext.moveToElement(productdetail.frequentlyText()).build().perform();
		 * log.info("Move to Frequently bought text");
		 */
	   
		/*
		 * Thread.sleep(3000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.checkPincodeButton());
	   //productdetail.quantityselect();
	   //log.info("Scroll to quantity field");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to Three");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to two");
	   
	   Thread.sleep(1000);
	   plusmattressproduct.defaultAddToCart();
	   log.info("Clicked on add to cart button");
	   
	   Thread.sleep(2000);
	   wait.until(ExpectedConditions.visibilityOf(cart.customCategoryUltimaProduct78x60x8AddedInCart()));
	   boolean productname = cart.customCategoryUltimaProduct78x60x8AddedInCart().isDisplayed();
	   
	if(productname) 
		{
			log.info("Custom Category Ultima Mattress Product is added in cart");
		}else
		{
			log.info("Custom Category Ultima Mattress Product is not added in cart");
		}	
	   
	}
    
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
