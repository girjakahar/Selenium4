package productdetailpage;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import addtocartproducts.OriginalMattressChangeMultipleOption;
import base.BaseTest;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class VideoSectionOnProductDetailsPage extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(VideoSectionOnProductDetailsPage.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void videoSectionforOriginalMattress() throws Exception
	{
    	
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
        //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	   //Thread.sleep(3000);
       productdetail.closeoffer();
       log.info("Closing the offer modal");
  	   
  	   Header websiteHeader = new Header(driver);
  	   websiteHeader.originalMattressProduct();
	   log.info("Original mattress product details page is opened");
	   
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
	   
	   OriginalMattress originalmattressproduct = new OriginalMattress(driver);
	   WebElement videoimg = driver.findElementByXPath("//div[@class='yt-lazyload-wrap']//a");
       wait.until(ExpectedConditions.visibilityOf(videoimg));   
       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", videoimg);
       //videoimg.click();
	   log.info("Clicked on Fifth video image option");
	   
		/*
		 * WebElement playvideoicon =
		 * driver.findElementByXPath("(//ul[@class='lSPager lSpg']//li[5])[2]");
		 * wait.until(ExpectedConditions.visibilityOf(playvideoicon));
		 * playvideoicon.click(); log.info("Clicked on Play video icon option");
		 */
	   
	   driver.switchTo().frame("product-video-slide-1");
	   log.info("Switching to video frame");
	   
		/*
		 * driver.switchTo().parentFrame(); log.info("Switching to parent frame");
		 * 
		 * Thread.sleep(2000);
		 * wait.until(ExpectedConditions.visibilityOf(productdetail.doubleCategory()));
		 * //productdetail.cmDimension().click();
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * productdetail.doubleCategory()); log.info("Clicked on double category");
		 */


	   WebElement playedvideo = driver.findElementByXPath("(//div[@class='html5-video-container']/video)[1]");
       wait.until(ExpectedConditions.visibilityOf(playedvideo));   
		//Thread.sleep(2000); 
		boolean videodisplayed = playedvideo.isDisplayed();
		
		if(videodisplayed) 
		{
			log.info("Original mattress product video is playing successfully ");
		}else
		{
			log.info("Original mattress product video is not playing ");
		}
		
		driver.switchTo().parentFrame();
		log.info("Switching to parent frame");
		   
	   Thread.sleep(2000); 
       wait.until(ExpectedConditions.visibilityOf(productdetail.doubleCategory()));   
	   //productdetail.cmDimension().click();
       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.doubleCategory());
	   log.info("Clicked on double category");

	   
	}
    
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
