package productdetailpage;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class MattressSizeguideAndChartImage extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(MattressSizeguideAndChartImage.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	 
	
    @Test
	public void mattressSizeChartHandling() throws Exception
	{
    	
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
      //Thread.sleep(3000);
      productdetail.closeoffer();
      log.info("Closing the offer modal");
	  
      Header websiteheader = new Header(driver);
      websiteheader.originalMattressProduct();
	  log.info("Original mattress product details page is opened");
	  
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
	  
	   productdetail.MattressSizeGuideLinkText().click();
	   log.info("Clicked on size guide link text on product details page");
	   
	   Thread.sleep(1000); 
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   js.executeScript("window.scrollBy(0,250)", "");
	   
	    wait.until(ExpectedConditions.visibilityOf(productdetail.mattressSizeGuideImage()));
		boolean sizeguideimage = productdetail.mattressSizeGuideImage().isDisplayed();

		if(sizeguideimage) 
		{
			log.info("Mattress Size Guide image is displayed");
		}else
		{
			log.info("Mattress Size Guide image is not displayed");
		}
		
} 
	
/*
 * @AfterTest public void closeDriver() throws IOException { driver.quit();
 * log.info("Driver is closed");
 * 
 * }
 */

}
