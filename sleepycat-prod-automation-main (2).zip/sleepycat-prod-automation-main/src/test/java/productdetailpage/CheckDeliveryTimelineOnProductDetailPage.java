package productdetailpage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.Header;
import pageobject.ProductDetails;
import pageobject.UltimaMattress;

@Test(groups= {"SanityTest","RegressionTest"})

public class CheckDeliveryTimelineOnProductDetailPage extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(CheckDeliveryTimelineOnProductDetailPage.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	 
	
    @Test
	public void checkDeliveryTimelineOnProductDetailPageTestCase() throws Exception
	{
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
  	  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
  	  productdetail.closeoffer();
  	  log.info("Closing the offer modal");
         
  	   Header websiteheader = new Header(driver);
	   UltimaMattress ultimamattressproduct = new UltimaMattress(driver);

  	   websiteheader.mattHeader();
	   log.info("Clicked on Mattress header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteheader.ultimaMattressMenu()));
	   websiteheader.ultimaMattressMenu().click();
	   log.info("Clicked on Ultima Mattress menu option");
	   
	   Actions move =new Actions(driver);
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.checkPincodeButton());
	   //move.moveToElement(productdetail.checkPincodeButton()).build().perform();
	   log.info("Scrolled down to size selection section");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   //productdetail.sizeDropdown().click();
	   log.info("Clicked on sizedropdown field");
	   
	   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");
	   //ultimamattressproduct.singleUltima72x36x8().click();
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimamattressproduct.singleUltima72x36x8());
	   log.info("Clicked on one size option from the dropdown");
	    
	   wait.until(ExpectedConditions.visibilityOf(productdetail.singleCategory()));
	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   productdetail.enterPincodeField().sendKeys("400101");
	   log.info("Entering correct pincode on check delivery timeline field");
	   
	   productdetail.checkPincodeButton().click();
	   log.info("click on check delivery timeline button");
	
		wait.until(ExpectedConditions.visibilityOf(productdetail.deliveryTimelineMessage()));
		boolean deliveyTimeline = productdetail.deliveryTimelineMessage().isDisplayed();

		if(deliveyTimeline) 
		{
			log.info("Delivery Timeline message is displayed");
		}else
		{
			log.info("Delivery Timeline message is not displayed");
		}		
		
	} 
	
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */



}
