package productdetailpage;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.LinkVerification;
import base.BaseTest;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class BestSellerProductsOnPlusMattressProductDetailsPage extends BaseTest {
	
	static WebDriverWait wait;

	public static Logger log = LogManager.getLogger(BestSellerProductsOnPlusMattressProductDetailsPage.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException { driver =
	 * initializeChrome(); log.info("Starting driver"); }
	 */

	@Test(priority=1)	
	public void originalMattressProductDetailLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
		
		wait = new WebDriverWait(driver, 10);		    	   
	    //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	    ProductDetails productdetail = new ProductDetails(driver);
        wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	    //Thread.sleep(3000);
	    productdetail.closeoffer();
	    log.info("Closing the offer modal");
	    
	   Header websiteheader = new Header(driver);
	   //websiteheader.plusMattressProduct();
	   log.info("Plus mattress product details page is opened");
	   
	    productdetail.originalMattressInBestSellerProductSection();
	    log.info("Scroll to Original mattress in Shop from our best seller section");

	    Thread.sleep(1000);
	    productdetail.originalMattressShopNowButton().click();
	    log.info("Click on Shop Now button");

		String mattressurl = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(mattressurl);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=2)	
	public void memoryPillowProductDetailLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
	    
	   ProductDetails productdetail = new ProductDetails(driver);
	   Header websiteheader = new Header(driver);
	   //websiteheader.plusMattressProduct();
	   log.info("Plus mattress product details page is opened");
	   
	    productdetail.memoryFoamPillowInBestSellerProductSection();
	    log.info("Scroll to memory Foam Pillow in Shop from our best seller section");

	    Thread.sleep(1000);
	    productdetail.memoryFoamPillowShopNowButton().click();
	    log.info("Click on Shop Now button");

		String mattressurl = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(mattressurl);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=3)	
	public void reversibleComforterProductDetailLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
	    
	   ProductDetails productdetail = new ProductDetails(driver);
	   Header websiteheader = new Header(driver);
	   //websiteheader.plusMattressProduct();
	   log.info("Plus mattress product details page is opened");
	   
	    productdetail.reversibleComforterInBestSellerProductSection();
	    log.info("Scroll to Reversible Comforter in Shop from our best seller section");

	    Thread.sleep(1000);
	    productdetail.reversibleComforterShopNowButton().click();
	    log.info("Click on Shop Now button");

		String mattressurl = driver.getCurrentUrl();
		log.info("Fetching the current url");

		LinkVerification response = new LinkVerification(driver);
		response.verifyLinkActive(mattressurl);
		log.info("checking the response code for the opened url");

	}
	
	@Test(priority=4)	
	public void cloudPillowProductDetailLink() throws Exception 
	{						  
		driver.get(prop.getProperty("url"));
		log.info("Website opened Successfully");
		
		ProductDetails productdetail = new ProductDetails(driver);
	    Header websiteheader = new Header(driver);
	    //websiteheader.plusMattressProduct();
		log.info("Plus mattress product details page is opened");
		   
        productdetail.cloudPillowInBestSellerProductSection();
	    log.info("Scroll to Cloud Pillow in Shop from our best seller section");

	    Thread.sleep(1000);
	    productdetail.cloudPillowShopNowButton().click();
	    log.info("Click on Shop Now button");

	    String mattressurl = driver.getCurrentUrl();
	    log.info("Fetching the current url");

	    LinkVerification response = new LinkVerification(driver);
	    response.verifyLinkActive(mattressurl);
	    log.info("checking the response code for the opened url");

	}
	
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
