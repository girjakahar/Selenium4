package addtocartproducts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.AllPillowsProductsListingPage;
import pageobject.CartSlider;
import pageobject.ContourMemoryFoamPillow;
import pageobject.Header;
import pageobject.Homepage;
import pageobject.PillowsPage;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class ContourCoolTecMemoryFoamPillowProductDetailsChanges extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(ContourCoolTecMemoryFoamPillowProductDetailsChanges.class);

	
	
	    @Test
		public void conTourCoolTecMemoryFoamPillowAddToCart() throws Exception
		{
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
			      
		  	   //wait = new WebDriverWait(driver, 10);		  
		       //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
			   
			 //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
			   
		 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		       productdetail.closeoffer();
			   log.info("Closing the offer modal");

		  	   CartSlider cart = new CartSlider(driver);   
		  	   Header websiteheader = new Header(driver);
		  	   Homepage home = new Homepage(driver);
		  	   AllPillowsProductsListingPage allpillowslisting = new AllPillowsProductsListingPage(driver);
		  	   
		  	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", home.pillowsCategory());
	  	   home.pillowsCategoryInSleepCategorySection();
		   log.info("Clicked on Pillows category image on home page");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", allpillowslisting.conTourCoolTecMemoryFoamPillowShopNowButton());
	  	   //allpillowslisting.conTourCoolTecMemoryFoamPillowShopNowButton().click();
	  	   log.info("Clicked on Shop now button of ConTour CoolTec Memory Foam pillow Shop Now Button");
	  	   
	  	   //allpillowslisting.conTourCoolTecMemoryFoamPillowShopNowButton().click();
	  	   //log.info("Clicked on Shop now button of ConTour CoolTec Memory Foam pillow Shop Now Button");
	  	   
	  	 productdetail.switchingToChildWindow();
         log.info("Switching to child window");
         
		   //productdetail.scrollToAddToCart();
		   //log.info("Scroll to add to cart button");
		   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()))
			 * ; productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
		   
           ContourMemoryFoamPillow memoryFoamPillowproduct = new ContourMemoryFoamPillow(driver);
		   JavascriptExecutor js = (JavascriptExecutor) driver;
		   js.executeScript("arguments[0].click();", memoryFoamPillowproduct.onePillowPackSize());
		   log.info("Clicked on One Pillow pack size option");

		   js.executeScript("arguments[0].click();", memoryFoamPillowproduct.twoPillowPackSize());
		   log.info("Clicked on Two Pillow pack size option");
		   
		   js.executeScript("arguments[0].click();", memoryFoamPillowproduct.onePillowPackSize());
		   log.info("Clicked again on One Pillow pack size option");
			 
		   //js.executeScript("arguments[0].click();", memoryFoamPillowproduct.fourPillowPackSize());
		   //memoryFoamPillowproduct.fourPillowPackSize().click();
		   //log.info("Clicked on Four Pillow pack size option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.checkPincodeButton());
		  //((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");
		   //productdetail.quantityselect();
		   //log.info("Selected one quantity from quantity dropdown");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
		   
		      //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer())); 
		      productdetail.closeoffer(); 
		      log.info("Closing the offer modal");
		   
		      ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.personalizeNameSection());
			   log.info("Scroll to personalize section");
			   
			  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.personalizeNameSection());
			  //productdetail.personalizeNameSection().click();
			  log.info("Clicked on personalize Name Section");
			  
			  Actions name =new Actions(driver);
			  name.moveToElement(productdetail.personalizeNameField()).build().perform();
			  log.info("Move to name field");
			  
			  productdetail.personalizeNameField().sendKeys("TE");
			  log.info("Entered the name in name field");
			  
			  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.stitchButton());
			  //productdetail.stitchButton().click(); 
			  log.info("Clicked on Stitch button");
			 
		   
		   js.executeScript("arguments[0].click();", memoryFoamPillowproduct.conTourCoolTecPillowAddToCartButton());
		   //memoryFoamPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   wait.until(ExpectedConditions.visibilityOf(cart.contourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart())); 
		   boolean productname = cart.contourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart().isDisplayed();
		   
			if(productname) 
			{
				log.info("Contour category CoolTecMemory Foam Pillow pack of 1 Product is added in cart");
			}else
			{
				log.info("Contour category CoolTecMemory Foam Pillow pack of 1 Product is not added in cart");
			}	
		}

}
