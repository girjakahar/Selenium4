package addtocartproducts;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.AdjustablePillow;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class AdjustablePillowProductDetailsChanges extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(AdjustablePillowProductDetailsChanges.class);

	
	 @Test
		public void adjustablePillowAddToCart() throws Exception
		{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	       
	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
      productdetail.closeoffer();
	   log.info("Closing the offer modal");

 	   CartSlider cart = new CartSlider(driver);   
 	   Header websiteheader = new Header(driver);
 	   websiteheader.pillowHeader();
 	   log.info("pillow menu is opened");
		   	   
		   AdjustablePillow adjustablePillow = new AdjustablePillow(driver);
		   JavascriptExecutor js = (JavascriptExecutor) driver;
		   
		   js.executeScript("arguments[0].click();", websiteheader.adjustablePillowMenu());
		   log.info("Clicked on Adjustable pillow menu option");
			 
		   js.executeScript("arguments[0].click();", adjustablePillow.twoPillowPackSize());
		   //hybridPillowproduct.twoPillowPackSize().click();
		   log.info("Clicked on Two Pillow pack size option");
		   
		   js.executeScript("arguments[0].click();", adjustablePillow.onePillowPackSize());
		   //hybridPillowproduct.onePillowPackSize().click();
		   log.info("Clicked on one Pillow pack size option");
		   
		   js.executeScript("arguments[0].click();", adjustablePillow.twoPillowPackSize());
		   //hybridPillowproduct.twoPillowPackSize().click();
		   log.info("Clicked on Two Pillow pack size option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		   productdetail.quantityselect();
		   log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", adjustablePillow.adjustablePillowAddToCartButton());
		   //adjustablePillow.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryAdjustablePillowPackOfTwoProductAddedInCart()));
		   boolean productname = cart.standardCategoryAdjustablePillowPackOfTwoProductAddedInCart().isDisplayed();
		   
			if(productname) 
			{
				log.info("Standard category Adjustable Pillow pack of Two Product is added in cart");
			}else
			{
				log.info("Standard category Adjustable Pillow pack of Two Product is not added in cart");
			}	
		}

}
