package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.PillowCase;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class PillowCaseProductDetailsChanges extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(PillowCaseProductDetailsChanges.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void pillowCaseAddToCart() throws Exception
		{
		 
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	 	   
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");

		   CartSlider cart = new CartSlider(driver);
		   Header websiteheader = new Header(driver);
		   websiteheader.beddingHeader();
		   log.info("Clicked on Bedding header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.pillowCaseMenu()));
		   websiteheader.pillowCaseMenu().click();
		   log.info("Clicked on pillowCase Menu option");
		   
		   PillowCase pillowCaseproduct = new PillowCase(driver);		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.presidentPillowCaseCategory());
		   //pillowCaseproduct.memoryFoamPillowCaseCategory().click();
		   log.info("Clicked on President Pillow Case category option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.cuddlePillowCaseCategory());
		   //pillowCaseproduct.memoryFoamPillowCaseCategory().click();
		   log.info("Clicked on Cuddle Pillow Case category option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.standardPillowCaseCategory());
		   //pillowCaseproduct.memoryFoamPillowCaseCategory().click();
		   log.info("Clicked on Standard Pillow Case category option");
	
		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.butterScoutchCreamColorPillowcase()); 
		   //pillowCaseproduct.fourPillowCasesPackSize().click();
		   log.info("Clicked on ButterScoutch Cream Color option");
		   
		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.twilightBlueColorPillowcase()); 
		   //pillowCaseproduct.fourPillowCasesPackSize().click();
		   log.info("Clicked on Dolphin Gray Color option");
		   
		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.butterScoutchCreamColorPillowcase()); 
		   //pillowCaseproduct.fourPillowCasesPackSize().click();
		   log.info("Clicked on ButterScoutch Cream Color option");

		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.feetDimension()); 
		   //productdetail.feetDimension().click();
		   log.info("Clicked on Feet dimension option");
		   
		   JavascriptExecutor js = (JavascriptExecutor) driver;

		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.checkPincodeButton());
		   //productdetail.quantityselect();
		   //log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
	
		   pillowCaseproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   //Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.butterScoutchColorStandardPillowCasePackOfTwoProductAddedInCart()));
		   //boolean productname = cart.twlightBlueColorStandardPillowCasePackOfTwoProductAddedInCart().isDisplayed();
		   boolean productname = cart.butterScoutchColorStandardPillowCasePackOfTwoProductAddedInCart().isDisplayed();

			if(productname) 
			{
				log.info("Standard Pillow case pack of 2 Product is added in cart");
			}else
			{
				log.info("Standard Pillow case pack of 2 Product is not added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
