package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.PetBed;
import pageobject.ProductDetails;

@Test(groups = { "SanityTest", "RegressionTest" })
public class PetBedProductDetailsChanges extends BaseTest {

	// static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log = LogManager.getLogger(PetBedProductDetailsChanges.class);

	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */

	@Test
	public void petBedAddToCart() throws Exception {

		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	 	   
		// Thread.sleep(3000);
		productdetail.closeoffer();
		log.info("Closing the offer modal");

		 Actions move =new Actions(driver);
		CartSlider cart = new CartSlider(driver);
		Header websiteheader = new Header(driver);
		websiteheader.dogBedHeader();
		log.info("Clicked on DogBed header option");
		   
		wait.until(ExpectedConditions.visibilityOf(websiteheader.dogBedOriginalMenu()));
		websiteheader.dogBedOriginalMenu().click();
		log.info("Clicked on petBed Menu option");

		PetBed petBedproduct = new PetBed(driver);
		petBedproduct.orthopedicCategory().click();
		log.info("Clicked on orthopedic category option");
		
		petBedproduct.redColorPetBedOption().click();
		log.info("Clicked on Red Color option");

		petBedproduct.blueColorPetBedOption().click();
		log.info("Clicked on blue color option");

		productdetail.cmDimension().click();
		log.info("Clicked on cm dimension option");

		productdetail.sizeDropdown().click();
		log.info("Clicked on sizedropdown field");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		wait.until(ExpectedConditions.visibilityOf(petBedproduct.orthopedicBlueColorPetBedLarge48x24()));
		move.moveToElement(petBedproduct.orthopedicBlueColorPetBedLarge48x24()).click().build().perform();
		//petBedproduct.orthopedicBlueColorPetBedLarge48x24().click();
		log.info("Clicked on one size option from the dropdown");

		/*
		 * productdetail.quantityselect();
		 * log.info("Selected one quantity from the dropdown");
		 */

		productdetail.quantityselect();
		   log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");

		 //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer())); 
		      productdetail.closeoffer(); 
		      log.info("Closing the offer modal");

		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.personalizeNameSection());
		  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.personalizeNameSection());
		  //productdetail.personalizeNameSection().click();
		  log.info("Clicked on personalize Name Section");
		  
		  Actions name =new Actions(driver);
		  name.moveToElement(productdetail.personalizeNameField()).build().perform();
		  log.info("Move to Pet name field");
		  
		  productdetail.personalizeNameField().sendKeys("OrthoTest");
		  log.info("Enter the name in pet name field");
	  
		  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.stitchButton());
		  log.info("Clicked on Stitch button");
		 
		  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", petBedproduct.petBedAddToCartButton());

		//productdetail.defaultAddToCart();
		log.info("Clicked on add to cart button");

		/*
		 * productdetail.closeoffer(); log.info("Closing the offer modal");
		 */

		// Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(cart.orthopedicCategoryBlueColorLargePetBed48x24ProductAddedInCart()));
		boolean productname = cart.orthopedicCategoryBlueColorLargePetBed48x24ProductAddedInCart().isDisplayed();

		if (productname) {
			log.info("Personalized Orthopedic category Blue color Large Pet Bed is added in cart");
		} else {
			log.info("Personalized Orthopedic category Blue color Large Pet Bed is not added in cart");
		}
	}

	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
