package addtocartproducts;

import org.testng.annotations.Test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
public class DefaultOriginalMattressProduct extends BaseTest {
		
		//static RemoteWebDriver driver;
		static WebDriverWait wait;
		public static Logger log =LogManager.getLogger(DefaultOriginalMattressProduct.class);

		/*
		 * @BeforeTest public void startingDriver() throws IOException {
		 * driver=initializeChrome(); log.info("Starting driver");
		 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
		 * }
		 */
		 
		
	    @Test
		public void defaultOriginalMattessAddToCart() throws Exception
		{
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		       
		  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	      //Thread.sleep(3000);
	      productdetail.closeoffer();
          log.info("Closing the offer modal");
		  
		   CartSlider cart = new CartSlider(driver);
          Header websiteheader = new Header(driver);
          websiteheader.mattHeader();
		  log.info("Clicked on Mattress header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.originalMattressMenu()));
		   websiteheader.originalMattressMenu().click();
		   log.info("Clicked on Original Mattress menu option");
	  	   
		   OriginalMattress originalmattressproduct = new OriginalMattress(driver);		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
		   log.info("Clicked on select sizedropdown");
			  
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", originalmattressproduct.singleOriginal72x36x6());
		   log.info("Clicked on one size from dropdown option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   originalmattressproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
			//Thread.sleep(2000);
		    wait.until(ExpectedConditions.visibilityOf(cart.originalMattressProductAddedInCartSlider()));
			boolean productname = cart.originalMattressProductAddedInCartSlider().isDisplayed();

			if(productname) 
			{
				log.info("Single category Original mattress Product is added in cart");
			}else
			{
				log.info("Single category Original mattress Product is not added in cart");
			}	
		   
		} 
		
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */
		 
}
