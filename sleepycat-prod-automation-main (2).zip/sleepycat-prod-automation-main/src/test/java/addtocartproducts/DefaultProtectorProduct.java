package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;
import pageobject.Protector;

@Test(groups= {"RegressionTest"})
public class DefaultProtectorProduct extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultProtectorProduct.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void defaultProtectorsAddToCart() throws Exception
		{
		 
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	       
	     //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		  //Thread.sleep(3000);
		  productdetail.closeoffer();
	      log.info("Closing the offer modal");
	  	   
		   CartSlider cart = new CartSlider(driver);
	  	  Header websiteheader = new Header(driver);  
	  	   websiteheader.beddingHeader();
		   log.info("Clicked on Bedding header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.protectorMenu()));
		   websiteheader.protectorMenu().click();
		   log.info("Clicked on protector Menu option");
		  
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		  Protector protectorproductdetail = new Protector(driver);		  
		  Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		  
		  protectorproductdetail.addToCart();
		  log.info("Clicked on add to cart button");
		  
		   wait.until(ExpectedConditions.visibilityOf(cart.singleCategoryGreyColorProtector72x36ProductAddedInCart()));
		   boolean productname = cart.singleCategoryGreyColorProtector72x36ProductAddedInCart().isDisplayed();
		   //wait.until(ExpectedConditions.visibilityOf(cart.singleCategoryWhiteProtector72x36ProductAddedInCart()));
		   //boolean productname = cart.singleCategoryWhiteProtector72x36ProductAddedInCart().isDisplayed();

		  if(productname) 
			{
				log.info("Default Single category White protector Product is added in cart");
			}else
			{
				log.info("Default Single category White protector Product is added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed"); }
		 */
}
