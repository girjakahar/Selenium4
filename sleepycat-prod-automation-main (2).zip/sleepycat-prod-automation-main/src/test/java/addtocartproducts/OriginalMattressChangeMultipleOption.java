package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class OriginalMattressChangeMultipleOption extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(OriginalMattressChangeMultipleOption.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void originalMattressChangeOption() throws Exception
	{
    	
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
        //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	   //Thread.sleep(3000);
       productdetail.closeoffer();
       log.info("Closing the offer modal");
  	   
	   CartSlider cart = new CartSlider(driver);	   		 
	   Header websiteheader = new Header(driver);
  	   websiteheader.mattHeader();
	   log.info("Clicked on Mattress header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteheader.originalMattressMenu()));
	   websiteheader.originalMattressMenu().click();
	   log.info("Clicked on Original Mattress menu option");
	   
	   OriginalMattress originalmattressproduct = new OriginalMattress(driver);  	   
       wait.until(ExpectedConditions.visibilityOf(productdetail.queenCategory()));
	   productdetail.queenCategory().click();
	   log.info("Clicked on double category");
	   
	   productdetail.kingCategory().click();
	   log.info("Clicked on King category");
	   
	   productdetail.singleCategory().click();
	   log.info("Clicked back on Single category");	
	   
	   //productdetail.scrollToDefaultAddToCart();
       //log.info("Scroll to add to cart button section");
	   
		/*
		 * Thread.sleep(2000); productdetail.closeoffer();
		 * log.info("Closing offer modal");
		 */	   
  	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   //productdetail.sizeDropdown().click();
	   log.info("Clicked on sizedropdown field");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", originalmattressproduct.singleOriginal75x36x6());
	   //originalmattressproduct.singleOriginal75x36x6().click();
	   log.info("Clicked on one size option from the dropdown"); 
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   //productdetail.sizeDropdown().click();
	   log.info("Clicked on sizedropdown field again");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", originalmattressproduct.singleOriginal78x36x6());
	   //originalmattressproduct.singleOriginal78x36x6().click();
	   log.info("Clicked on one size option again from the dropdown");
	     	 
	   JavascriptExecutor js = (JavascriptExecutor) driver;

	   Thread.sleep(2000);
	   js.executeScript("arguments[0].click();",productdetail.quantityField());
	   //productdetail.quantityField().click();
	   log.info("Clicked on Quantity field");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to Three");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to two");
	   
	   //js.executeScript("arguments[0].click();",productdetail.quantityselection());
	   //productdetail.quantityselect();
	   //log.info("Selected one quantity from the dropdown");
  	   
	   js.executeScript("arguments[0].click();",originalmattressproduct.originalMattressAddToCartButton());

	   //productdetail.changedaddToCart();
	   log.info("Clicked on add to cart button"); 
	   
		//Thread.sleep(2000); 
		wait.until(ExpectedConditions.visibilityOf(cart.singleCategoryOriginalMattress78x36x6ProductAddedInCart()));
		boolean productname = cart.singleCategoryOriginalMattress78x36x6ProductAddedInCart().isDisplayed();
		
		if(productname) 
		{
			log.info("Single Category Original Mattress change option Product is added in cart");
		}else
		{
			log.info("Single Category Original Mattress change option Product is not added in cart");
		}	
	   
	}
    
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
