package addtocartproducts;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.BabyHeadPillow;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultBabyHeadPillowProduct extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultBabyHeadPillowProduct.class);
	
	    @Test
		public void defaultBabyHeadPillowAddToCart() throws Exception
		{
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		       
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	      productdetail.closeoffer();
		   log.info("Closing the offer modal");

	 	   CartSlider cart = new CartSlider(driver);   
	 	   Header websiteheader = new Header(driver);
	 	   websiteheader.babyHeader();
	 	   log.info("Click on baby menu in header");
	 	   
	 	   wait.until(ExpectedConditions.visibilityOf(websiteheader.babyHeadPillowMenu()));
	 	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteheader.babyHeadPillowMenu());
		   log.info("Clicked on Baby Head Pillow menu option ");
		   
		   BabyHeadPillow babyHeadPillowproduct = new BabyHeadPillow(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", babyHeadPillowproduct.babyHeaddPillowAddToCartButton());
		   //babyHeadPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryBabyHeadPillowProductAddedInCart()));
		   boolean productname = cart.standardCategoryBabyHeadPillowProductAddedInCart().isDisplayed();
			
			if(productname) 
			{
				log.info("Standard category Baby Head pillow product is added in cart");
			}else
			{
				log.info("Standard category Baby Head pillow product is not added in cart");
			}	
		}

}
