package addtocartproducts;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.BabyCribSheet;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultBabyCribSheetProduct extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultBabyCribSheetProduct.class);
	
	    @Test
		public void defaultBabyCribSheetAddToCart() throws Exception
		{
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		      
		    //Declare and initialise a fluent wait
			   FluentWait wait = new FluentWait(driver);
			   //Specify the timout of the wait
			   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
			   //Sepcify polling time
			   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
			   //Specify what exceptions to ignore
			   wait.ignoring(NoSuchElementException.class);
			   wait.ignoring(StaleElementReferenceException.class);
			   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	      productdetail.closeoffer();
		   log.info("Closing the offer modal");

	 	   CartSlider cart = new CartSlider(driver);   
	 	   Header websiteheader = new Header(driver);
	 	   websiteheader.babyHeader();
	 	   log.info("Click on baby menu in header");
	 	   
	 	   wait.until(ExpectedConditions.visibilityOf(websiteheader.babyCribSheetMenu()));
	 	   websiteheader.babyCribSheetMenu().click();;
		   log.info("Clicked on Baby CribSheet menu option ");
		   
	 	   BabyCribSheet babyCribSheetproduct = new BabyCribSheet(driver);
		   wait.until(ExpectedConditions.visibilityOf(babyCribSheetproduct.oneSheetPackSize()));
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,800)", "");
		   babyCribSheetproduct.babyCribSheetAddToCartButton().click();
		   log.info("Clicked on add to cart button");
		   
		   Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryPackOfOneBabyCribSheetProductAddedInCart()));
		   boolean productname = cart.standardCategoryPackOfOneBabyCribSheetProductAddedInCart().isDisplayed();
			
			if(productname) 
			{
				log.info("Standard category Baby crib sheet product is added in cart");
			}else
			{
				log.info("Standard category Baby crib sheet product is not added in cart");
			}		
		}

}
