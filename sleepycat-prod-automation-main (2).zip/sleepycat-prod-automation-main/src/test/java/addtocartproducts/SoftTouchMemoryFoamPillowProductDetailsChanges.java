package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.SoftTouchMemoryFoamPillow;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
public class SoftTouchMemoryFoamPillowProductDetailsChanges extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(SoftTouchMemoryFoamPillowProductDetailsChanges.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void softTouchmemoryFoamPillowAddToCart() throws Exception
		{
		 
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	 	   
	       //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");
	       
	  	   CartSlider cart = new CartSlider(driver);   
		   Header websiteheader = new Header(driver);
		   websiteheader.pillowHeader();
		   log.info("Clicked on Pillow header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.softTouchMemoryFoamMenu()));
		   websiteheader.softTouchMemoryFoamMenu().click();
		   log.info("Clicked on softTouchMemoryFoam Menu option");
		   
		   SoftTouchMemoryFoamPillow SoftTouchmemoryFoamPillowproduct = new SoftTouchMemoryFoamPillow(driver);		   
		   SoftTouchmemoryFoamPillowproduct.presidentCategory().click();
		   log.info("Clicked on President Category option");
		   
		   Thread.sleep(1000);
		   SoftTouchmemoryFoamPillowproduct.standardCategory().click();
		   log.info("Clicked on Standard Category option");
	       
		   Thread.sleep(1000);
		   SoftTouchmemoryFoamPillowproduct.fourPillowPackSize().click();
		   log.info("Clicked on Four Pillow pack size option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		   JavascriptExecutor js = (JavascriptExecutor) driver;
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.checkPincodeButton());
		   //productdetail.quantityselect();
		   //log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
		   
			/*
			 * productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
			/*
			 * productdetail.personalizeNameSection().click();
			 * log.info("Clicked on personalize Name Section");
			 * 
			 * Actions name =new Actions(driver);
			 * name.moveToElement(productdetail.personalizeNameField()).build().perform();
			 * log.info("Move to name field");
			 * 
			 * productdetail.personalizeNameField().sendKeys("TE");
			 * log.info("Entered the name in name field");
			 * 
			 * productdetail.stitchButton().click(); log.info("Clicked on Stitch button");
			 */
		   js.executeScript("arguments[0].click();",SoftTouchmemoryFoamPillowproduct.softTouchPillowAddToCartButton());

		   //SoftTouchmemoryFoamPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   Thread.sleep(2000);
		    wait.until(ExpectedConditions.visibilityOf(cart.standardCategorySoftTouchMemoryPillowPackOfFourProductAddedInCart()));
		   boolean productname = cart.standardCategorySoftTouchMemoryPillowPackOfFourProductAddedInCart().isDisplayed();
		   
			if(productname) 
			{
				log.info("Standard category Memory Foam Pillow pack of 4 Product is added in cart");
			}else
			{
				log.info("Standard category Memory Foam Pillow pack of 4 Product is not added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
