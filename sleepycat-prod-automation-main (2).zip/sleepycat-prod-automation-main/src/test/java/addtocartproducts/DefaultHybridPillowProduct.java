package addtocartproducts;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.HybridPillow;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultHybridPillowProduct extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultHybridPillowProduct.class);

	
	 @Test
		public void defaultHybridPillowAddToCart() throws Exception
		{
		 
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	       
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
		   productdetail.closeoffer();
		   log.info("Closing the offer modal");
	  	   
	  	   Header websiteheader = new Header(driver);   
	  	   CartSlider cart = new CartSlider(driver);   

	  	    websiteheader.pillowHeader();
	       log.info("pillow menu is opened");
	       
	       wait.until(ExpectedConditions.visibilityOf(websiteheader.hybridPillowMenu()));
	 	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteheader.hybridPillowMenu());
	       log.info("Clicked on Hybrid pillow menu option");
		   	   
		   HybridPillow hybridPillowproduct = new HybridPillow(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
		   hybridPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryHybridPillowProductAddedInCart()));
		   boolean productname = cart.standardCategoryHybridPillowProductAddedInCart().isDisplayed();
			
			if(productname) 
			{
				log.info("Standard category Hybrid pillow pack of one product is added in cart");
			}else
			{
				log.info("Standard category Hybrid pillow pack of one product is not added in cart");
			}		
		}

}
