package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.PillowCase;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class DefaultPillowCaseProduct extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultPillowCaseProduct.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void defaultPillowCaseAddToCart() throws Exception
		{
		 
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	       
		  //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	      //Thread.sleep(3000);
	      productdetail.closeoffer();
          log.info("Closing the offer modal");
		  	   
		   CartSlider cart = new CartSlider(driver);
		   Header websiteheader = new Header(driver);   
		   websiteheader.beddingHeader();
		   log.info("Clicked on Bedding header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.pillowCaseMenu()));
		   websiteheader.pillowCaseMenu().click();
		   log.info("Clicked on Pillowcase Menu option");
		   
		   PillowCase pillowCaseproduct = new PillowCase(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", pillowCaseproduct.pillowCaseAddToCartButton());
		   //pillowCaseproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   //Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.dolphinGrayColorStandardPillowCasePackOfTwoProductAddedInCart()));
		   //boolean productname = cart.twlightBlueColorStandardPillowCasePackOfTwoProductAddedInCart().isDisplayed();
		   boolean productname = cart.dolphinGrayColorStandardPillowCasePackOfTwoProductAddedInCart().isDisplayed();

			if(productname) 
			{
				log.info("Dolphin Gray color Standard Pillow Case pack of Two product is added in cart");
			}else
			{
				log.info("Dolphin Gray color Standard Pillow Case pack of Two product is not added in cart");
			}	
		}
	 
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed"); }
		 */

}
