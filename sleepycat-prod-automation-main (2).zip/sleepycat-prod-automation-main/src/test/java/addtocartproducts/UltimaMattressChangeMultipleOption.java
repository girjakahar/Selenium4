package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.UltimaMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
public class UltimaMattressChangeMultipleOption extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(UltimaMattressChangeMultipleOption.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void ultimaMattressChangeoption() throws Exception
	{
    	
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
       //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
  	   //Thread.sleep(3000);
       productdetail.closeoffer();
       log.info("Closing the offer modal");
  	   
	   CartSlider cart = new CartSlider(driver);
  	   Header websiteHeader = new Header(driver);  	   
  	   websiteHeader.mattHeader();
	   log.info("Clicked on Mattress header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.ultimaMattressMenu()));
	   websiteHeader.ultimaMattressMenu().click();
	   log.info("Clicked on Ultima Mattress menu option");

	   productdetail.queenCategory().click();
	   log.info("Clicked on Queen category");
	   
	   productdetail.kingCategory().click();
	   log.info("Clicked on King category");
	   
	   productdetail.singleCategory().click();
	   log.info("Clicked on Single category");
	   
	   UltimaMattress ultimamattressproduct = new UltimaMattress(driver);
	   ultimamattressproduct.tenInchHeight().click();
	   log.info("Clicked on ten Inch Height option");
	   
	   ultimamattressproduct.eightInchHeight().click();
	   log.info("Clicked on Eight Inch Height option");
	   
		/*
		 * Thread.sleep(3000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
	    Thread.sleep(2000);
		/*
		 * WebElement add1 = driver.
		 * findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt disabled wc-variation-selection-needed'])[2]"
		 * );
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",
		 * add1);
		 */
	   //productdetail.scrollToChangeCategoryDefaultAddToCart();
	   //log.info("Scroll to add to cart button section");
	   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,50)", "");
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   productdetail.sizeDropdown().click();
	   log.info("Clicked on sizedropdown field");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimamattressproduct.singleUltima78x30x8());
	   //ultimamattressproduct.singleUltima78x30x8().click();
	   log.info("Clicked on one size option from the dropdown");
		
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   //productdetail.sizeDropdown().click();
	   log.info("Clicked on sizedropdown field");
		 	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimamattressproduct.singleUltima72x36x8());
	   //ultimamattressproduct.singleUltima72x36x8().click();
	   log.info("Clicked on one size option from the dropdown");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimamattressproduct.tenInchHeight());
	   //ultimamattressproduct.tenInchHeight().click();
	   log.info("Clicked again on ten Inch Height option");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.kingCategory());
	   //ultimamattressproduct.tenInchHeight().click();
	   log.info("Clicked on King Category option");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
	   //productdetail.sizeDropdown().click();
	   log.info("Clicked on sizedropdown field");
		 	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimamattressproduct.kingUltima75x72x10());
	   //ultimamattressproduct.singleUltima72x36x8().click();
	   log.info("Clicked on one size option from the dropdown");
	   
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.checkPincodeButton());
	   //productdetail.quantityselect();
	   //log.info("Scroll to quantity field");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to Three");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
	   log.info("Scroll to cross selling product section");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimamattressproduct.ultimaMattressAddToCartButton());
	   //ultimamattressproduct.defaultAddToCart();
	   log.info("Clicked on add to cart button");
	   
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOf(cart.kingCategoryUltima75x72x10ProductAddedInCart()));
		boolean productname = cart.kingCategoryUltima75x72x10ProductAddedInCart().isDisplayed();
		
		if(productname) 
		{
			log.info("King Category Ultima Mattress change option Product is added in cart");
		}else
		{
			log.info("King Category Ultima Mattress change option Product is not added in cart");
		}	
	   
	}
    
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
