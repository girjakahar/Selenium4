package addtocartproducts;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.BabyBolsterPillow;
import pageobject.BabyHeadPillow;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultBabyBolsterPillowProduct extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultBabyBolsterPillowProduct.class);
	
	    @Test
		public void defaultBabyBolsterPillowAddToCart() throws Exception
		{
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		       
	      productdetail.closeoffer();
		   log.info("Closing the offer modal");

	 	   CartSlider cart = new CartSlider(driver);   
	 	   Header websiteheader = new Header(driver);
	 	   websiteheader.babyHeader();
	 	   log.info("Click on baby menu in header");
	 	   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.babyBolsterPillowMenu()));
	 	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteheader.babyBolsterPillowMenu());
		   log.info("Clicked Baby Bolster menu option ");
		   
		   BabyBolsterPillow babyBolsterPillowproduct = new BabyBolsterPillow(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", babyBolsterPillowproduct.babyBolsterPillowAddToCartButton());
		   //babyBolsterPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryBabyBolsterPillowProductAddedInCart()));
		   boolean productname = cart.standardCategoryBabyBolsterPillowProductAddedInCart().isDisplayed();
			
		   if(productname) 
			{
				log.info("Standard category Baby Bolster pillow product is added in cart");
			}else
			{
				log.info("Standard category Baby Bolster pillow product is not added in cart");
			}	
		}

}
