package addtocartproducts;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.CouplePillow;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})

public class DefaultCouplePillowProduct extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultCouplePillowProduct.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	    @Test
		public void defaultCouplePillow() throws Exception
		{
		   
		 //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		       
		       
		       Header websiteheader = new Header(driver);   
		  	   CartSlider cart = new CartSlider(driver); 

		  	   websiteheader.pillowHeader();
		 	   log.info("pillow menu is opened");
			   	   
		 	   CouplePillow couplePillowProduct = new CouplePillow(driver);
			   
			   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteheader.couplePillowMenu());
			   log.info("Clicked on Couple pillow menu option");
			   
			   Thread.sleep(2000);
			   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
			   log.info("Scroll to cross selling product section");
				   
				   
				   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,800)", "");
				   Thread.sleep(1000); 
				   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", couplePillowProduct.couplePillowAddToCartButton());
				   //cloudPillowproduct.addToCart();
				   log.info("Clicked on add to cart button");
				   
				   wait.until(ExpectedConditions.visibilityOf(cart.leftHandCouplePillowProductAddedInCart())); 
				   boolean productname = cart.leftHandCouplePillowProductAddedInCart().isDisplayed();
				   		
					if(productname) 
					{
						log.info("Left Hand Couple pillow pack of one product is added in cart");
					}else
					{
						log.info("Left Hand Couple pillow pack of one product is not added in cart");
					}
					
		}
	

}
