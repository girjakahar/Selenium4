package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.CloudPillow;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class CloudPillowProductDetailsChanges extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(CloudPillowProductDetailsChanges.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	    @Test
		public void cloudPillowAddToCart() throws Exception
		{
	    	
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		       
	 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
		   //Thread.sleep(3000);
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");

		   Header websiteheader = new Header(driver);
		   websiteheader.pillowHeader();
	 	   log.info("pillow menu is opened");
	 	   
	 	   wait.until(ExpectedConditions.visibilityOf(websiteheader.cloudPillowMenu()));
	 	   websiteheader.cloudPillowMenu().click();
	 	   log.info("Clicked on cloud pillow menu option");
		   
		   CartSlider cart = new CartSlider(driver);
		   CloudPillow cloudPillowproduct = new CloudPillow(driver);
		   cloudPillowproduct.presidentCategory().click();
		   log.info("Clicked on president category option");
           
		   Thread.sleep(1000);
		   cloudPillowproduct.twoPillowPackSize().click();
		   log.info("Clicked on Two Pillow pack size option");
		   
		   productdetail.feetDimension().click();
		   log.info("Clicked on Feet dimension option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
			/*
			 * productdetail.quantityselect();
			 * log.info("Selected one qantity from quantity dropdown");
			 */
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.increaseQuantity());
		   JavascriptExecutor js = (JavascriptExecutor) driver;

		   productdetail.quantityselect();
		   log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
		   
		   Thread.sleep(2000);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
		   cloudPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   //Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.presidentCategoryCloudPillowPackOfTwoProductAddedInCart()));
		   boolean productname = cart.presidentCategoryCloudPillowPackOfTwoProductAddedInCart().isDisplayed();
		   
			if(productname) 
			{
				log.info("President category Cloud Pillow pack of 2 Product is added in cart");
			}else
			{
				log.info("President category Cloud Pillow pack of 2 Product is not added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
