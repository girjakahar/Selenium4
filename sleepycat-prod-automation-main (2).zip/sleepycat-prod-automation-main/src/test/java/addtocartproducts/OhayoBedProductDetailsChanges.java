package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OhayoBed;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class OhayoBedProductDetailsChanges extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(OhayoBedProductDetailsChanges.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void ohayoBedAddToCart() throws Exception
		{	
		  
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	       
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");
	  	   
	  	   CartSlider cart = new CartSlider(driver);   
	  	   Header websiteHeader = new Header(driver);
	  	   OhayoBed ohayoproduct = new OhayoBed(driver);
		   Header websiteheader = new Header(driver);

	  	   websiteheader.bedHeader();
		   log.info("Clicked on Bed header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.ohayoBedMenu()));
		   websiteheader.ohayoBedMenu().click();
		   log.info("Clicked on ohayoBed Menu option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.kingCategory());
		   //productdetail.kingCategory().click();
		   log.info("Clicked on King category option");
		   
			/*
			 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.queenPlusTrayCategory());
			 * //productdetail.kingCategory().click();
			 * log.info("Clicked on Queen Plus Tray Category option");
			 * 
			 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
			 * productdetail.kingPlusTrayCategory());
			 * //productdetail.kingCategory().click();
			 * log.info("Clicked on King Plus Tray Category option");
			 */
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.queenCategory());
		   //productdetail.kingCategory().click();
		   log.info("Clicked again on Queen category option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.kingCategory());
		   //productdetail.kingCategory().click();
		   log.info("Clicked on King category option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.feetDimension());
		   //productdetail.feetDimension().click();
		   log.info("Clicked on Feet dimension option");
		   
			/*
			 * wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()))
			 * ; productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
		   productdetail.quantityselect();
		   log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
		   
		   JavascriptExecutor js = (JavascriptExecutor) driver;
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
		   js.executeScript("arguments[0].click();", ohayoproduct.ohayoBedAddToCartButton());

		   //productdetail.defaultAddToCart();
		   log.info("Clicked on add to cart button");
		   
		   //Thread.sleep(2000); 
		    wait.until(ExpectedConditions.visibilityOf(cart.ohayoBedKingCategoryProductAddedInCart()));
		   boolean productname = cart.ohayoBedKingCategoryProductAddedInCart().isDisplayed();
			
			if(productname) 
			{
				log.info("King category Ohayo Bed Product is added in cart");
			}else
			{
				log.info("King category Ohayo Bed Product is not added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed"); }
		 */
}
