package addtocartproducts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OhayoBedTray;
import pageobject.ProductDetails;


@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultOhayoBedTrayproduct extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultOhayoBedTrayproduct.class);

	
	 @Test
		public void defaultOhayoBedAddToCart() throws Exception
		{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	      
		    //wait = new WebDriverWait(driver, 10);		    	   
	       //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	      
	       //Declare and initialise a fluent wait
		   FluentWait wait = new FluentWait(driver);
		   //Specify the timout of the wait
		   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		   //Sepcify polling time
		   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		   //Specify what exceptions to ignore
		   wait.ignoring(NoSuchElementException.class);
		   wait.ignoring(StaleElementReferenceException.class);
		   
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
		   productdetail.closeoffer();
		   log.info("Closing the offer modal");
	  	   
	  	   Header websiteheader = new Header(driver);   
	  	   CartSlider cart = new CartSlider(driver);   
	  	   websiteheader.bedHeader();
		   log.info("Clicked on Bed header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.ohayoBedTrayMenu()));
		   websiteheader.ohayoBedTrayMenu().click();
		   log.info("Clicked on ohayoBed Tray Menu option");
		   
		   OhayoBedTray ohayoBedTrayproduct = new OhayoBedTray(driver);		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
		   ohayoBedTrayproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   wait.until(ExpectedConditions.visibilityOf(cart.ohayoBedTrayProductAddedInCart()));
		   boolean productname = cart.ohayoBedTrayProductAddedInCart().isDisplayed();
			
		  if(productname) 
			{
				log.info("Ohayo bed Tray product is added in cart");
			}else
			{
				log.info("Ohayo bed Tray product is not added in cart");
			}	
		}

}
