package addtocartproducts;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.NapPillow;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class NapPillowProductDetailsChanges extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(NapPillowProductDetailsChanges.class);
	
	 @Test
		public void napPillowAddToCart() throws Exception
		{
		//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
         ProductDetails productdetail = new ProductDetails(driver);
         productdetail.openWebsite();
	       log.info("open the website");
	       
	    //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
        productdetail.closeoffer();
	    log.info("Closing the offer modal");

	   CartSlider cart = new CartSlider(driver);   
	   Header websiteheader = new Header(driver);
	   websiteheader.pillowHeader();
	   log.info("Clicked on Pillow header option");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteheader.napPillowMenu()));
	   websiteheader.napPillowMenu().click();
	   log.info("Clicked on Nap Pillow Menu option");
		   	   
		   NapPillow napPillowproduct = new NapPillow(driver);
		   JavascriptExecutor js = (JavascriptExecutor) driver;
			 
		   js.executeScript("arguments[0].click();", productdetail.cmDimension());
		   //hybridPillowproduct.twoPillowPackSize().click();
		   log.info("Clicked on cm dimension option");
		   
		   js.executeScript("arguments[0].click();", productdetail.feetDimension());
		   //hybridPillowproduct.onePillowPackSize().click();
		   log.info("Clicked on feet dimension option");
		   
		   js.executeScript("arguments[0].click();", productdetail.inchDimension());
		   //hybridPillowproduct.twoPillowPackSize().click();
		   log.info("Clicked on inch dimension option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		   productdetail.quantityselect();
		   log.info("Scroll to quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
		   log.info("Increase product quantity to Three");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
		   log.info("Decrease product quantity to two");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
		   napPillowproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   wait.until(ExpectedConditions.visibilityOf(cart.standardCategoryNapPillowPackOfOneProductAddedInCart()));
		   boolean productname = cart.standardCategoryNapPillowPackOfOneProductAddedInCart().isDisplayed();
		   
			if(productname) 
			{
				log.info("Standard category Nap Pillow pack of Two Product is added in cart");
			}else
			{
				log.info("Standard category Nap Pillow pack of Two Product is not added in cart");
			}	
		}


}
