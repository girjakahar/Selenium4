package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.MetalBedFrame;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class MetalBedFrameProductDetailsChanges extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(MetalBedFrameProductDetailsChanges.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	 @Test
		public void metalBedFrameAddToCart() throws Exception
		{
		 
		 driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      log.info("Website opened Successfully");
	      
		   wait = new WebDriverWait(driver, 10);		    	   
	       //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	       ProductDetails productdetail = new ProductDetails(driver);
		   wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");

	  	   CartSlider cart = new CartSlider(driver);   
	  	   Header websiteheader = new Header(driver);
	  	   websiteheader.metalBedFrameProduct();
		   log.info("Metal Bed Frame Product detail page is opened");
		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		  
		   productdetail.queenCategory().click();
		   log.info("Clicked on Queen category option");
		   
			/*
			 * productdetail.closeoffer(); log.info("Closing the offer modal");
			 */
		   
		   productdetail.kingCategory().click();
		   log.info("Clicked on King category option");
		   
		   productdetail.singleCategory().click();
		   log.info("Clicked Back on Single category option");
		   
		   productdetail.feetDimension().click();
		   log.info("Clicked on Feet dimension option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
			/*
			 * productdetail.quantityselect();
			 * log.info("Selected one quantity from the dropdown");
			 */
		   
		   JavascriptExecutor js = (JavascriptExecutor) driver;

		   Thread.sleep(2000);
		   productdetail.quantityField().click();
		   log.info("Clicked on Quantity field");
		   
		   Thread.sleep(2000);
		   js.executeScript("arguments[0].click();",productdetail.quantityselection());
		   //productdetail.quantityselect();
		   log.info("Selected one quantity from the dropdown");
		   
		   Thread.sleep(1000);
		   MetalBedFrame metalBedFrameproduct = new MetalBedFrame(driver);  	   
		   metalBedFrameproduct.addToCart();
		   log.info("Clicked on add to cart button");
		   
		   //Thread.sleep(2000); 
		    wait.until(ExpectedConditions.visibilityOf(cart.metalBedSingleCategoryProductAddedInCart()));
		   boolean productname = cart.metalBedSingleCategoryProductAddedInCart().isDisplayed();

		 if(productname) 
			{
				log.info("Single category Metal Bed frame Product is added in cart");
			}else
			{
				log.info("Single category Metal Bed frame Product is not added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
