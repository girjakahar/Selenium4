package addtocartproducts;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.ContourMemoryFoamPillow;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultContourCoolTecMemoryFoamPillowProduct extends BaseTest {
	
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultContourCoolTecMemoryFoamPillowProduct.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	   @Test
		public void defaultContourCoolTecMemoryFoamPillowAddToCart() throws Exception
		{
		     //driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	         ProductDetails productdetail = new ProductDetails(driver);
	         productdetail.openWebsite();
		       log.info("open the website");
		       
	 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");

	  	   CartSlider cart = new CartSlider(driver);   
	  	   Header websiteheader = new Header(driver);

	  	   websiteheader.pillowHeader();
	 	   log.info("pillow menu is opened"); 
	 	   
	 	   wait.until(ExpectedConditions.visibilityOf(websiteheader.contourCoolTecMemoryFoamPillowMenu()));
	 	  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", websiteheader.contourCoolTecMemoryFoamPillowMenu());
		   log.info("Clicked on Contour cooltec pillow menu option");	
		   
			/*
			 * productdetail.personalizeNameSection().click();
			 * log.info("Clicked on personalize Name Section");
			 * 
			 * Actions name =new Actions(driver);
			 * name.moveToElement(productdetail.personalizeNameField()).build().perform();
			 * log.info("Move to Name field");
			 * 
			 * productdetail.personalizeNameField().sendKeys("ME");
			 * log.info("Entered The Name");
			 * 
			 * productdetail.stitchButton().click();
			 * log.info("Clicked on Stitch it button");
			 */
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.quantityField());
	  	   //productdetail.quantityField().click();
		   log.info("Clicked on Quantity field");

		   productdetail.enterQuantityManually().sendKeys("6");
		   log.info("Quantity value is added in Quantity field");	
		   
		   productdetail.enterQuantityManually().sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
		   //productdetail.enterQuantityManually().clear();
		   log.info("By default entered value is removed from quantity field");
		   
		   productdetail.enterQuantityManually().sendKeys("4");
		   log.info("Quantity value is added in Quantity field");
		   
		   ContourMemoryFoamPillow contourMemoryFoamPillowproduct = new ContourMemoryFoamPillow(driver);
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", contourMemoryFoamPillowproduct.conTourCoolTecPillowAddToCartButton());
		   //contourMemoryFoamPillowproduct.addToCartConTourCoolTecPillow();
		   log.info("Clicked on add to cart button");
		   
		   Thread.sleep(2000);
		   wait.until(ExpectedConditions.visibilityOf(cart.contourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart()));
		   boolean productname = cart.contourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart().isDisplayed();
			
			if(productname) 
			{
				log.info("Contour category CoolTec Memory Foam pillow pack of one product is added in cart");
			}else
			{
				log.info("Contour category CoolTec Memory Foam pillow pack of one product is not added in cart");
			}	
		}

}
