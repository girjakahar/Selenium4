package addtocartproducts;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.LatexMattress;
import pageobject.ProductDetails;

@Test(groups= {"RegressionTest"})
public class LatexMattressChangeMultipleOption extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(LatexMattressChangeMultipleOption.class);

	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
	    @Test
		public void latexMattressChangeoption() throws Exception
		{
	    	
	    	//driver.get(prop.getProperty("url"));
		      //driver.get("https://sleepycat.in/");
		      //log.info("Website opened Successfully");
		    	
		      wait = new WebDriverWait(driver, 10);		    	   
		      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
	          ProductDetails productdetail = new ProductDetails(driver);
	          productdetail.openWebsite();
		       log.info("open the website");
		       
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");
	  	   
	  	   CartSlider cart = new CartSlider(driver);   
	  	   Header websiteheader = new Header(driver);
	  	   websiteheader.mattHeader();
		   log.info("Clicked on Mattress header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.hybridLatexMattressMenu()));
		   websiteheader.hybridLatexMattressMenu().click();
		   log.info("Clicked on Latex Mattress menu option");
		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   
		   productdetail.queenCategory().click();
		   log.info("Clicked on Queen category option");
		   
		   productdetail.kingCategory().click();
		   log.info("Clicked on King category option");
		   
		   productdetail.singleCategory().click();
		   log.info("Clicked on Single category option");
		   
			/*
			 * Thread.sleep(3000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       //Thread.sleep(3000);
	       productdetail.closeoffer();
	       log.info("Closing the offer modal");
		  
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
		   //productdetail.sizeDropdown().click();
		   log.info("Clicked on sizedropdown field");
		   
		   LatexMattress latexmattressproduct = new LatexMattress(driver);
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", latexmattressproduct.singleLatex72x36x6());
		   //latexmattressproduct.singleLatex72x36x6().click();
		   log.info("Clicked on one size option from the dropdown");
		   
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
		   //productdetail.sizeDropdown().click();
		   log.info("Again clicked on sizedropdown field");
		   
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", latexmattressproduct.singleLatex75x36x6());
		   //latexmattressproduct.singleLatex75x36x6().click();
		   log.info("Clicked on one size option from the dropdown");
		   
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.kingCategory());
		   //productdetail.kingCategory().click();
		   log.info("Clicked on King category option");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
		   //productdetail.sizeDropdown().click();
		   log.info("Again clicked on sizedropdown field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", latexmattressproduct.kingLatex75x72x6());
		   log.info("Clicked on one size option from the dropdown");
		   
			/*
			 * productdetail.quantityselect();
			 * log.info("Quantity is selected from the quantity dropdown");
			 */
		   
	       
		   JavascriptExecutor js = (JavascriptExecutor) driver;

		   Thread.sleep(2000);
	       ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.quantityField());
		   //productdetail.quantityField().click();
		   log.info("Clicked on Quantity field");
		   
		   productdetail.enterQuantityManually().sendKeys("6");
		   log.info("Quantity value is added in Quantity field");	
		   
		   productdetail.enterQuantityManually().sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
		   //productdetail.enterQuantityManually().clear();
		   log.info("By default entered value is removed from quantity field");
		   
		   productdetail.enterQuantityManually().sendKeys("4");
		   log.info("Quantity value is added in Quantity field");
		   
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
		   js.executeScript("arguments[0].click();",latexmattressproduct.latexMattressAddToCartButton());
		   //Thread.sleep(2000);
		   //productdetail.defaultAddToCart();
		   log.info("Clicked on add to cart button");
		   
		    //Thread.sleep(2000);
		    wait.until(ExpectedConditions.visibilityOf(cart.kingCategoryHybridLatexMattress75x72x6ProductAddedInCart()));
			boolean productname = cart.kingCategoryHybridLatexMattress75x72x6ProductAddedInCart().isDisplayed();
		   			
			if(productname) 
			{
				log.info("King category latex mattress change option Product is added in cart");
			}else
			{
				log.info("King category latex mattress change option Product is not added in cart");
			}	
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
