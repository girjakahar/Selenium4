package addtocartproducts;

import org.testng.annotations.Test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.UltimaMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})
public class DefaultUltimalMattressProduct extends BaseTest {
		
		//static RemoteWebDriver driver;
		static WebDriverWait wait;
		public static Logger log =LogManager.getLogger(DefaultUltimalMattressProduct.class);

		/*
		 * @BeforeTest public void startingDriver() throws IOException {
		 * driver=initializeChrome(); log.info("Starting driver");
		 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
		 * }
		 */
		
	    @Test
		public void defaultUltimaMattressAddToCart() throws Exception
		{
	    
	      //driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
          ProductDetails productdetail = new ProductDetails(driver);
          productdetail.openWebsite();
	       log.info("open the website");
	 	   
		   //Thread.sleep(3000);
		   productdetail.closeoffer();
	       log.info("Closing the offer modal");
			  
		   CartSlider cart = new CartSlider(driver);
	  	   Header websiteheader = new Header(driver);
	  	   websiteheader.mattHeader();
		   log.info("Clicked on Mattress header option");
		   
		   wait.until(ExpectedConditions.visibilityOf(websiteheader.ultimaMattressMenu()));
		   websiteheader.ultimaMattressMenu().click();
		   log.info("Clicked on Ultima Mattress menu option");
		   
			/*
			 * Thread.sleep(1000); productdetail.closeoffer();
			 * log.info("Closing the offer modal");
			 */
		   	  	   
		   UltimaMattress ultimaMattressproduct = new UltimaMattress(driver);
		    //wait.until(ExpectedConditions.visibilityOf(productdetail.singleCategory()));
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,800)", "");
		   //((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
		   log.info("Scroll to cross selling product section");
		   
			  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.sizeDropdown());
			  log.info("Clicked on select sizedropdown");
			  
			  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ultimaMattressproduct.singleUltima72x36x8());
			  log.info("Clicked on one size from dropdown option");
		   
		    ultimaMattressproduct.defaultAddToCart();
		   log.info("Clicked on add to cart button");
		   	
		    wait.until(ExpectedConditions.visibilityOf(cart.ultimaMattressProductAddedInCartSlider()));
			boolean productname = cart.ultimaMattressProductAddedInCartSlider().isDisplayed();

			if(productname) 
			{
				log.info("Single category Ultima Mattress Product is added in cart");
			}else
			{
				log.info("Single category Ultima Mattress Product is not added in cart");
			}	
		   
		}
	    
		/*
		 * @AfterTest public void closeDriver() throws IOException { driver.quit();
		 * log.info("Driver is closed");
		 * 
		 * }
		 */

}
