package addtocartbundleproductsincart;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class OriginalMattressAddToCartBundle extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(OriginalMattressAddToCartBundle.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void originalMattressBundleAddToCart() throws Exception
	{
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
        //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	   //Thread.sleep(3000);
       productdetail.closeoffer();
       log.info("Closing the offer modal");
  	   
  	   Header websiteHeader = new Header(driver);
  	 websiteHeader.bundleHeader();
	   log.info("All Bundle menu is opened");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.babyStarterPackBundleMenu()));
	   websiteHeader.babyStarterPackBundleMenu().click();
	   log.info("Original mattress product details page is opened");
	   
  	   CartSlider cart = new CartSlider(driver);   
	   OriginalMattress originalmattressproduct = new OriginalMattress(driver);  	   
	   productdetail.queenCategory().click();
	   log.info("Clicked on Queen category");
	   
	   productdetail.kingCategory().click();
	   log.info("Clicked on King category");
	   
	   Thread.sleep(2000);
	   productdetail.scrollToBuyBundleButton();
       log.info("Scroll to Buy Bundle button section");
	   
		/*
		 * Thread.sleep(2000); productdetail.closeoffer();
		 * log.info("Closing offer modal");
		 */	   
	     	   
		/*
		 * productdetail.quantityselect();
		 * log.info("Selected one quantity from the dropdown");
		 */
       
       JavascriptExecutor js = (JavascriptExecutor) driver;

	   Thread.sleep(2000);
	   productdetail.quantityField().click();
	   log.info("Clicked on Quantity field");
	   
	   Thread.sleep(2000);
	   js.executeScript("arguments[0].click();",productdetail.quantityselection());
	   //productdetail.quantityselect();
	   log.info("Selected one quantity from the dropdown");
  	   
	   js.executeScript("arguments[0].click();",productdetail.buyBundleButton());
	   //productdetail.buyBundleButton().click();
	   log.info("Clicked on Buy Bundle button"); 
	   
		//Thread.sleep(2000); 
	    wait.until(ExpectedConditions.visibilityOf(cart.originalMattressKingCategory72x72x6BundleProductAddedInCart()));
		boolean productname = cart.originalMattressKingCategory72x72x6BundleProductAddedInCart().isDisplayed();
		
		if(productname) 
		{
			log.info("King Category Original Mattress Bundle Product is added in cart");
		}else
		{
			log.info("King Category Original Mattress Bundle Product is added in cart");
		}	
	   
	}
    
	/*
	 * @AfterTest public void closeDriver() throws IOException { driver.quit();
	 * log.info("Driver is closed");
	 * 
	 * }
	 */

}
