package addtocartbundleproductsincart;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.CartSlider;
import pageobject.EverydayBundle;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class DefaultEverydayBundleAddToCart extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(DefaultEverydayBundleAddToCart.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void defaultEverydayBundleAddToCart() throws Exception
	{
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
		      
	  	   //wait = new WebDriverWait(driver, 10);		  
	       //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		   
		 //Declare and initialise a fluent wait
		   FluentWait wait = new FluentWait(driver);
		   //Specify the timout of the wait
		   wait.withTimeout(9000, TimeUnit.MILLISECONDS);
		   //Sepcify polling time
		   wait.pollingEvery(1000, TimeUnit.MILLISECONDS);
		   //Specify what exceptions to ignore
		   wait.ignoring(NoSuchElementException.class);
		   wait.ignoring(StaleElementReferenceException.class);
		   
	 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
  	   
  	   Header websiteHeader = new Header(driver);
  	   websiteHeader.bundleHeader();
	   log.info("All Bundle menu is opened");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.everydayBundleMenu()));
	   websiteHeader.everydayBundleMenu().click();
	   log.info("EveryDay Bundle product details page is opened");
	   
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
  	   CartSlider cart = new CartSlider(driver);   
  	   EverydayBundle everydayBundleproduct = new EverydayBundle(driver);  	   
       
	   //productdetail.quantityselect();
	   //log.info("Selected one quantity from quantity dropdown");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to one");
	   
	   JavascriptExecutor js = (JavascriptExecutor) driver;

	   js.executeScript("arguments[0].click();", everydayBundleproduct.everyDayBundleAddToCartButton());
	   //memoryFoamPillowproduct.addToCart();
	   log.info("Clicked on add to cart button");
	   
 	   wait.until(ExpectedConditions.visibilityOf(cart.everyDayBundleKing72x72x8PinkColorProductAddedInCart()));
	   boolean productname = cart.everyDayBundleKing72x72x8PinkColorProductAddedInCart().isDisplayed();
	   
		if(productname) 
		{
			log.info("EveryDay Bundle Default variation Product is added in cart");
		}else
		{
			log.info("EveryDay Bundle Default variation Product is not added in cart");
		}	
	}

}
