package addtocartbundleproductsincart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.AllBundleProductDetailsPage;
import pageobject.BachelorBundle;
import pageobject.CartSlider;
import pageobject.EverydayBundle;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class BachelorBundleAddToCart extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(BachelorBundleAddToCart.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void bachelorBundleAddToCart() throws Exception
	{
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
  	   
  	   Header websiteHeader = new Header(driver);
  	   AllBundleProductDetailsPage allBundleproduct = new AllBundleProductDetailsPage(driver);  	   
  	   websiteHeader.bundleHeader();
	   log.info("All Bundle menu is opened");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.bachelorBundleMenu()));
	   websiteHeader.bachelorBundleMenu().click();
	   log.info("Campus Bundle product details page is opened");

  	   CartSlider cart = new CartSlider(driver);   
  	   BachelorBundle campusBundleproduct = new BachelorBundle(driver);  	   
  	   campusBundleproduct.selectSizeDropdownField().click();
	   log.info("Click on Select Sizedropdown field");
	   
	   allBundleproduct.singleOriginalMattressBundle75x36x6().click();
	   log.info("Clicked on Single category variation of original mattress");
	   
	   campusBundleproduct.selectSizeDropdownField().click();
	   log.info("Again Click on Select Sizedropdown field");
	   
	   //allBundleproduct.singleOriginalMattressBundle78x36x6().click();
	   allBundleproduct.singleOriginalMattressBundle72x36x6().click();
	   log.info("Clicked on Single category variation of original mattress");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", allBundleproduct.bundleComforterPinkColor());
	   //allBundleproduct.bundleComforterPinkColor().click();
	   log.info("Clicked on Pink Color Comforter variation");
	   
		/*
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * allBundleproduct.bundleComforterBlueColor());
		 * //allBundleproduct.bundleComforterBlueColor().click();
		 * log.info("Clicked on Blue Color Comforter variation");
		 */
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", allBundleproduct.bundleComforterCoffeeColor());
	   //allBundleproduct.bundleComforterCoffeeColor().click();
	   log.info("Clicked on Coffee Color Comforter variation");
       
	   //productdetail.quantityselect();
	   //log.info("Selected one quantity from quantity dropdown");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to Three");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to two");
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
	   log.info("Scroll to cross selling product section");

	   js.executeScript("arguments[0].click();", campusBundleproduct.campusBundleAddToCartButton());
	   //memoryFoamPillowproduct.addToCart();
	   log.info("Clicked on add to cart button");
	   
 	   //wait.until(ExpectedConditions.visibilityOf(cart.campusBundleSingle78X36X6CoffeeColorProductAddedInCart()));
 	   wait.until(ExpectedConditions.visibilityOf(cart.campusBundleSingle72X36X6CoffeeColorProductAddedInCart()));
	   boolean productname = cart.campusBundleSingle72X36X6CoffeeColorProductAddedInCart().isDisplayed();
	   
		if(productname) 
		{
			log.info("Campus Bundle Single Coffee Color Product is added in cart");
		}else
		{
			log.info("Campus Bundle Single Coffee Color Product is not added in cart");
		}	
	}

}
