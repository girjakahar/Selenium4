package addtocartbundleproductsincart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.AllBundleProductDetailsPage;
import pageobject.CartSlider;
import pageobject.EverydayBundle;
import pageobject.Header;
import pageobject.OriginalMattress;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class EverydayBundleAddToCart extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(EverydayBundleAddToCart.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void everydayBundleAddToCart() throws Exception
	{
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
  	   
  	   Header websiteHeader = new Header(driver);
  	   websiteHeader.bundleHeader();
	   log.info("All Bundle menu is opened");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.everydayBundleMenu()));
	   websiteHeader.everydayBundleMenu().click();
	   log.info("EveryDay Bundle product details page is opened");
	   
		/*
		 * Thread.sleep(1000); productdetail.closeoffer();
		 * log.info("Closing the offer modal");
		 */
  	   CartSlider cart = new CartSlider(driver);   
  	   EverydayBundle everydayBundleproduct = new EverydayBundle(driver);
  	   AllBundleProductDetailsPage allBundleproduct = new AllBundleProductDetailsPage(driver);  	   
  	   everydayBundleproduct.mainCategoryDropdownField().click();
	   log.info("Clicked on Main category Dropdown field");
	   
	   everydayBundleproduct.queenCategoryDropdownField().click();
	   log.info("Clicked on Queen category");
	   
	   everydayBundleproduct.mainCategoryDropdownField().click();
	   log.info("Again Click on Main category Dropdown field");
	   
	   everydayBundleproduct.kingCategoryDropdownField().click();
	   log.info("Clicked on King category");
	   
	   everydayBundleproduct.selectSizeDropdownField().click();
	   log.info("Click on Select Sizedropdown field");
	   
	   allBundleproduct.kingOriginalMattressBundle75x72x8().click();
	   log.info("Clicked on King category variation of original mattress");
	   
	   everydayBundleproduct.selectSizeDropdownField().click();
	   log.info("Again Click on Select Sizedropdown field");
	   
	   allBundleproduct.kingOriginalMattressBundle78x72x8().click();
	   log.info("Clicked on King category variation of original mattress");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", allBundleproduct.bundleComforterPinkColor());
	   //allBundleproduct.bundleComforterPinkColor().click();
	   log.info("Clicked on Pink Color Comforter variation");
	   
		/*
		 * ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		 * allBundleproduct.bundleComforterBlueColor());
		 * //allBundleproduct.bundleComforterBlueColor().click();
		 * log.info("Clicked on Blue Color Comforter variation");
		 */
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", allBundleproduct.bundleComforterCoffeeColor());
	   //allBundleproduct.bundleComforterCoffeeColor().click();
	   log.info("Clicked on Coffee Color Comforter variation");
       
	   //productdetail.quantityselect();
	   //log.info("Selected one quantity from quantity dropdown");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to Three");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to two");
	   JavascriptExecutor js = (JavascriptExecutor) driver;

	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", productdetail.CrossSellFreeShippingText());
	   log.info("Scroll to cross selling product section");
	   
	   js.executeScript("arguments[0].click();", everydayBundleproduct.everyDayBundleAddToCartButton());
	   //memoryFoamPillowproduct.addToCart();
	   log.info("Clicked on add to cart button");
	   
 	   wait.until(ExpectedConditions.visibilityOf(cart.everyDayBundleKing78x72x8CoffeeColorProductAddedInCart()));
	   boolean productname = cart.everyDayBundleKing78x72x8CoffeeColorProductAddedInCart().isDisplayed();
	   
		if(productname) 
		{
			log.info("EveryDay Bundle King CoffeeColor Product is added in cart");
		}else
		{
			log.info("EveryDay Bundle King CoffeeColor Product is not added in cart");
		}	
	}
}
