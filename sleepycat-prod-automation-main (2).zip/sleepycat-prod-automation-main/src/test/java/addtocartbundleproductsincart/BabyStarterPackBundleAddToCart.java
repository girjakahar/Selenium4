package addtocartbundleproductsincart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.BaseTest;
import pageobject.AllBundleProductDetailsPage;
import pageobject.BabyStarterPackBundle;
import pageobject.BachelorBundle;
import pageobject.CartSlider;
import pageobject.Header;
import pageobject.ProductDetails;

@Test(groups= {"SanityTest","RegressionTest"})

public class BabyStarterPackBundleAddToCart extends BaseTest {
	
	//static RemoteWebDriver driver;
	static WebDriverWait wait;
	public static Logger log =LogManager.getLogger(BabyStarterPackBundleAddToCart.class);
	
	/*
	 * @BeforeTest public void startingDriver() throws IOException {
	 * driver=initializeChrome(); log.info("Starting driver");
	 * driver.get(prop.getProperty("url")); log.info("Website opened Successfully");
	 * }
	 */
	
    @Test
	public void babyStarterPackBundleAddToCart() throws Exception
	{
    	//driver.get(prop.getProperty("url"));
	      //driver.get("https://sleepycat.in/");
	      //log.info("Website opened Successfully");
	    	
	      wait = new WebDriverWait(driver, 10);		    	   
	      //driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
        ProductDetails productdetail = new ProductDetails(driver);
        productdetail.openWebsite();
	       log.info("open the website");
	       
	 	   //wait.until(ExpectedConditions.visibilityOf(productdetail.crossIconOfoffer()));
	       productdetail.closeoffer();
		   log.info("Closing the offer modal");
  	   
  	   Header websiteHeader = new Header(driver);
  	   AllBundleProductDetailsPage allBundleproduct = new AllBundleProductDetailsPage(driver);  	   
  	   websiteHeader.bundleHeader();
	   log.info("All Bundle menu is opened");
	   
	   wait.until(ExpectedConditions.visibilityOf(websiteHeader.babyStarterPackBundleMenu()));
	   websiteHeader.babyStarterPackBundleMenu().click();
	   log.info("Baby Starter Bundle product details page is opened");

  	   CartSlider cart = new CartSlider(driver);   
  	   BabyStarterPackBundle babyStarterBundleproduct = new BabyStarterPackBundle(driver);  	   
  	   babyStarterBundleproduct.selectSizeDropdownField().click();
	   log.info("Click on Select Sizedropdown field");
	   
	   allBundleproduct.babyMattressBundle52x28x4().click();
	   log.info("Clicked on Single category variation of baby mattress");
	   
	   babyStarterBundleproduct.selectSizeDropdownField().click();
	   log.info("Again Click on Select Sizedropdown field");
	   
	   allBundleproduct.babyMattressBundle48x24x4().click();
	   log.info("Clicked on Single category variation of baby mattress");
       
	   //productdetail.quantityselect();
	   //log.info("Selected one quantity from quantity dropdown");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to two");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.increaseQuantity());
	   log.info("Increase product quantity to Three");
	   
	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", productdetail.decreaseQuantity());
	   log.info("Decrease product quantity to two");
	   JavascriptExecutor js = (JavascriptExecutor) driver;

	   js.executeScript("arguments[0].click();", babyStarterBundleproduct.babyStarterPackBundleAddToCartButton());
	   //memoryFoamPillowproduct.addToCart();
	   log.info("Clicked on add to cart button");
	   
 	   wait.until(ExpectedConditions.visibilityOf(cart.babyStarterBundleSingle48X24X4ProductAddedInCart()));
	   //boolean productname = cart.babyStarterBundleSingle52X28X4ProductAddedInCart().isDisplayed();	   
	   boolean productname = cart.babyStarterBundleSingle48X24X4ProductAddedInCart().isDisplayed();

		if(productname) 
		{
			log.info("Baby Starter Bundle Product is added in cart");
		}else
		{
			log.info("Baby Starter Bundle Product is not added in cart");
		}	
	}

}
