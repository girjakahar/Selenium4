package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
	
static RemoteWebDriver driver;

   public Homepage(RemoteWebDriver driver) throws Exception
    {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
    }
	
	// Xpath for Banner section 
   //@FindBy(xpath = "//*[contains(@class, 'center')]//*[contains(@class, 'banner-desktop-svg')]")
   @FindBy(xpath = "(//div[@class='banner-desktop banner-bg-1'])[2]")
   private WebElement FirstBanner;
	
   @FindBy(xpath = "(//div[@class='banner-desktop banner-bg-2'])[2]")
   private WebElement SecondBanner;
	
   //@FindBy(xpath = "//*[contains(@class, 'center')]//*[contains(@class, 'banner-desktop-svg')]")
   @FindBy(xpath = "(//div[@class='banner-desktop banner-bg-3'])[2]")
   private WebElement ThirdBanner;
	
   //@FindBy(xpath = "//*[contains(@class, 'center')]//*[contains(@class, 'banner-desktop-svg')]")
   @FindBy(xpath = "(//div[@class='banner-desktop banner-bg-4'])[2]")
   private WebElement FourthBanner;
	
   @FindBy(xpath = "(//div[@class='banner-desktop banner-bg-5'])[2]")
   private WebElement FifthBanner;
   
   @FindBy(xpath = "//div[@class='owl-nav']//button[@class='owl-next']")
   private WebElement Nextbanner;
	
   @FindBy(xpath = "//div[@class='owl-nav']//button[@class='owl-prev']")
   private WebElement PreviousBanner;
	
	// Webelement for banner section
	public WebElement firstBanner() {
		return FirstBanner;
	}

	public WebElement secondBanner() {
		return SecondBanner;
	}

	public WebElement thirdBanner() {
		return ThirdBanner;
	}

	public WebElement fourthBanner() {
		return FourthBanner;
	}
		
	public WebElement fifthBanner() {
		return FifthBanner;
	}

	public WebElement nextbanner() {
		return Nextbanner;
	}

	public WebElement previousBanner() {
		return PreviousBanner;
	}
	
	// Xpath for Social media links on Homepage
	@FindBy(xpath = "//i[@class='fab fa-facebook-square']")
	private WebElement Facebook;
		
    @FindBy(xpath = "//i[@class='fab fa-instagram']")
	private WebElement Instagram;
		
    @FindBy(xpath = "//i[@class='fab fa-youtube ']")
    private WebElement Youtube;
		
	@FindBy(xpath = "//i[@class='fab fa-twitter']")
	private WebElement Twitter;
		
	// Webelement for Social media links on Homepage
	public WebElement facebook() {
		return Facebook;
	}

	public WebElement instagram() {
		return Instagram;
	}

	public WebElement youtube() {
		return Youtube;
	}

    public WebElement twitter() {
		return Twitter;
	}
    
    //Xpath for Find your match button in recommender
    @FindBy(xpath = "//*[contains(@class, 'col-5')]//a[text()='Find your Dream Match']")
    private WebElement  FindYourMatchButton ;
					
    // Webelement for retry link on Mattress recommender link
    public WebElement findYourMatchButton() {
 		return FindYourMatchButton;
	}
	
    public void findMatchSection() 
	   {		
		  Actions findmatch = new Actions(driver); 
		  findmatch.moveToElement(FindYourMatchButton).build().perform();
		  FindYourMatchButton.click();
		}
    
    //Xpath for Different categories in Sleep by Categories section
    @FindBy(xpath = "(//a[@href='/mattresses/'])[3]")
    private WebElement  MattressCategory ;
    
    @FindBy(xpath = "(//a[@href='/pillow/'])[3]")
    private WebElement  PillowsCategory ;
    
    @FindBy(xpath = "(//a[@href='/bedding/'])[2]")
    private WebElement  BeddingCategory ;
    
    @FindBy(xpath = "//a[@class='d-block sc-byCat-el l_green-bg ohayo-catEl']")
    private WebElement  OhayoBedCategory ;
    
    @FindBy(xpath = "//a[@class='d-block sc-byCat-el l_orange-bg petbed-catEl']")
    private WebElement  PetBedCategory ;
    
    @FindBy(xpath = "(//a[@href='/baby-bedding-sets-and-pillows'])")
    private WebElement  BabyRangeCategory ;
    
    @FindBy(xpath = "(//a[@href='/bundle/'])[4]")
    private WebElement  BundleCategory ;
					
    // Webelement for Different categories in Sleep by Categories section
    public WebElement mattressCategory() {
 		return MattressCategory;
	}
    
    public WebElement pillowsCategory() {
 		return PillowsCategory;
	}
    
    public WebElement beddingCategory() {
 		return BeddingCategory;
	}
    
    public WebElement ohayoBedCategory() {
 		return OhayoBedCategory;
	}
    
    public WebElement petBedCategory() {
 		return PetBedCategory;
	}
    
    public WebElement BabyRangeCategory() {
 		return BabyRangeCategory;
	}
    
    public WebElement bundleCategory() {
 		return BundleCategory;
	}
    
    public void mattressCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(MattressCategory).click().build().perform();		
 	}
    
    public void pillowsCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(PillowsCategory).build().perform();
 	  PillowsCategory.click();
 	}
    
    public void beddingCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(BeddingCategory).click().build().perform();		
 	}
    
    public void ohayoBedCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(OhayoBedCategory).click().build().perform();		
 	}
    
    public void petBedCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(PetBedCategory).click().build().perform();		
 	}
    
    public void BabyRangeCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(BabyRangeCategory).click().build().perform();		
 	}
    
    public void bundleCategoryInSleepCategorySection() 
    {		
 	  Actions categoryscroll = new Actions(driver); 
 	  categoryscroll.moveToElement(BundleCategory).click().build().perform();		
 	}
	
    
  // Xpath for all the products present in Our most loved products section
 	@FindBy(xpath = "//div[@id='product_page_629264']//a[@class='shop-more']")
 	private WebElement PlusMattressProduct;
 		
     @FindBy(xpath = "//div[@id='product_page_98749']//a[@class='shop-more']")
 	private WebElement MemoryFoamPillowProduct;
 		
     @FindBy(xpath = "//div[@id='product_page_629227']//a[@class='shop-more']")
     private WebElement OriginalMattressProduct;
 		
 	@FindBy(xpath = "//div[@id='product_page_214599']//a[@class='shop-more']")
 	private WebElement ReversibleComforterProduct;
 		
 	// Webelement for all the products present in Our most loved products section
 	public WebElement plusMattressProduct() {
 		return PlusMattressProduct;
 	}

 	public WebElement memoryFoamPillowProduct() {
 		return MemoryFoamPillowProduct;
 	}

 	public WebElement originalMattressProduct() {
 		return OriginalMattressProduct;
 	}

     public WebElement reversibleComforterProduct() {
 		return ReversibleComforterProduct;
 	}
       
   public void plusMattressInMostLovedProductSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(PlusMattressProduct).click().build().perform();		
	}
   
   public void memoryPillowInMostLovedProductSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(MemoryFoamPillowProduct).click().build().perform();		
	}
   
   public void originalMattressInMostLovedProductSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(OriginalMattressProduct).click().build().perform();		
	}
   
   public void reversibleComforterInMostLovedProductSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(ReversibleComforterProduct).click().build().perform();		
	}
   
   
// Xpath for all the products present in New from Sleepycat products section
 	@FindBy(xpath = "//div[@id='product_page_671178']//a[@class='shop-more']")
 	private WebElement OhayoBedProduct;
 		
     @FindBy(xpath = "//div[@id='product_page_830548']//a[@class='shop-more']")
 	private WebElement WeightedBlanketProduct;
 		
     @FindBy(xpath = "//*[contains(@class, 'bed-products-grid')]//*[@id='product_page_750272']/div[2]/a")
     private WebElement PetBedProduct;
 		
 	@FindBy(xpath = "//div[@id='product_page_214595']//a[@class='shop-more']")
 	private WebElement CuddlePillowProduct;
 		
 	// Webelement for all the products present in New from Sleepycat products section
 	public WebElement ohayoBedProduct() {
 		return OhayoBedProduct;
 	}

 	public WebElement weightedBlanketProduct() {
 		return WeightedBlanketProduct;
 	}

 	public WebElement petBedProduct() {
 		return PetBedProduct;
 	}

     public WebElement cuddlePillowProduct() {
 		return CuddlePillowProduct;
 	}
       
   public void ohayoBedProductInNewfromSleepycatSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(OhayoBedProduct).click().build().perform();		
	}
   
   public void weightedBlanketProductInNewfromSleepycatSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(WeightedBlanketProduct).click().build().perform();		
	}
   
   public void petBedProductInNewfromSleepycatSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(PetBedProduct).click().build().perform();		
	}
   
   public void cuddlePillowProductInNewfromSleepycatSection() 
   {		
	  Actions productscroll = new Actions(driver); 
	  productscroll.moveToElement(CuddlePillowProduct).click().build().perform();		
	}
   
    //New and buzz worthy section 
    @FindBy(xpath = "//a[@href='/mattress-recommender'][2]")
	private WebElement TakeMattressQuizButton;
		
    @FindBy(xpath = "//a[@href='/pillow-recommender'][2]")
	private WebElement TakethePillowQuizButton;
		
    @FindBy(xpath = "//a[@href='/bundle'][2]")
    private WebElement ShopBundlesButton;
		
	// Webelement for New and buzz worthy section 
	public WebElement takeMattressQuizButton() {
		return TakeMattressQuizButton;
	}

	public WebElement takethePillowQuizButton() {
		return TakethePillowQuizButton;
	}

	public WebElement shopBundlesButton() {
		return ShopBundlesButton;
	}
	
   

}
