package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Comforter {
	
	static RemoteWebDriver driver;
	
	 public Comforter(RemoteWebDriver driver) throws Exception
	   {
        this.driver = driver; 
        PageFactory.initElements(driver, this);
      }
	 
		/*
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-COMF-S-90x60']")
		 * private WebElement SingleCategoryComforterProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * singleCategoryComforterProductAddedInCart() { return
		 * SingleCategoryComforterProductAddedInCart; }
		 * 
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CFCOMF-D-90x100']")
		 * private WebElement DoubleCategoryCoffeColorComforterProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * doubleCategoryCoffeColorComforterProductAddedInCart() { return
		 * DoubleCategoryCoffeColorComforterProductAddedInCart; }
		 */
	
	//Xpath for Color options of Comforter on product details page
	@FindBy(xpath = "(//li[@data-value='coffee'])")
    private WebElement ComforterCoffeeColor;
	
	@FindBy(xpath = "(//li[@data-value='pink'])")
    private WebElement ComforterPinkColor;
	
	// Webelement for Color options of Comforter on product details page
	public WebElement comforterCoffeeColor() {
		return ComforterCoffeeColor;
	}
			
	public WebElement comforterPinkColor() {
		return ComforterPinkColor;
	}
	 
	
	//Add to cart button
    @FindBy(xpath = "(//button[@data-productid='214599'])[2]")
    private WebElement ComforterAddToCartButton;
			
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement comforterAddToCartButton() {
		return ComforterAddToCartButton;
	}
	
	 public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
			//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
			//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		    Actions cart = new Actions(driver);
			cart.moveToElement(ComforterAddToCartButton).click(ComforterAddToCartButton).build().perform();
		}

}
