package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class AllBeddingProductsListingpage {
	
	static RemoteWebDriver driver;
	
	 public AllBeddingProductsListingpage(RemoteWebDriver driver) throws Exception
	   {
	    this.driver = driver; 
	   //MyPageFactory.initElements(driver, this);
	    PageFactory.initElements(driver, this);
	   }
	   
		// Xpath for All Bedding products learn more section
	   @FindBy(xpath = "(//div[@data-producttype='petbed']//a[text()='SHOP NOW'])")
	   private WebElement PetBedShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='weighted_blanket']//a[text()='SHOP NOW'])")
	   private WebElement WeightedBlanketShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='comforter']//a[text()='SHOP NOW'])")
	   private WebElement ReversibleComforterShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='protector']//a[text()='SHOP NOW'])")
	   private WebElement MattressProtectorShopNow;
	   
	   @FindBy(xpath = "(//div[@data-producttype='muslin']//a[text()='SHOP NOW'])")
	   private WebElement MuslinThrowShopNow;
	   
	   @FindBy(xpath = "(//div[@data-producttype='luxe_comforter']//a[text()='SHOP NOW'])")
	   private WebElement LuxeComforterShopNow;
	   
	   @FindBy(xpath = "(//div[@data-producttype='knitted_throw']//a[text()='SHOP NOW'])")
	   private WebElement KnittedThrowShopNow;
		
		// Webelement for All Bedding products learn more section
		public WebElement petBedShopNow() {
			return PetBedShopNow;
		}

		public WebElement weightedBlanketShopNow() {
			return WeightedBlanketShopNow;
		}

		public WebElement reversibleComforterShopNow() {
			return ReversibleComforterShopNow;
		}

		public WebElement mattressProtectorShopNow() {
			return MattressProtectorShopNow;
		}
		
		public WebElement muslinThrowShopNow() {
			return MuslinThrowShopNow;
		}
		
		public WebElement luxeComforterShopNow() {
			return LuxeComforterShopNow;
		}
		
		public WebElement knittedThrowShopNow() {
			return KnittedThrowShopNow;
		}

}
