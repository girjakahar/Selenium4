package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Protector {
	
	static RemoteWebDriver driver;
	
	 public Protector(RemoteWebDriver driver) throws Exception
	   {
         this.driver = driver; 
         PageFactory.initElements(driver, this);
       }
	 
		/*
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PROT-S-72x36']")
		 * private WebElement SingleCategoryProtector72x36ProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * singleCategoryProtector72x36ProductAddedInCart() { return
		 * SingleCategoryProtector72x36ProductAddedInCart; }
		 * 
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PROT-D-75x48']")
		 * private WebElement DoubleCategoryProtector75x48ProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * doubleCategoryProtector75x48ProductAddedInCart() { return
		 * DoubleCategoryProtector75x48ProductAddedInCart; }
		 */
	
	//Mattress Protector size section on product details page
	// Dropdown option when Inch is selected in Protector and when category is double
	@FindBy(xpath = "//ul[@class='protector']//li[@data-sku='SC-PROT-D-75x48']")
    private WebElement DoubleProtector75x48;

	@FindBy(xpath = "//ul[@class='protector']//li[@data-sku='SC-PROT-D-78x48']")
    private WebElement DoubleProtector78x48;

    // Webelement when Inch is selected in Protector and when category is double
	public WebElement doubleProtector75x48() {
		return DoubleProtector75x48;
	}

	public WebElement doubleProtector78x48() {
		return DoubleProtector78x48;
	}
		
		
	// Mattress Protector size section on product details page
	// Dropdown size option in Protector when category is Single
	@FindBy(xpath = "//ul[@class='protector']//li[@data-sku='SC-PROT-S-75x36']")
    private WebElement SingleProtector75x36;
	
	@FindBy(xpath = "//ul[@class='protector']//li[@data-sku='SC-PROT-S-78x36']")
    private WebElement SingleProtector78x36;

	// Webelement when Inch is selected in Protector and when category is Single
	public WebElement singleProtector75x36() {
		return SingleProtector75x36;
	}

	public WebElement singleProtector78x36() {
		return SingleProtector78x36;
	}
	 
	        // Mattress Protector Color section on product details page
			// Dropdown size option in Protector when category is Single
			@FindBy(xpath = "//li[@data-value='pgrey']")
			private WebElement GreyProtector;
					
	    	@FindBy(xpath = "//li[@data-value='pwhite']")
		    private WebElement WhiteProtector;

			// Webelement when Inch is selected in Protector and when category is Single
			public WebElement greyProtector() {
				return GreyProtector;
			}

			public WebElement whiteProtector() {
				return WhiteProtector;
			}
	
	//Add to cart button
	@FindBy(xpath = "(//button[@data-productid='94872'])[2]")
    private WebElement ProtectorAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement protectorAddToCartButton() {
		return ProtectorAddToCartButton;
	}
	
	 public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
			//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
			//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
			Actions cart = new Actions(driver);
			cart.moveToElement(ProtectorAddToCartButton).click(ProtectorAddToCartButton).build().perform();
		}

}
