package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllPillowsProductsListingPage {
	
	static RemoteWebDriver driver;
	
	 public AllPillowsProductsListingPage(RemoteWebDriver driver) throws Exception
	   {
	    this.driver = driver; 
	   //MyPageFactory.initElements(driver, this);
	    PageFactory.initElements(driver, this);
	   }

	// Xpath for Banner section 
	   @FindBy(xpath = "(//div[@data-producttype='cooltecmemorypillow']//a[text()='SHOP NOW'])")
	   private WebElement CoolTecMemoryFoamPillowShopNowButton;
	   
	   @FindBy(xpath = "(//div[@data-producttype='contourcooltecmemorypillow']//a[text()='SHOP NOW'])")
	   private WebElement ConTourCoolTecMemoryFoamPillowShopNowButton;
	   
	   @FindBy(xpath = "(//div[@data-producttype='contoursofttouchpillow']//a[text()='SHOP NOW'])")
	   private WebElement ConTourSoftTouchMemoryFoamPillowShopNowButton;
		
	   @FindBy(xpath = "(//div[@data-producttype='pillow']//a[text()='SHOP NOW'])")
	   private WebElement SoftTouchMemoryFoamPillowShopNowButton;
		
	   @FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//a[text()='SHOP NOW'])")
	   private WebElement CloudPillowShopNowButton;
	   
	   @FindBy(xpath = "(//div[@data-producttype='body_pillow']//a[text()='SHOP NOW'])")
	   private WebElement CuddlePillowShopNowButton;
		
	   @FindBy(xpath = "(//div[@data-producttype='slim_pillow']//a[text()='SHOP NOW'])")
	   private WebElement SlimPillowShopNowButton;
		
	   @FindBy(xpath = "(//div[@data-producttype='hybrid_pillow']//a[text()='SHOP NOW'])")
	   private WebElement HybridPillowShopNowButton;
	   
	   @FindBy(xpath = "(//div[@data-producttype='pillow_case']//a[text()='SHOP NOW'])")
	   private WebElement PillowCasesShopNowButton;
		
		
		// Webelement for banner section
		public WebElement coolTecMemoryFoamPillowShopNowButton() {
			return CoolTecMemoryFoamPillowShopNowButton;
		}
		
		public WebElement conTourCoolTecMemoryFoamPillowShopNowButton() {
			return ConTourCoolTecMemoryFoamPillowShopNowButton;
		}
		
		public WebElement conTourSoftTouchMemoryFoamPillowShopNowButton() {
			return ConTourSoftTouchMemoryFoamPillowShopNowButton;
		}

		public WebElement softTouchMemoryFoamPillowShopNowButton() {
			return SoftTouchMemoryFoamPillowShopNowButton;
		}

		public WebElement cloudPillowShopNowButton() {
			return CloudPillowShopNowButton;
		}
		
		public WebElement cuddlePillowShopNowButton() {
			return CuddlePillowShopNowButton;
		}

		public WebElement slimPillowShopNowButton() {
			return SlimPillowShopNowButton;
		}

		public WebElement hybridPillowShopNowButton() {
			return HybridPillowShopNowButton;
		}
		
		public WebElement pillowCasesShopNowButton() {
			return PillowCasesShopNowButton;
		}
		
		
		
		// Xpath for Banner section 
	   @FindBy(xpath = "(//a[contains(@href,'/pillow/memory-foam-pillow/')])[5]")
	   private WebElement MemoryFoamPillowImage;
		
	   @FindBy(xpath = "(//a[contains(@href,'/pillow/cloud-microfiber-pillow/')])[5]")
	   private WebElement CloudPillowImage;
		
	   @FindBy(xpath = "(//a[contains(@href,'pillow/pregnancy-body-pillow/')])[5]")
	   private WebElement CuddlePillowImage;
		
		
		// Webelement for banner section
		public WebElement memoryFoamPillowImage() {
			return MemoryFoamPillowImage;
		}

		public WebElement cloudPillowImage() {
			return CloudPillowImage;
		}

		public WebElement cuddlePillowImage() {
			return CuddlePillowImage;
		}
		
		public void softTouchMemoryFoamShopNowclick() 
	    {		
	 	  Actions categoryscroll = new Actions(driver); 
	 	  //categoryscroll.moveToElement(PillowsCategory).click().build().perform();
	 	  categoryscroll.moveToElement(SoftTouchMemoryFoamPillowShopNowButton).click().build().perform();		
	 	}
}
