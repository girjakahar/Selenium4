package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CompareMattressPage {
	
	static RemoteWebDriver driver;

    public CompareMattressPage(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }

    //Original mattress product section
    //Xpath for Type field for Original Mattress
    @FindBy(xpath = "//div[@class='column1 crossSellOuterDiv productData product1 crossSellList']//div[@data-name='scategory']")
    private WebElement OriginalMattressTypeField;
    
    //Webelement for Type field for Original Mattress
    public WebElement originalMattressTypeField() {
  		return OriginalMattressTypeField;
  	}
    
   //Xpath for Type dropdown options for Original Mattress
    @FindBy(xpath = "//div[@class='column1 crossSellOuterDiv productData product1 crossSellList']//li[@data-value='Double']")
    private WebElement OriginalMattressDoubleType;
    
    @FindBy(xpath = "//div[@class='column1 crossSellOuterDiv productData product1 crossSellList']//li[@data-value='Single']")
    private WebElement OriginalMattressSingleType;
    
    //Webelement for Type dropdown options for Original Mattress
    public WebElement OriginalMattressDoubleType() {
  		return OriginalMattressDoubleType;
  	}
    
    public WebElement OriginalMattressSingleType() {
  		return OriginalMattressSingleType;
  	}
    
    public void typeSelectInOriginalMattress() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(OriginalMattressTypeField).click().build().perform();
          cart.moveToElement(OriginalMattressDoubleType).click().build().perform();
    }
    
    //Xpath for Size dropdown options for Original Mattress
    @FindBy(xpath = "//div[@data-sliderparent='compare_cross_sell_wrap']//div//div[@name='variations original']")
    private WebElement OriginalMattressSizeField;
    
    //Webelement for Type dropdown options for Original Mattress
    public WebElement originalMattressSizeField() {
  		return OriginalMattressSizeField;
  	}
    
    //Xpath for different Size dropdown options for Original Mattress when type is Double
    @FindBy(xpath = "//div[@class='customDropdown variations original']//li[@data-sku='SC-ORIG-D-75x48x6']")
    private WebElement OriginalMattressDouble75x48x6;
    
    @FindBy(xpath = "//div[@class='customDropdown variations original']//li[@data-sku='SC-ORIG-D-78x48x6']")
    private WebElement OriginalMattressDouble78x48x6;
    
    //Webelement for different Size dropdown options for Original Mattress when type is Double
    public WebElement originalMattressDouble75x48x6() {
  		return OriginalMattressDouble75x48x6;
  	}
    
    public WebElement originalMattressDouble78x48x6() {
  		return OriginalMattressDouble78x48x6;
  	}
    
    public void sizeSelectInOriginalMattress() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(OriginalMattressSizeField).click().build().perform();
          cart.moveToElement(OriginalMattressDouble75x48x6).click().build().perform();
    }
    
    
    //Xpath for Quantity field for Original Mattress
    @FindBy(xpath = "//div[@class='customDropdown original']")
    private WebElement OriginalMattressQuantityField;
    
    //Webelement for Quantity field for Original Mattress
    public WebElement originalMattressQuantityField() {
  		return OriginalMattressQuantityField;
  	}
    
    //Xpath for Quantity select for Original Mattress
    @FindBy(xpath = "//div[@class='customDropdown original']//li[@data-value='7']")
    private WebElement QuantitySelectionOriginalMattress;
	
    //Webelement for Quantity select for Original Mattress
	public WebElement quantitySelectionOriginalMattress() {
		return QuantitySelectionOriginalMattress;
	}
    
	
	public void selectQuantityForOriginalMattress() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(OriginalMattressQuantityField).click().build().perform();
          QuantitySelectionOriginalMattress.click();
    }
	
    //Xpath for Add to cart button when type is double and size is 75x48x6 for Original Mattress
    @FindBy(xpath = "//span[@data-sku='SC-ORIG-D-75x48x6']")
    private WebElement AddToCartButtonForOriginalMattressDouble75x48x6;
    
    //Webelement for Type dropdown options for Original Mattress
    public WebElement addToCartButtonForOriginalMattressDouble75x48x6() {
  		return AddToCartButtonForOriginalMattressDouble75x48x6;
  	}
    
  //Xpath for Add to cart button when type is double and size is 72x48x6 for Original Mattress
    @FindBy(xpath = "//span[@data-sku='SC-ORIG-D-72x48x6']")
    private WebElement AddToCartButtonForOriginalMattressDouble72x48x6;
    
    //Webelement for Type dropdown options for Original Mattress
    public WebElement addToCartButtonForOriginalMattressDouble72x48x6() {
  		return AddToCartButtonForOriginalMattressDouble72x48x6;
  	}
    
    public void addToCartOriginalMattressDouble75x48x6() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(AddToCartButtonForOriginalMattressDouble75x48x6).build().perform();
    }
    
    public void addToCartOriginalMattressDouble72x48x6() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(AddToCartButtonForOriginalMattressDouble72x48x6).click().build().perform();
    }
    
     //Latex mattress product section
    //Xpath for Type field for Original Mattress
    @FindBy(xpath = "//div[@class='column3 crossSellOuterDiv productData product3 crossSellList']//div[@data-name='scategory']")
    private WebElement LatexMattressTypeField;
    
    //Webelement for Type field for Latex Mattress
    public WebElement latexMattressTypeField() {
  		return LatexMattressTypeField;
  	}
    
   //Xpath for Type dropdown options for Latex Mattress
    @FindBy(xpath = "//div[@class='column3 crossSellOuterDiv productData product3 crossSellList']//li[@data-value='Queen']")
    private WebElement LatexMattressQueenType;
    
    @FindBy(xpath = "//div[@class='column3 crossSellOuterDiv productData product3 crossSellList']//li[@data-value='King']")
    private WebElement LatexMattressKingType;
    
    //Webelement for Type dropdown options for Latex Mattress
    public WebElement latexMattressQueenType() {
  		return LatexMattressQueenType;
  	}
    
    public WebElement latexMattressKingType() {
  		return LatexMattressKingType;
  	}
    
    public void typeSelectInLatexMattress() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(LatexMattressTypeField).click().build().perform();
          cart.moveToElement(LatexMattressQueenType).click().build().perform();
    }
    
    //Xpath for Size dropdown options for Latex Mattress
    @FindBy(xpath = "//div[@data-sliderparent='compare_cross_sell_wrap']//div//div[@name='variations latex']")
    private WebElement LatexMattressSizeField;
    
    //Webelement for Type dropdown options for Latex Mattress
    public WebElement latexMattressSizeField() {
  		return LatexMattressSizeField;
  	}
    
    //Xpath for different Size dropdown options for Latex Mattress when type is Queen
    @FindBy(xpath = "//div[@class='customDropdown variations latex']//li[@data-sku='SC-LATEX-Q-75x60x7']")
    private WebElement LatexMattressQueen75x60x7;
    
    @FindBy(xpath = "//div[@class='customDropdown variations latex']//li[@data-sku='SC-LATEX-Q-78x60x7']")
    private WebElement LatexMattressQueen78x60x7;
    
    //Webelement for different Size dropdown options for Latex Mattress when type is Queen
    public WebElement LatexMattressQueen75x60x7() {
  		return LatexMattressQueen75x60x7;
  	}
    
    public WebElement LatexMattressQueen78x60x7() {
  		return LatexMattressQueen78x60x7;
  	}
    
    public void sizeSelectInLatexMattress() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(LatexMattressSizeField).click().build().perform();
          cart.moveToElement(LatexMattressQueen75x60x7).click().build().perform();
    }
    
    
    //Xpath for Quantity field for Latex Mattress
    @FindBy(xpath = "//div[@class='customDropdown latex']")
    private WebElement LatexMattressQuantityField;
    
    //Webelement for Quantity field for Latex Mattress
    public WebElement latexMattressQuantityField() {
  		return LatexMattressQuantityField;
  	}
    
    //Xpath for Quantity select for Latex Mattress
    @FindBy(xpath = "//div[@class='customDropdown latex']//li[@data-value='7']")
    private WebElement QuantitySelectionLatexMattress;
	
    //Webelement for Quantity select for Latex Mattress
	public WebElement quantitySelectionLatexMattress() {
		return QuantitySelectionLatexMattress;
	}
    
	
	public void selectQuantityForLatexMattress() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(LatexMattressQuantityField).click().build().perform();
          QuantitySelectionLatexMattress.click();
    }
	
    //Xpath for Add to cart button when type is Queen and size is 75x60x7 for Latex Mattress
    @FindBy(xpath = "//span[@data-sku='SC-LATEX-Q-75x60x7']")
    private WebElement AddToCartButtonForLatexMattressQueen75x60x7;
    
    //Webelement for Add to cart button when type is Queen and size is 75x60x7 for Latex Mattress
    public WebElement addToCartButtonForLatexMattressQueen75x60x7() {
  		return AddToCartButtonForLatexMattressQueen75x60x7;
  	}
    
    public void addToCartLatexMattress() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(AddToCartButtonForLatexMattressQueen75x60x7).click().build().perform();
    }
    
    
    //Plus mattress product section
    //Xpath for Type field for Plus Mattress
    @FindBy(xpath = "//div[@class='column2 crossSellOuterDiv productData product2 crossSellList']//div[@data-name='scategory']")
    private WebElement PlusMattressTypeField;
    
    //Webelement for Type field for Plus Mattress
    public WebElement plusMattressTypeField() {
  		return PlusMattressTypeField;
  	}
    
   //Xpath for Type dropdown options for Plus Mattress
    @FindBy(xpath = "//div[@class='column2 crossSellOuterDiv productData product2 crossSellList']//li[@data-value='Double']")
    private WebElement PlusMattressDoubleType;
    
    @FindBy(xpath = "//div[@class='column2 crossSellOuterDiv productData product2 crossSellList']//li[@data-value='Queen']")
    private WebElement PlusMattressQueenType;
    
    //Webelement for Type dropdown options for Plus Mattress
    public WebElement plusMattressDoubleType() {
  		return PlusMattressDoubleType;
  	}
    
    public WebElement plusMattressQueenType() {
  		return PlusMattressQueenType;
  	}
    
    public void typeSelectInPlusMattress() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(PlusMattressTypeField).click().build().perform();
          cart.moveToElement(PlusMattressDoubleType).click().build().perform();
    }
    
    //Xpath for Size dropdown options for Plus Mattress
    @FindBy(xpath = "//div[@data-sliderparent='compare_cross_sell_wrap']//div//div[@name='variations plus']")
    private WebElement PlusMattressSizeField;
    
    //Webelement for Type dropdown options for Plus Mattress
    public WebElement plusMattressSizeField() {
  		return PlusMattressSizeField;
  	}
    
    //Xpath for different Size dropdown options for Plus Mattress when type is Double
    @FindBy(xpath = "//div[@class='customDropdown variations plus']//li[@data-sku='SC-PLUS-D-75x48x8']")
    private WebElement PlusMattressDouble75x48x8;
    
    @FindBy(xpath = "//div[@class='customDropdown variations plus']//li[@data-sku='SC-PLUS-D-78x48x8']")
    private WebElement PlusMattressDouble78x48x8;
    
    //Webelement for different Size dropdown options for Plus Mattress when type is Double
    public WebElement plusMattressDouble75x48x8() {
  		return PlusMattressDouble75x48x8;
  	}
    
    public WebElement plusMattressDouble78x48x8() {
  		return PlusMattressDouble78x48x8;
  	}
    
    public void sizeSelectInPlusMattress() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(PlusMattressSizeField).click().build().perform();
          cart.moveToElement(PlusMattressDouble75x48x8).click().build().perform();
    }
    
    
    //Xpath for Quantity field for Plus Mattress
    @FindBy(xpath = "//div[@class='customDropdown plus']")
    private WebElement PlusMattressQuantityField;
    
    //Webelement for Quantity field for Plus Mattress
    public WebElement plusMattressQuantityField() {
  		return PlusMattressQuantityField;
  	}
    
    //Xpath for Quantity select for Plus Mattress
    @FindBy(xpath = "//div[@class='customDropdown plus']//li[@data-value='7']")
    private WebElement QuantitySelectionPlusMattress;
	
    //Webelement for Quantity select for Plus Mattress
	public WebElement quantitySelectionPlusMattress() {
		return QuantitySelectionPlusMattress;
	}
    
	
	public void selectQuantityForPlusMattress() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(PlusMattressQuantityField).click().build().perform();
          QuantitySelectionPlusMattress.click();
    }
	
    //Xpath for Add to cart button when type is Double and size is 75x48x8 for Plus Mattress
    @FindBy(xpath = "//span[@data-sku='SC-PLUS-D-75x48x8']")
    private WebElement AddToCartButtonForPlusMattressDouble75x48x8;
    
    //Webelement for Add to cart button when type is Double and size is 75x48x8 for Plus Mattress
    public WebElement addToCartButtonForPlusMattressDouble75x48x8() {
  		return AddToCartButtonForPlusMattressDouble75x48x8;
  	}
    
    public void addToCartPlusMattress() 
    {
		  Actions cart = new Actions(driver); 
          cart.moveToElement(AddToCartButtonForPlusMattressDouble75x48x8).click().build().perform();
    }

}
