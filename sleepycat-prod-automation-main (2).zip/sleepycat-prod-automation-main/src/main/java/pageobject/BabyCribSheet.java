package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BabyCribSheet {
	
	static RemoteWebDriver driver;
	
	 public BabyCribSheet(RemoteWebDriver driver) throws Exception
	   {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
     }
	 
	 
	       //Xpath for Cloud pillow Standard,President Category option on product details page
			@FindBy(xpath = "//li[text()='President']")
		    private WebElement PresidentCategory;
						
			@FindBy(xpath = "//li[text()='Standard']")
			private WebElement StandardCategory;
						
		   // Webelement for Cloud pillow President Category option on product details page
			public WebElement presidentCategory() {
				return PresidentCategory;
			}
						
			public WebElement standardCategory() {
				return StandardCategory;
			}
			
			
			    //Xpath for different Pack size on product details page of memory Pillow
				@FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='sheet-1']")
			    private WebElement OneSheetPackSize;
							
				@FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='sheet-2']")
				private WebElement TwoSheetPackSize;
						
				// Webelement for different Pack size on product details page of Cloud Pillow
				public WebElement oneSheetPackSize() {
					return OneSheetPackSize;
				}
						
				public WebElement twoSheetPackSize() {
					return TwoSheetPackSize;
				}
					 
				
				//Add to cart button
				@FindBy(xpath = "//button[@data-productid='2158931']")
			    private WebElement BabyCribSheetAddToCartButton;
				
				// Webelement for Add to cart button 
				public WebElement babyCribSheetAddToCartButton() {
					return BabyCribSheetAddToCartButton;
				}
				
			    public void addToCart()
			    {
					//List<AndroidElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
					//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
					//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
			    	Actions cart = new Actions(driver);
				    cart.moveToElement(BabyCribSheetAddToCartButton).click(BabyCribSheetAddToCartButton).build().perform();
			}	 

}
