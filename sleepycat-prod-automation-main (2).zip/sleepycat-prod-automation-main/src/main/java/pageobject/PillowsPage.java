package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PillowsPage {
	
	static RemoteWebDriver driver;

    public PillowsPage(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }

     //Memory Foam Pillow product section
    //Xpath for Type field for Memory Foam pillow
    @FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//div[@data-name='scategory']")
    private WebElement MemoryFoamPillowTypeField;
    
    //Webelement for Type field for Memory Foam pillow
    public WebElement memoryFoamPillowTypeField() {
  		return MemoryFoamPillowTypeField;
  	}
    
   //Xpath for Type dropdown options for Memory Foam pillow
    @FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//li[@data-value='President']")
    private WebElement MemoryFoamPillowPresidentType;
    
    @FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//li[@data-value='Standard']")
    private WebElement MemoryFoamPillowStandardTypeField;
    
    //Webelement for Type dropdown options for Memory Foam pillow
    public WebElement memoryFoamPillowPresidentType() {
  		return MemoryFoamPillowPresidentType;
  	}
    
    public WebElement memoryFoamPillowStandardTypeField() {
  		return MemoryFoamPillowStandardTypeField;
  	}
    
    public void typeSelectionInMemoryFaomPillow() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(MemoryFoamPillowTypeField).click().build().perform();
          cart.moveToElement(MemoryFoamPillowPresidentType).click().build().perform();
    }
    
    //Xpath for Pack field for Memory Foam pillow
    @FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//div[@data-name='pack']")
    private WebElement MemoryFoamPillowPackField;
    
    //Webelement for Pack field for Memory Foam pillow
    public WebElement memoryFoamPillowPackField() {
  		return MemoryFoamPillowPackField;
  	}
    
    //Xpath for Pack dropdown options for Memory Foam pillow
    @FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//li[@data-value='pillow-2']")
    private WebElement MemoryFoamPillowPackOfTwo;
    
    @FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//li[@data-value='pillow-4']")
    private WebElement MemoryFoamPillowPackOfFour;
    
    //Webelement for Pack dropdown options for Memory Foam pillow
    public WebElement MemoryFoamPillowPackOfTwo() {
  		return MemoryFoamPillowPackOfTwo;
  	}
    
    public WebElement memoryFoamPillowPackOfFour() {
  		return MemoryFoamPillowPackOfFour;
  	}
    
    public void packSelectionInMemoryFaomPillow() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(MemoryFoamPillowPackField).click().build().perform();
          cart.moveToElement(MemoryFoamPillowPackOfTwo).click().build().perform();
    }
    
    
    // Quantity dropdown selection field for Memory Foam pillow
 	@FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//div[@data-name='quantity']")
     private WebElement QuantityFieldInMemoryFoamPillow;
 		   
 	// Webelement for Quantity dropdown selection field for Memory Foam pillow
 	public WebElement quantityFieldInMemoryFoamPillow() {
 		return QuantityFieldInMemoryFoamPillow;
 	}
 	
 	@FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//li[@data-value='3']")
    private WebElement QuantitySelectionInMemoryFoamPillow;
	
	public WebElement quantitySelectionInMemoryFoamPillow() {
		return QuantitySelectionInMemoryFoamPillow;
	}
	
    public void quantitySelectInMemoryFaomPillow() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(QuantityFieldInMemoryFoamPillow).click().build().perform();
          cart.moveToElement(QuantitySelectionInMemoryFoamPillow).click().build().perform();
    }
    
    // Xpath for Add to cart button for Memory Foam pillow
  	@FindBy(xpath = "//span[@data-sku='SC-MFPILWSET2-P-28x18']")
    private WebElement PresidentMemoryFoamPillowPackOfTwoAddToCartButton;
  	
  	@FindBy(xpath = "//span[@data-sku='SC-MFPILWSET4-P-28x18']")
    private WebElement PresidentMemoryFoamPillowPackOfFourAddToCartButton;
  	
  	@FindBy(xpath = "//div[@class='container_cross_sell pillow primaryCrossSell']//span[@data-sku='SC-PILLOW-S-26x16x4']")
    private WebElement StandardMemoryFoamPillowPackOfOneAddToCartButton;
  		   
  	// Webelement for for Add to cart button for Memory Foam pillow
  	public WebElement presidentMemoryFoamPillowPackOfTwoAddToCartButton() {
  		return PresidentMemoryFoamPillowPackOfTwoAddToCartButton;
  	}
    
  	public WebElement presidentMemoryFoamPillowPackOfFourAddToCartButton() {
  		return PresidentMemoryFoamPillowPackOfFourAddToCartButton;
  	}
  	
  	public WebElement standardMemoryFoamPillowPackOfOneAddToCartButton() {
  		return StandardMemoryFoamPillowPackOfOneAddToCartButton;
  	}
  	
     //Cloud Pillow product section
    //Xpath for Type field for Cloud pillow
    @FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//div[@data-name='scategory']")
    private WebElement CloudPillowTypeField;
    
    //Webelement for Type field for Memory Foam pillow
    public WebElement cloudPillowTypeField() {
  		return CloudPillowTypeField;
  	}
    
   //Xpath for Type dropdown options for Cloud pillow
    @FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//li[@data-value='President']")
    private WebElement CloudPillowPresidentType;
    
    @FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//li[@data-value='Standard']")
    private WebElement CloudPillowStandardTypeField;
    
    //Webelement for Type dropdown options for Memory Foam pillow
    public WebElement cloudPillowPresidentType() {
  		return CloudPillowPresidentType;
  	}
    
    public WebElement cloudPillowStandardTypeField() {
  		return CloudPillowStandardTypeField;
  	}
    
    public void typeSelectionInCloudPillow() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(CloudPillowTypeField).click().build().perform();
          cart.moveToElement(CloudPillowPresidentType).click().build().perform();
    }
    
    //Xpath for Pack field for Cloud pillow
    @FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//div[@data-name='pack']")
    private WebElement CloudPillowPackField;
    
    //Webelement for Pack field for Memory Foam pillow
    public WebElement cloudPillowPackField() {
  		return CloudPillowPackField;
  	}
    
    //Xpath for Pack dropdown options for Memory Foam pillow
    @FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//li[@data-value='pillow-2']")
    private WebElement CloudPillowPackOfTwo;
    
    @FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//li[@data-value='pillow-4']")
    private WebElement CloudPillowPackOfFour;
    
    //Webelement for Pack dropdown options for Memory Foam pillow
    public WebElement cloudPillowPackOfTwo() {
  		return CloudPillowPackOfTwo;
  	}
    
    public WebElement cloudPillowPackOfFour() {
  		return CloudPillowPackOfFour;
  	}
    
    public void packSelectionInCloudPillow() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(CloudPillowPackField).click().build().perform();
          cart.moveToElement(CloudPillowPackOfTwo).click().build().perform();
    }
    
    
    // Quantity dropdown selection field of Cloud pillow
 	@FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//div[@data-name='quantity']")
     private WebElement QuantityFieldInCloudPillow;
 		   
 	// Webelement for Quantity dropdown selection field for Memory Foam pillow
 	public WebElement QuantityFieldInCloudPillow() {
 		return QuantityFieldInCloudPillow;
 	}
 	
 	@FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//li[@data-value='5']")
    private WebElement QuantitySelectionInCloudPillow;
	
	public WebElement QuantitySelectionInCloudPillow() {
		return QuantitySelectionInCloudPillow;
	}
	
    public void quantitySelectInCloudPillow() 
    {
		  Actions cart = new Actions(driver); 
		  cart.moveToElement(QuantityFieldInCloudPillow).click().build().perform();
          cart.moveToElement(QuantitySelectionInCloudPillow).click().build().perform();
    }
    
    // Xpath for Add to cart button for Memory Foam pillow
  	@FindBy(xpath = "//span[@data-sku='SC-CLPILWSET2-P-32x20']")
    private WebElement PresidentCloudPillowPackOfTwoAddToCartButton;
  	
  	@FindBy(xpath = "//span[@data-sku='SC-CLPILWSET4-P-32x20']")
    private WebElement PresidentCloudPillowPackOfFourAddToCartButton;
  	
  	@FindBy(xpath = "//div[@class='container_cross_sell cloud_pillow primaryCrossSell']//span[@data-sku='SC-CLPILW-S-27x18']")
    private WebElement StandardCloudPillowPackOfOneAddToCartButton;
  		   
  	// Webelement for for Add to cart button for Memory Foam pillow
  	public WebElement presidentCloudPillowPackOfTwoAddToCartButton() {
  		return PresidentCloudPillowPackOfTwoAddToCartButton;
  	}
    
  	public WebElement presidentCloudPillowPackOfFourAddToCartButton() {
  		return PresidentCloudPillowPackOfFourAddToCartButton;
  	}
  	
  	public WebElement standardCloudPillowPackOfOneAddToCartButton() {
  		return StandardCloudPillowPackOfOneAddToCartButton;
  	}
  	
     //Cuddle Pillow section
    // Quantity dropdown selection field of Cuddle pillow
  	@FindBy(xpath = "//div[@class='container_cross_sell body_pillow primaryCrossSell']//div[@data-name='quantity']")
      private WebElement QuantityFieldInCuddlePillow;
  		   
  	// Webelement for Quantity dropdown selection field for Cuddle pillow
  	public WebElement quantityFieldInCuddlePillow() {
  		return QuantityFieldInCuddlePillow;
  	}
  	
  	@FindBy(xpath = "//div[@class='container_cross_sell body_pillow primaryCrossSell']//li[@data-value='5']")
     private WebElement QuantitySelectionInCuddlePillow;
 	
 	public WebElement quantitySelectionInCuddlePillow() {
 		return QuantitySelectionInCuddlePillow;
 	}
 	
     public void quantitySelectInCuddlePillow() 
     {
 		  Actions cart = new Actions(driver); 
 		  cart.moveToElement(QuantityFieldInCuddlePillow).click().build().perform();
          cart.moveToElement(QuantitySelectionInCuddlePillow).click().build().perform();
     }
     
     // Xpath for Add to cart button for Cuddle pillow
   	@FindBy(xpath = "//div[@class='container_cross_sell body_pillow primaryCrossSell']//span[@data-sku='SC-GRBDPILWSET-S-50x19']")
     private WebElement StandardCuddlePillowAddToCartButton;
   		   
   	// Webelement for for Add to cart button for Cuddle pillow
   	public WebElement standardCuddlePillowAddToCartButton() {
   		return StandardCuddlePillowAddToCartButton;
   	}
     

}
