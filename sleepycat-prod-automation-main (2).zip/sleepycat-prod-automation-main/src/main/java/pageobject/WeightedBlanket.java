package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WeightedBlanket {
	
	static RemoteWebDriver driver;
	
	 public WeightedBlanket(RemoteWebDriver driver) throws Exception
	   {
        this.driver = driver; 
        PageFactory.initElements(driver, this);
      }
	
	
	//Xpath for Color options of Weighted Blanket on product details page
	@FindBy(xpath = "//li[@data-value='wbgrey']")
    private WebElement WeightedBlanketGreyColor;
	
	@FindBy(xpath = "//li[@data-value='wbpink']")
    private WebElement WeightedBlanketPinkColor;
	
	@FindBy(xpath = "//li[@data-value='wbmblue']")
    private WebElement WeightedBlanketBlueColor;
	
    // Webelement for Color options of Weighted Blanket on product details page
	public WebElement weightedBlanketGreyColor() {
		return WeightedBlanketGreyColor;
	}
			
	public WebElement weightedBlanketPinkColor() {
		return WeightedBlanketPinkColor;
	}
	
	public WebElement weightedBlanketBlueColor() {
		return WeightedBlanketBlueColor;
	}
	
	 
	 
	//Add to cart button
	@FindBy(xpath = "(//button[@data-productid='830548'])[2]")
    private WebElement WeightedBlanketAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement weightedBlanketAddToCartButton() {
		return WeightedBlanketAddToCartButton;
	}
	
	 public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
			//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
			//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
			Actions cart = new Actions(driver);
			cart.moveToElement(WeightedBlanketAddToCartButton).click(WeightedBlanketAddToCartButton).build().perform();
		}

}
