package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.MyPageFactory;

public class BabyMattress {
	
static RemoteWebDriver driver;
	
	public BabyMattress(RemoteWebDriver driver) throws Exception
	{
     this.driver = driver; 
     PageFactory.initElements(driver, this);
    }
	
	// Baby mattress Different Size sections
	// Drop down option when Inch,cm or feet is selected in Baby mattress for Single category
	@FindBy(xpath = "//li[@data-sku='SC-BABY-S-52x28x4']")
    private WebElement SingleBabyMattress52x28x4;
	//Above Xpath can also be used when cm or feet is selected as dimension for 132 x 71 x 10 cm and 4.33' x 2.33' x 0.33' feet
	
	@FindBy(xpath = "//li[@data-sku='SC-BABY-S-48x24x4']")
    private WebElement SingleBabyMattress48x24x4;
	//Above xpath can also be used when cm or feet is selected as dimension for 121 x 60 x 10 cm and 4' x 2' x 0.33' feet

	// Webelement for Drop down option when Inch,cm or feet is selected in Baby mattress for Single category
	public WebElement singleBabyMattress52x28x4() {
		return SingleBabyMattress52x28x4;
	}

	public WebElement singleBabyMattress48x24x4() {
		return SingleBabyMattress48x24x4;
	}
	
	//Xpath for error messages for lenght and width field for Original,plus and Latex mattress
	@FindBy(xpath = "//h6[text()='Length customization is allowed between 40 - 52 inch']")
    private WebElement BabyMattressLengthError;
		
	@FindBy(xpath = "//h6[text()='Width customization is allowed between 24 - 28 inch']")
	private WebElement BabyMattressWidthError;
		
	// Webelement for error messages for lenght and width field for Original,plus and Latex mattress
	public WebElement babyMattressLengthError() {
		return BabyMattressLengthError;
	}
			
	public WebElement babyMattressWidthError() {
		return BabyMattressWidthError;
	}
	
	//Xpath for Default add to cart button
	@FindBy(xpath = "(//button[@class='single_add_to_cart_button btn-block alt'])[2]")
    private WebElement DefaultAddtoCart;

	// Webelement for Default add to cart button
	public WebElement defaultAddtoCart() {
		return DefaultAddtoCart;
	}
	
	
	//Add to cart button
	@FindBy(xpath = "(//button[@data-productid='94873'])[2]")
    private WebElement BabyMattressAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement babyMattressAddToCartButton() {
		return BabyMattressAddToCartButton;
	}
	
	public void addToCart() {
		//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
		//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
		cart.moveToElement(BabyMattressAddToCartButton).click(BabyMattressAddToCartButton).build().perform();
	}
    

}
