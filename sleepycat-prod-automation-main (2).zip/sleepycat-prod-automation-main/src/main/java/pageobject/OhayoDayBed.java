package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OhayoDayBed {
	
	static RemoteWebDriver driver;
	
	 public OhayoDayBed(RemoteWebDriver driver) throws Exception
	   {
       this.driver = driver; 
       PageFactory.initElements(driver, this);
      }
	   
	        //Add to cart button
	 		@FindBy(xpath = "(//button[@data-productid='2132236'])[2]")
	 	    private WebElement OhayoDayBedAddToCartButton;
	 		
	 		// Webelement for different Pack size on product details page of Cloud Pillow
	 		public WebElement ohayoDayBedAddToCartButton() {
	 			return OhayoDayBedAddToCartButton;
	 		}
	 		
	 		
		 public void addToCart() {
				//List<AndroidElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));//div[@class='productDirectPurchase hidden_form plus']//button[@type='button'][normalize-space()='Add To Cart']
				//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
				//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
			    Actions cart = new Actions(driver);
				cart.moveToElement(OhayoDayBedAddToCartButton).click(OhayoDayBedAddToCartButton).build().perform();
			}

}
