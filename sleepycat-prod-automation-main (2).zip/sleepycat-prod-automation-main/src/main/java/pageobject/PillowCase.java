package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PillowCase {
	
	static RemoteWebDriver driver;
	
	 public PillowCase(RemoteWebDriver driver) throws Exception
	   {
        this.driver = driver; 
        PageFactory.initElements(driver, this);
       }
	 
	
	        //Pillow case Xpath and Webelement for different element on product details page
			//Xpath for different Category on product details page of Pillow Cases
		    @FindBy(xpath = "//div[@class='attr attr_Scategory ']//li[@data-value='Standard']")
		    private WebElement StandardPillowCaseCategory;
					
		    @FindBy(xpath = "//div[@class='attr attr_Scategory ']//li[@data-value='President']")
			private WebElement PresidentPillowCaseCategory;
			    
		    @FindBy(xpath = "//div[@class='attr attr_Scategory ']//li[@data-value='Cuddle']")
		    private WebElement CuddlePillowCaseCategory; 
				
			// Webelement for different Category on product details page of Pillow Cases
			public WebElement standardPillowCaseCategory() {
				return StandardPillowCaseCategory;
			}
				
			public WebElement presidentPillowCaseCategory() {
				return PresidentPillowCaseCategory;
			}
				
			public WebElement cuddlePillowCaseCategory() {
				return CuddlePillowCaseCategory;
			}
	
	//Xpath for different Pack size options on product details page of Pillow Cases
	@FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='case-2']")
    private WebElement TwoPillowCasesPackSize;
			
    @FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='case-4']")
	private WebElement FourPillowCasesPackSize;
	    
    @FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='case-8']")
    private WebElement EightPillowCasesPackSize; 
    
    @FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='case-1']")
    private WebElement OnePillowCasesPackSize;
	
	// Webelement for different Pack size options on product details page of Pillow Cases
	public WebElement twoPillowCasesPackSize() {
		return TwoPillowCasesPackSize;
	}
	
	public WebElement fourPillowCasesPackSize() {
		return FourPillowCasesPackSize;
	}
	
	public WebElement eightPillowCasesPackSize() {
		return EightPillowCasesPackSize;
	}
	
	public WebElement onePillowCasesPackSize() {
		return OnePillowCasesPackSize;
	}
	
	
	    //Xpath for different Color options on product details page of Pillow Cases
		@FindBy(xpath = "//li[@data-value='pc_dolphingrey']")
	    private WebElement DolphinGrayColorPillowcase;
				
	    @FindBy(xpath = "//li[@data-value='pc_twilightblue']")
		private WebElement TwilightBlueColorPillowcase;
		    
	    @FindBy(xpath = "//li[@data-value='pc_butterscotchcream']")
	    private WebElement ButterScoutchCreamColorPillowcase; 
		
		// Webelement for different Color options on product details page of Pillow Cases
		public WebElement dolphinGrayColorPillowcase() {
			return DolphinGrayColorPillowcase;
		}
		
		public WebElement twilightBlueColorPillowcase() {
			return TwilightBlueColorPillowcase;
		}
		
		public WebElement butterScoutchCreamColorPillowcase() {
			return ButterScoutchCreamColorPillowcase;
		}

		
	//Pillow cases size section on product details page
	// Size Dropdown option when memory foam pillow case category is selected on Pillow case product details page
	
	/*
	 * @FindBy(xpath =
	 * "//ul[@class='pillow_case']//li[@data-sku='SC-GRPILWCSSET2-S-28x18']")
	 * private WebElement MemoryFoamFourCases28x18;
	 * 
	 * @FindBy(xpath =
	 * "//ul[@class='pillow_case']//li[@data-sku='SC-GRPILWCSSET2-P-33x21'][1]")
	 * private WebElement MemoryFoamFourCases33x21;
	 * 
	 * // Webelement when Inch,cm or feet dimension is selected in latex mattress
	 * and when category is king public WebElement memoryFoamFourCases28x18() {
	 * return MemoryFoamFourCases28x18; }
	 * 
	 * public WebElement memoryFoamFourCases33x21() { return
	 * MemoryFoamFourCases33x21; }
	 * 
	 * 
	 * // Size Dropdown option when Cloud pillow case category is selected on Pillow
	 * case product details page
	 * 
	 * @FindBy(xpath =
	 * "//ul[@class='pillow_case']//li[@data-sku='SC-GRPILWCS-P-33x21'][2]") private
	 * WebElement CloudPillowTwoCases33x21;
	 * 
	 * @FindBy(xpath =
	 * "//ul[@class='pillow_case']//li[@data-sku='SC-GRPILWCS-S-28x18'][2]") private
	 * WebElement CloudPillowTwoCases28x18;
	 * 
	 * // Webelement option for size dropdown when Cloud pillow case category is
	 * selected on Pillow case product details page public WebElement
	 * cloudPillowTwoCases33x21() { return CloudPillowTwoCases33x21; }
	 * 
	 * public WebElement cloudPillowTwoCases28x18() { return
	 * CloudPillowTwoCases28x18; }
	 */
	 
	/*
	 * //Product added in cart XPath
	 * 
	 * @FindBy(xpath =
	 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-GRPILWCS-S-28x18']")
	 * private WebElement PillowCaseProductAddedInCart;
	 * 
	 * // Webelement for Product added in cart XPath public WebElement
	 * pillowCaseProductAddedInCart() { return PillowCaseProductAddedInCart; }
	 */
	
	/*
	 * //Product added in cart XPath
	 * 
	 * @FindBy(xpath =
	 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-GRPILWCSSET2-P-33x21']")
	 * private WebElement MemoryFoamPillowCase33x21ProductAddedInCart;
	 * 
	 * // Webelement for Product added in cart XPath public WebElement
	 * memoryFoamPillowCase33x21ProductAddedInCart() { return
	 * MemoryFoamPillowCase33x21ProductAddedInCart; }
	 */
	 
	
	//Add to cart button
	@FindBy(xpath = "//button[@data-productid='691893']")
    private WebElement PillowCaseAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement pillowCaseAddToCartButton() {
		return PillowCaseAddToCartButton;
	}
	
	public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
			//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
			//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", PillowCaseAddToCartButton);
			//Actions cart = new Actions(driver);
			//cart.moveToElement(add1).click(add1).build().perform();
		}

}
