package pageobject;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPage {
	
	RemoteWebDriver driver;
	
	@FindBy(css = "input#login-email")
	private WebElement Email;
	
	@FindBy(css = "input#login-password")
	private WebElement Password;
	
	@FindBy(xpath = "//button[@data-logindiv='LoginDiv']")
	private WebElement Submit;
	
	@FindBy(xpath = "//span[text()=' Create new account ']")
	private WebElement NewAccount;
	
	@FindBy(xpath = "//span[text()=' Forgot password? ']")
	private WebElement ForgetPassword;
	
	@FindBy(xpath = "//input[@id='forgot-password-email']")
	private WebElement ForgetEmail;
	
	@FindBy(xpath = "//*[@id='forgotPasswordDiv']//*[contains(@class, 'button')]")
	private WebElement ResetPassword;
	
	@FindBy(xpath = "//form[@id='forgotPasswordDiv']//div[@class='login-success-txt']")
	private WebElement ForgetEmailSentText;
	
	public WebElement email()
	{
		return Email;
	}

	public WebElement password()
	{
		return Password;
	}

	public WebElement submit()
	{
		return Submit;
	}

	public WebElement newAccount()
	{
		return NewAccount;
	}

	public WebElement forgetPassword()
	{
		return ForgetPassword;
	}
	
	public WebElement forgetEmail()
	{
		return ForgetEmail;
	}
	
	public WebElement resetPassword()
	{
		return ResetPassword;
	}
	
	public WebElement forgetEmailSentText()
	{
		return ForgetEmailSentText;
	}
	
	//Xpath for error login message text
	@FindBy(xpath = "//div[text()='Incorrect Email or Password']")
	private WebElement LoginErrorMessage;
	
	public WebElement loginErrorMessage()
	{
		return LoginErrorMessage;
	}
	
	
	   //Xpath for My Orders section in 
		@FindBy(xpath = "//a[text()='My Orders']")
		private WebElement MyOrderoption;
		
		public WebElement myOrderoption()
		{
			return MyOrderoption;
		}
		

	public LoginPage(RemoteWebDriver driver) throws Exception //to provide life to driver in different test cases where this Landing page object is used we have added this method
	{ 
		this.driver=driver;   
        PageFactory.initElements(driver, this);

	}
	
	public void switchingToChildWindow() 
	{
		Set<String> s1=driver.getWindowHandles();
        Iterator<String> It= s1.iterator();
		String parentWindow = It.next();
		String childWindow = It.next();
		driver.switchTo().window(childWindow);
	 }
	
	public void switchingToParentWindow() 
	{
		Set<String> s1=driver.getWindowHandles();
        Iterator<String> It= s1.iterator();
		String parentWindow = It.next();
		String childWindow = It.next();
		driver.switchTo().window(parentWindow);
	 }
	
	public void moveToForgetPassword() {
		
		Actions cart = new Actions(driver);
		cart.moveToElement(ForgetPassword).click(ForgetPassword).build().perform();
	}

}
