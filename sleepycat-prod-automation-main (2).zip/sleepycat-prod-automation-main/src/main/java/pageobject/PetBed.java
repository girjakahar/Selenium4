package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class PetBed {
	
static RemoteWebDriver driver;
	
	// Xpath for Pet Bed Category section on product details page
	@FindBy(xpath = "//li[text()='Original']")
	private WebElement OriginalCategory;
		
	@FindBy(xpath = "//li[text()='Orthopedic']")
    private WebElement OrthopedicCategory;
		
	// Webelement for Xpath for Pet Bed Category section on product details page
	public WebElement originalCategory() {
		return OriginalCategory;
	}
		
	public WebElement orthopedicCategory() {
		return OrthopedicCategory;
	}
	
	
	//Pet Bed size section on product details page
	// Dropdown option when inch is selected in Pet Bed and when category is Orthopedic
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORTHO-M-28x26']")
	private WebElement OrthopedicPetBed28x26;
			
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORTHO-L-48x24']")
    private WebElement OrthopedicPetBed48x24;
		
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORTHO-XL-52x28']")
	private WebElement OrthopedicPetBed52x28;
	
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORTHO-N.Blue-L-48X24']")
    private WebElement OrthopedicBlueColorPetBedLarge48x24;
		  
	// Webelement option when inch is selected in Pet Bed and when category is Orthopedic
	public WebElement orthopedicPetBed28x26() {
		return OrthopedicPetBed28x26;
	}

	public WebElement orthopedicPetBed48x24() {
		return OrthopedicPetBed48x24;
	}
						
	public WebElement orthopedicPetBed52x28() {
		return OrthopedicPetBed52x28;
	}
	
	public WebElement orthopedicBlueColorPetBedLarge48x24() {
		return OrthopedicBlueColorPetBedLarge48x24;
	}
			
	// Dropdown option for Pet Bed and when category is Original
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORIG-M-36x26']")
	private WebElement OriginalPetBedMedium36x26;
			
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORIG-L-46x32']")
    private WebElement OriginalPetBedLarge46x32;
		
	@FindBy(xpath = "//li[@data-sku='SC-PETBEDORIG-XL-54x36']")
	private WebElement OriginalPetBedExtraLarge54x36;
		   
	// Webelement option for Pet Bed and when category is Original
	public WebElement originalPetBedMedium36x26() {
		return OriginalPetBedMedium36x26;
	}

	public WebElement originalPetBedLarge46x32() {
		return OriginalPetBedLarge46x32;
	}
						
	public WebElement originalPetBedExtraLarge54x36() {
		return OriginalPetBedExtraLarge54x36;
	}
	
	//Different Color option for Pet Bed 
	@FindBy(xpath = "//li[@data-value='nauticblue']")
	private WebElement BlueColorPetBedOption;
			
	@FindBy(xpath = "//li[@data-value='mudred']")
    private WebElement RedColorPetBedOption;
		
	@FindBy(xpath = "//li[@data-value='greyrust']")
	private WebElement GrayColorPetBedOption;
		   
	// Webelement Color option for Pet Bed 
	public WebElement blueColorPetBedOption() {
		return BlueColorPetBedOption;
	}

	public WebElement redColorPetBedOption() {
		return RedColorPetBedOption;
	}
						
	public WebElement grayColorPetBedOption() {
		return GrayColorPetBedOption;
	}
	
	public PetBed(RemoteWebDriver driver) throws Exception
	{
     this.driver = driver; 
     PageFactory.initElements(driver, this);
    }
	
	//Add to cart button
	@FindBy(xpath = "(//button[@data-productid='750272'])[2]")
    private WebElement PetBedAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement petBedAddToCartButton() {
		return PetBedAddToCartButton;
	}
	
	public void addToCart() {
		//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
		//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
		cart.moveToElement(PetBedAddToCartButton).click(PetBedAddToCartButton).build().perform();
	}

}
