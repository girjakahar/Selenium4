package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllBedsProductsListingpage {

	static RemoteWebDriver driver;

   public AllBedsProductsListingpage(RemoteWebDriver driver) throws Exception
    {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
    }
	
	
	
	   // Xpath for All Bedding products learn more section
	   @FindBy(xpath = "(//div[@data-producttype='petbed']//a[text()='SHOP NOW'])")
	   private WebElement PetBedShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='ohayo']//a[text()='SHOP NOW'])")
	   private WebElement OhayoBedShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='ohayo_daybed']//a[text()='SHOP NOW'])")
	   private WebElement OhayoDayBedShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='ohayo_tray']//a[text()='SHOP NOW'])")
	   private WebElement OhayoBedTrayShopNow;
	   
		// Webelement for All Bedding products learn more section
		public WebElement petBedShopNow() {
			return PetBedShopNow;
		}

		public WebElement ohayoBedShopNow() {
			return OhayoBedShopNow;
		}

		public WebElement ohayoDayBedShopNow() {
			return OhayoDayBedShopNow;
		}

		public WebElement ohayoBedTrayShopNow() {
			return OhayoBedTrayShopNow;
		}

}
