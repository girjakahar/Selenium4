package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MetalBedFrame {
	
	static RemoteWebDriver driver;
	
	 public MetalBedFrame(RemoteWebDriver driver) throws Exception
	   {
         this.driver = driver; 
         PageFactory.initElements(driver, this);
       }
	 
		/*
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BED-S-78x36x16']")
		 * private WebElement MetalBedSingleCategoryProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * metalBedSingleCategoryProductAddedInCart() { return
		 * MetalBedSingleCategoryProductAddedInCart; }
		 */
	 
	 public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));//div[@class='productDirectPurchase hidden_form plus']//button[@type='button'][normalize-space()='Add To Cart']
			//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
			WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		    Actions cart = new Actions(driver);
			cart.moveToElement(add1).click(add1).build().perform();
		}

}
