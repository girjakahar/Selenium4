package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactUsPage {
	
	static RemoteWebDriver driver;

    public ContactUsPage(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }


   //Xpath for Name error text
    @FindBy(xpath = "//label[@for='fname']")
    private WebElement BlankNameErrorText;
    
   //Webelement for Name error text
   public WebElement blankNameErrorText() {
  		return BlankNameErrorText;
  	}
   
   //Xpath for Email error text
   @FindBy(xpath = "//label[@for='cemail']")
   private WebElement BlankEmailErrorText;
   
   //Webelement for Email error text
   public WebElement blankEmailErrorText() {
 		return BlankEmailErrorText;
 	}
   
   //Xpath for Message error text
   @FindBy(xpath = "//label[@for='cemail']")
   private WebElement BlankMessageErrorText;
   
   //Webelement for Message error text
   public WebElement blankMessageErrorText() {
 		return BlankMessageErrorText;
 	}
   
   //Xpath for Message error text
   @FindBy(xpath = "//div[@class='last_row_contact_form form-group']//input[@name='submit']")
   private WebElement ContactUsSubmitButton;
   
   //Webelement for Message error text
   public WebElement contactUsSubmitButton() {
 		return ContactUsSubmitButton;
 	}
   
   public void submitButton() 
   {		
	  Actions submitscroll = new Actions(driver); 
	  submitscroll.moveToElement(ContactUsSubmitButton).click().build().perform();		
	}

}
