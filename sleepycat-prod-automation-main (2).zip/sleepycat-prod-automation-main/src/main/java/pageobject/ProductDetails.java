package pageobject;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseTest;

public class ProductDetails extends BaseTest {

	static WebDriverWait wait;
	static RemoteWebDriver driver;
	public static Logger log = LogManager.getLogger(ProductDetails.class);

	public ProductDetails(RemoteWebDriver driver) throws Exception {
		this.driver = driver;
		// MyPageFactory.initElements(driver, this);
		PageFactory.initElements(driver, this);
	}

	// Category section on product details page
	@FindBy(xpath = "//li[text()='Double']")
	private WebElement DoubleCategory;

	@FindBy(xpath = "//li[text()='Queen']")
	private WebElement QueenCategory;

	@FindBy(xpath = "//li[text()='Single']")
	private WebElement SingleCategory;

	@FindBy(xpath = "//li[text()='King']")
	private WebElement KingCategory;

	@FindBy(xpath = "//li[text()='Custom Size']")
	private WebElement CustomCategory;

	@FindBy(xpath = "//li[text()='Queen + Tray']")
	private WebElement QueenPlusTrayCategory;

	@FindBy(xpath = "//li[text()='King + Tray']")
	private WebElement KingPlusTrayCategory;

	// Webelement for Category section of product details page
	public WebElement queenCategory() {
		return QueenCategory;
	}

	public WebElement singleCategory() {
		return SingleCategory;
	}

	public WebElement doubleCategory() {
		return DoubleCategory;
	}

	public WebElement kingCategory() {
		return KingCategory;
	}

	public WebElement customCategory() {
		return CustomCategory;
	}

	public WebElement queenPlusTrayCategory() {
		return QueenPlusTrayCategory;
	}

	public WebElement kingPlusTrayCategory() {
		return KingPlusTrayCategory;
	}

	@FindBy(xpath = "//li[@data-value='7']")
	private WebElement QuantitySelection;

	public WebElement quantityselection() {
		return QuantitySelection;
	}

	// Dimension section of product details page
	@FindBy(xpath = "//Span[text()=' inch ']")
	private WebElement InchDimension;

	@FindBy(xpath = "//Span[text()=' cm ']")
	private WebElement CmDimension;

	@FindBy(xpath = "//Span[text()=' feet ']")
	private WebElement FeetDimension;

	// Webelement for Dimension section on product details page
	public WebElement inchDimension() {
		return InchDimension;
	}

	public WebElement cmDimension() {
		return CmDimension;
	}

	public WebElement feetDimension() {
		return FeetDimension;
	}

	// Buy Bundle button XPath
	@FindBy(xpath = "(//button[@id='bundlePurchase'])[2]")
	private WebElement BuyBundleButton;

	// Webelement for Buy Bundle button
	public WebElement buyBundleButton() {
		return BuyBundleButton;
	}

	// Size dropdown section
	@FindBy(xpath = "//div[@Class='variations attr']")
	private WebElement SizeDropdown;

	// Webelement for sizeDropdown field
	public WebElement sizeDropdown() {
		return SizeDropdown;
	}

	// Xpath for Size chart image link text on product details page
	@FindBy(xpath = "(//div[@class='mt-2 sizeChart'])[1]")
	private WebElement MattressSizeChartImageLinkText;

	// Webelement for Size chart image link text on product details page
	public WebElement mattressSizeChartImageLinkText() {
		return MattressSizeChartImageLinkText;
	}

	// Xpath for Size chart image on product details page
	@FindBy(xpath = "//*[@id='sizeChartModal']//*[contains(@class, 'vin-lazy-load')]")
	private WebElement MattressSizeChartImage;

	// Webelement for Size chart image on product details page
	public WebElement mattressSizeChartImage() {
		return MattressSizeChartImage;
	}

	// Xpath for Size guide link text on product details page
	@FindBy(xpath = "(//div[@class='mt-2 sizeChart'])[2]")
	private WebElement MattressSizeGuideLinkText;

	// Webelement for Size Guide link text on product details page
	public WebElement MattressSizeGuideLinkText() {
		return MattressSizeGuideLinkText;
	}

	// Xpath for Size Guide image on product details page
	// @FindBy(xpath = "//*[@id='measureMattress']//*[contains(@class,
	// 'modal-content')]/img")
	@FindBy(xpath = "//*[@id='measureMattress']//*[contains(@class, 'modal-content')]/img")
	private WebElement MattressSizeGuideImage;

	// Webelement for Size Guide image on product details page
	public WebElement mattressSizeGuideImage() {
		return MattressSizeGuideImage;
	}

	// Xpath for Size chart image on product details page
	@FindBy(xpath = "//*[@id='measureMattress']//button[text()='×']")
	private WebElement MattressSizeGuideCrossIcon;

	// Webelement for Size chart image on product details page
	public WebElement mattressSizeGuideCrossIcon() {
		return MattressSizeGuideCrossIcon;
	}

	// Xpath for error messages for lenght and width field for Original,plus and
	// Latex mattress
	@FindBy(xpath = "//h6[text()='Length customization is allowed between 68 - 84 inch']")
	private WebElement LengthError;

	@FindBy(xpath = "//h6[text()='Length customization is allowed between 70 - 78 inch']")
	private WebElement LatexLenghtError;

	@FindBy(xpath = "//h6[text()='Width customization is allowed between 30 - 72 inch']")
	private WebElement WidthError;

	// Webelement for error messages for lenght and width field for Original,plus
	// and Latex mattress
	public WebElement lenghtError() {
		return LengthError;
	}

	public WebElement latexLenghtError() {
		return LatexLenghtError;
	}

	public WebElement widthError() {
		return WidthError;
	}

	// Xpath for custom lenght and width option when category is custom
	@FindBy(xpath = "//input[@name='custom_length']")
	private WebElement CustomLength;

	@FindBy(xpath = "//input[@name='custom_breath']")
	private WebElement CustomWidth;

	// Webelement option for Dropdown option when category is Queen on Plus mattress
	// and height is 10 inch
	public WebElement customLength() {
		return CustomLength;
	}

	public WebElement customWidth() {
		return CustomWidth;
	}

	// Xpath for Personalize Name Section,Stitch it button and name field on product
	// details page
	@FindBy(xpath = "//button[@id='personalize-toggle-btn']")
	private WebElement PersonalizeNameSection;

	@FindBy(xpath = "//input[@id='personalize-initials']")
	private WebElement PersonalizeNameField;

	@FindBy(xpath = "//button[@id='stitch-it-btn']")
	private WebElement StitchButton;

	@FindBy(xpath = "//button[@id='edit-btn']")
	private WebElement EditButton;

	@FindBy(xpath = "//button[@id='cancel-btn']")
	private WebElement RemoveButton;

	// Webelement for Personalize Name Section,Stitch it button and name field on
	// product details page
	public WebElement personalizeNameSection() {
		return PersonalizeNameSection;
	}

	public WebElement personalizeNameField() {
		return PersonalizeNameField;
	}

	public WebElement stitchButton() {
		return StitchButton;
	}

	public WebElement editButton() {
		return EditButton;
	}

	public WebElement removeButton() {
		return RemoveButton;
	}

	// Xpath for Frequently bought with the above product text
	@FindBy(xpath = "//span[text()='Frequently bought with the above product']")
	private WebElement FrequentlyText;

	// Webelement for for Frequently bought with the above product text
	public WebElement frequentlyText() {
		return FrequentlyText;
	}

	// Xpath for cross sell section text
	@FindBy(xpath = "//span[text()='10 years warranty']")
	private WebElement CrossSellSection;

	// Webelement for for Frequently bought with the above product text
	public WebElement crossSellSection() {
		return CrossSellSection;
	}

	// Xpath for cross sell section text
	@FindBy(xpath = "//span[text()='Free shipping']")
	private WebElement CrossSellFreeShippingText;

	// Webelement for for Frequently bought with the above product text
	public WebElement CrossSellFreeShippingText() {
		return CrossSellFreeShippingText;
	}

	// Xpath for How to measure the right fit for your bed text
	@FindBy(xpath = "//span[text()='How to measure the right fit for your bed?']")
	private WebElement MeasureBedText;

	// Webelement for How to measure the right fit for your bed text
	public WebElement measureBedText() {
		return MeasureBedText;
	}

	// Cross selling section product Add to cart button xpath section on product
	// details page
	@FindBy(xpath = "(//span[@data-sku='SC-COMF-S-90x60'])")
	private WebElement CrossSellAddToCartButtonForSingleWhiteColorComforter;

	@FindBy(xpath = "(//span[@data-sku='SC-CFCOMF-S-90x60'])")
	private WebElement CrossSellAddToCartButtonForSingleCoffeeColorComforter;

	@FindBy(xpath = "(//span[@data-sku='SC-LMCOMF-S-90x60'])")
	private WebElement CrossSellAddToCartButtonForSingleLimeColorComforter;

	@FindBy(xpath = "//span[@data-sku='SC-GRBDPILWSET-S-50x19']")
	private WebElement CrossSellAddToCartButtonForCuddlePillow;

	@FindBy(xpath = "(//span[@data-sku='SC-CLPILW-S-27x18'])")
	private WebElement CrossSellAddToCartButtonForCloudPillow;

	// Webelement option for Cross selling section Add to cart product button
	public WebElement crossSellAddToCartButtonForSingleWhiteColorComforter() {
		return CrossSellAddToCartButtonForSingleWhiteColorComforter;
	}

	public WebElement crossSellAddToCartButtonForSingleCoffeeColorComforter() {
		return CrossSellAddToCartButtonForSingleCoffeeColorComforter;
	}

	public WebElement crossSellAddToCartButtonForSingleLimeColorComforter() {
		return CrossSellAddToCartButtonForSingleLimeColorComforter;
	}

	public WebElement crossSellAddToCartButtonForCuddlePillow() {
		return CrossSellAddToCartButtonForCuddlePillow;
	}

	public WebElement crossSellAddToCartButtonForCloudPillow() {
		return CrossSellAddToCartButtonForCloudPillow;
	}

	// Cross selling next and previous product icon xpath section on product details
	// page
	@FindBy(xpath = "//div[@class='product_cross_sell_wrap cross-selling-section']//a[@class='lSNext']")
	private WebElement CrossSellNextproduct;

	@FindBy(xpath = "//div[@class='product_cross_sell_wrap cross-selling-section']//a[@class='lSPrev']")
	private WebElement CrossSellPreviousProduct;

	// Webelement option for Cross selling next and previous product icon on product
	// details page
	public WebElement crossSellNextproduct() {
		return CrossSellNextproduct;
	}

	public WebElement crossSellPreviousProduct() {
		return CrossSellPreviousProduct;
	}

	// Cross selling section product Add to cart button xpath section on product
	// details page of Original mattress page
	@FindBy(xpath = "//span[@data-sku='SC-CLPILW-P-32x20']")
	private WebElement CrossSellAddtocartPresidentCloudPillowSet1;

	@FindBy(xpath = "//span[@data-sku='SC-CLPILWSET2-P-32x20']")
	private WebElement CrossSellAddtocartPresidentCloudPillowSet2;

	@FindBy(xpath = "//span[@data-sku='SC-CLPILWSET4-P-32x20']")
	private WebElement CrossSellAddtocartPresidentCloudPillowSet4;

	@FindBy(xpath = "//span[@data-sku='SC-PROT-S-75x36']")
	private WebElement CrossSellAddtocartSingleProtector75x36;

	@FindBy(xpath = "//span[@data-sku='SC-PROT-S-72x36']")
	private WebElement CrossSellAddtocartSingleGreyProtector72x36;

	@FindBy(xpath = "//span[@data-sku='SC-PROT-WT-S-72x36']")
	private WebElement CrossSellAddtocartSingleWhiteProtector72x36;

	// Webelement option for cross selling product on Original mattress page
	public WebElement crossSellAddtocartSingleWhiteProtector72x36() {
		return CrossSellAddtocartSingleWhiteProtector72x36;
	}

	public WebElement crossSellAddtocartPresidentCloudPillowSet1() {
		return CrossSellAddtocartPresidentCloudPillowSet1;
	}

	public WebElement crossSellAddtocartPresidentCloudPillowSet2() {
		return CrossSellAddtocartPresidentCloudPillowSet2;
	}

	public WebElement crossSellAddtocartPresidentCloudPillowSet4() {
		return CrossSellAddtocartPresidentCloudPillowSet4;
	}

	public WebElement crossSellAddtocartSingleProtector75x36() {
		return CrossSellAddtocartSingleProtector75x36;
	}

	public WebElement crossSellAddtocartSingleGreyProtector72x36() {
		return CrossSellAddtocartSingleGreyProtector72x36;
	}

	// Xpath for Different color options of Protector in cross selling product
	// section
	@FindBy(xpath = "(//span[@class='color-ball comforter pwhite'])")
	private WebElement CrossSellWhiteColorProtector;

	@FindBy(xpath = "(//span[@class='color-ball comforter pgrey'])")
	private WebElement CrossSellGreyColorProtector;

	// Webelement for Different color options of Protector in cross selling product
	// section
	public WebElement crossSellWhiteColorProtector() {
		return CrossSellWhiteColorProtector;
	}

	public WebElement crossSellGreyColorProtector() {
		return CrossSellGreyColorProtector;
	}

	// Cross selling cloud pillow section
	// Xpath for category field of cloud pillow cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//div[@data-name='scategory'])")
	private WebElement CrossSellCloudPillowCategoryField;

	// Webelement for category field of cloud pillow cross selling product section
	public WebElement crossSellCloudPillowCategoryField() {
		return CrossSellCloudPillowCategoryField;
	}

	// Xpath for President category of cloud pillow cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//li[@data-value='President'])")
	private WebElement CrossSellPresidentCategoryCloudPillow;

	// Webelement option for President category of cloud pillow cross selling
	// product section
	public WebElement crossSellPresidentCategoryCloudPillow() {
		return CrossSellPresidentCategoryCloudPillow;
	}

	// Xpath for pack field of cloud pillow in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//div[@data-name='pack'])")
	private WebElement CrossSellPackFieldOfCloudPillow;

	// Webelement option for pack field of cloud pillow in cross selling product
	// section
	public WebElement crossSellPackFieldOfCloudPillow() {
		return CrossSellPackFieldOfCloudPillow;
	}

	// Xpath for pack field of cloud pillow in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//li[@data-value='pillow-2'])")
	private WebElement CrossSellPackTwoOfCloudPillow;

	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//li[@data-value='pillow-4'])")
	private WebElement CrossSellPackFourOfCloudPillow;

	// Webelement option for pack field of cloud pillow in cross selling product
	// section
	public WebElement crossSellPackFourOfCloudPillow() {
		return CrossSellPackFourOfCloudPillow;
	}

	public WebElement CrossSellPackTwoOfCloudPillow() {
		return CrossSellPackTwoOfCloudPillow;
	}

	// Xpath for increment and decrement product quantity icon of cloud pillow in
	// cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//input[@class='plus'])")
	private WebElement CrossSellCloudPillowIncrementQuantity;

	@FindBy(xpath = "(//div[@data-producttype='cloud_pillow']//input[@class='minus'])")
	private WebElement CrossSellCloudPillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of cloud
	// pillow in cross selling product section
	public WebElement crossSellCloudPillowIncrementQuantity() {
		return CrossSellCloudPillowIncrementQuantity;
	}

	public WebElement crossSellCloudPillowDecreaseQuantity() {
		return CrossSellCloudPillowDecreaseQuantity;
	}

	// Cross selling section for Comforter
	// Xpath for category Type field of comforter cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='comforter']//div[@data-name='scategory'])")
	private WebElement CrossSellComforterCategoryField;

	// Webelement option for category Type field of comforter cross selling product
	// section
	public WebElement crossSellComforterCategoryField() {
		return CrossSellComforterCategoryField;
	}

	// Xpath for Double category of comforter cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='comforter']//span[text()='Double'])")
	private WebElement CrossSellDoubleCategoryComforter;

	// Webelement option for Double category of comforter cross selling product
	// section
	public WebElement crossSellDoubleCategoryComforter() {
		return CrossSellDoubleCategoryComforter;
	}

	// Xpath for Color options of Comforter on cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='comforter']//li[@data-value='coffee'])")
	private WebElement CrossSellComforterCoffeeColor;

	@FindBy(xpath = "(//div[@data-producttype='comforter']//li[@data-value='pink'])")
	private WebElement CrossSellComforterPinkColor;

	// Webelement for Color options of Comforter on cross selling product section
	public WebElement crossSellComforterCoffeeColor() {
		return CrossSellComforterCoffeeColor;
	}

	public WebElement crossSellComforterPinkColor() {
		return CrossSellComforterPinkColor;
	}

	// Xpath for Add to cart of Double category pink color comforter cross selling
	// product
	@FindBy(xpath = "//span[@data-sku='SC-PKCOMF-D-90x100']")
	private WebElement CrossSellAddToCartButtonForDoubleCategoryPinkComforter;

	// Webelement option for Add to cart of Double category pink color comforter
	// cross selling product
	public WebElement crossSellAddToCartButtonForDoubleCategoryPinkComforter() {
		return CrossSellAddToCartButtonForDoubleCategoryPinkComforter;
	}

	// Xpath for Add to cart of Double category Coffee color comforter cross selling
	// product
	@FindBy(xpath = "//span[@data-sku='SC-CFCOMF-D-90x100']")
	private WebElement CrossSellAddToCartButtonForDoubleCategoryCoffeeComforter;

	// Webelement option for Add to cart of Double category Coffee color comforter
	// cross selling product
	public WebElement crossSellAddToCartButtonForDoubleCategoryCoffeeComforter() {
		return CrossSellAddToCartButtonForDoubleCategoryCoffeeComforter;
	}

	// Cross selling section for Protector
	// Xpath for category Type field of comforter cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='protector']//div[@data-name='scategory'])")
	private WebElement CrossSellProtectorCategoryField;

	// Webelement option for category Type field of comforter cross selling product
	// section
	public WebElement crossSellProtectorCategoryField() {
		return CrossSellProtectorCategoryField;
	}

	// Xpath for different category field of comforter cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-value='Single'])")
	private WebElement CrossSellSingleCategoryProtector;

	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-value='Double'])")
	private WebElement CrossSellDoubleCategoryProtector;

	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-value='King'])")
	private WebElement CrossSellKingCategoryProtector;

	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-value='Queen'])")
	private WebElement CrossSellQueenCategoryProtector;

	// Webelement option for Double category of comforter cross selling product
	// section
	public WebElement crossSellSingleCategoryProtector() {
		return CrossSellSingleCategoryProtector;
	}

	public WebElement crossSellDoubleCategoryProtector() {
		return CrossSellDoubleCategoryProtector;
	}

	public WebElement crossSellKingCategoryProtector() {
		return CrossSellKingCategoryProtector;
	}

	public WebElement crossSellQueenCategoryProtector() {
		return CrossSellQueenCategoryProtector;
	}

	// Xpath for Size field of Protector cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='protector']//div[@data-name='variation'])")
	private WebElement CrossSellProtectorSizeField;

	// Webelement option for category Type field of comforter cross selling product
	// section
	public WebElement crossSellProtectorSizeField() {
		return CrossSellProtectorSizeField;
	}

	// Xpath for Different Size dropdown field of Protector in cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-sku='SC-PROT-D-75x48'])")
	private WebElement CrossSellGreyColorDoubleProtector75x48;

	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-sku='SC-PROT-D-78x48'])")
	private WebElement CrossSellGreyColorDoubleProtector78x48;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement crossSellGreyColorDoubleProtector75x48() {
		return CrossSellGreyColorDoubleProtector75x48;
	}

	public WebElement crossSellGreyColorDoubleProtector78x48() {
		return CrossSellGreyColorDoubleProtector78x48;
	}

	// Xpath for Different Size dropdown field of Protector in cross selling product
	// section
	@FindBy(xpath = "//span[@data-sku='SC-PROT-D-75x48']")
	private WebElement CrossSellAddToCartDoubleProtector75x48;

	@FindBy(xpath = "//span[@data-sku='SC-PROT-D-78x48']")
	private WebElement CrossSellAddToCartDoubleProtector78x48;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement crossSellAddToCartDoubleProtector75x48() {
		return CrossSellAddToCartDoubleProtector75x48;
	}

	public WebElement crossSellAddToCartDoubleProtector78x48() {
		return CrossSellAddToCartDoubleProtector78x48;
	}

	// Xpath for Different Size dropdown field of Protector in cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='protector']//li[@data-sku='SC-PROT-Q-78x60'])")
	private WebElement CrossSellQueenProtector78x60;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement crossSellQueenProtector78x60() {
		return CrossSellQueenProtector78x60;
	}

	// Xpath for Add to cart button when Protector in cross selling product section
	@FindBy(xpath = "//span[@data-sku='SC-PROT-Q-78x60']")
	private WebElement CrossSellAddToCartQueenProtector78x60;

	// Webelement for Add to cart button when Protector Protector in cross selling
	// product section
	public WebElement crossSellAddToCartQueenProtector78x60() {
		return CrossSellAddToCartQueenProtector78x60;
	}

	// Xpath for Defaut Add to cart button when Single Protector in cross selling
	// product section
	@FindBy(xpath = "//span[@data-sku='SC-PROT-S-78x36']")
	private WebElement CrossSellAddToCartSingleProtector78x36;

	// Webelement for Add to cart button when Protector Protector in cross selling
	// product section
	public WebElement crossSellAddToCartSingleProtector78x36() {
		return CrossSellAddToCartSingleProtector78x36;
	}

	// Ultima mattress product in cross selling product section
	// Xpath for category field for Ultima mattress
	@FindBy(xpath = "//div[@data-producttype='ultima']//div[@data-name='scategory']")
	private WebElement CrossSellUltimaMattressCategoryField;

	// Webelement for category field for Ultima mattress
	public WebElement crossSellUltimaMattressCategoryField() {
		return CrossSellUltimaMattressCategoryField;
	}

	// Xpath for category options for Ultima mattress
	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-value='Single']")
	private WebElement CrossSellUltimaMattressSingleCategory;

	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-value='Double']")
	private WebElement CrossSellUltimaMattressDoubleCategory;

	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-value='Queen']")
	private WebElement CrossSellUltimaMattressQueenCategory;

	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-value='King']")
	private WebElement CrossSellUltimaMattressKingCategory;

	// Webelement for category options for Ultima mattress
	public WebElement crossSellUltimaMattressSingleCategory() {
		return CrossSellUltimaMattressSingleCategory;
	}

	public WebElement crossSellUltimaMattressDoubleCategory() {
		return CrossSellUltimaMattressDoubleCategory;
	}

	public WebElement crossSellUltimaMattressQueenCategory() {
		return CrossSellUltimaMattressQueenCategory;
	}

	public WebElement crossSellUltimaMattressKingCategory() {
		return CrossSellUltimaMattressKingCategory;
	}

	// Xpath for Height field for Ultima mattress
	@FindBy(xpath = "//div[@data-producttype='ultima']//div[@data-name='height']")
	private WebElement CrossSellUltimaMattressHeightField;

	// Webelement for Height field for Ultima mattress
	public WebElement crossSellUltimaMattressHeightField() {
		return CrossSellUltimaMattressHeightField;
	}

	// Xpath for Height field for Ultima mattress
	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-value='10 inch']")
	private WebElement CrossSellUltimaMattressTenInchHeight;

	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-value='8 inch']")
	private WebElement CrossSellUltimaMattressEightInchHeight;

	// Webelement for Height field for Ultima mattress
	public WebElement crossSellUltimaMattressTenInchHeight() {
		return CrossSellUltimaMattressTenInchHeight;
	}

	public WebElement crossSellUltimaMattressEightInchHeight() {
		return CrossSellUltimaMattressEightInchHeight;
	}

	// Xpath for Size field for Ultima mattress
	@FindBy(xpath = "//div[@data-producttype='ultima']//div[@data-name='variation']")
	private WebElement CrossSellUltimaMattressSizeField;

	// Webelement for Size field for Ultima mattress
	public WebElement crossSellUltimaMattressSizeField() {
		return CrossSellUltimaMattressSizeField;
	}

	// Xpath for different size options for Ultima mattress when king category is
	// selected
	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-sku='SC-ULTM-K-75x72x10']")
	private WebElement CrossSellUltimaMattressKing75x72x10;

	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-sku='SC-ULTM-K-75x72x8']")
	private WebElement CrossSellUltimaMattressKing75x72x8;

	@FindBy(xpath = "//div[@data-producttype='ultima']//li[@data-sku='SC-ULTM-K-78x72x8']")
	private WebElement CrossSellUltimaMattressKing78x72x8;

	// Webelement for for different size options for Ultima mattress when king
	// category
	public WebElement crossSellUltimaMattressKing75x72x10() {
		return CrossSellUltimaMattressKing75x72x10;
	}

	public WebElement crossSellUltimaMattressKing75x72x8() {
		return CrossSellUltimaMattressKing75x72x8;
	}

	public WebElement crossSellUltimaMattressKing78x72x8() {
		return CrossSellUltimaMattressKing78x72x8;
	}

	// Xpath for Add to cart button for Ultima mattress when king category is
	// selected and height is 10 inch and size is 75x72x10
	@FindBy(xpath = "//span[@data-sku='SC-ULTM-K-75x72x10']")
	private WebElement CrossSellAddToCartUltimaMattressKing75x72x10;

	@FindBy(xpath = "//span[@data-sku='SC-ULTM-K-78x72x8']")
	private WebElement CrossSellAddToCartUltimaMattressKing78x72x8;

	@FindBy(xpath = "//span[@data-sku='SC-ULTM-K-78x72x10']")
	private WebElement CrossSellAddToCartUltimaMattressKing78x72x10;

	// Webelement for Add to cart button for Ultima mattress when king category is
	// selected and height is 10 inch and size is 75x72x10
	public WebElement crossSellAddToCartUltimaMattressKing75x72x10() {
		return CrossSellAddToCartUltimaMattressKing75x72x10;
	}

	public WebElement crossSellAddToCartUltimaMattressKing78x72x8() {
		return CrossSellAddToCartUltimaMattressKing78x72x8;
	}

	public WebElement crossSellAddToCartUltimaMattressKing78x72x10() {
		return CrossSellAddToCartUltimaMattressKing78x72x10;
	}

	// Original mattress product in cross selling product section
	// Xpath for category field for Original mattress
	@FindBy(xpath = "//div[@data-producttype='original']//div[@data-name='scategory']")
	private WebElement CrossSellOriginalMattressCategoryField;

	// Webelement for category field for Original mattress
	public WebElement crossSellOriginalMattressCategoryField() {
		return CrossSellOriginalMattressCategoryField;
	}

	// Xpath for category options for Original mattress
	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='Single']")
	private WebElement CrossSellOriginalMattressSingleCategory;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='Double']")
	private WebElement CrossSellOriginalMattressDoubleCategory;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='Queen']")
	private WebElement CrossSellOriginalMattressQueenCategory;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='King']")
	private WebElement CrossSellOriginalMattressKingCategory;

	// Webelement for category options for Original mattress
	public WebElement crossSellOriginalMattressSingleCategory() {
		return CrossSellOriginalMattressSingleCategory;
	}

	public WebElement crossSellOriginalMattressDoubleCategory() {
		return CrossSellOriginalMattressDoubleCategory;
	}

	public WebElement crossSellOriginalMattressQueenCategory() {
		return CrossSellOriginalMattressQueenCategory;
	}

	public WebElement crossSellOriginalMattressKingCategory() {
		return CrossSellOriginalMattressKingCategory;
	}

	// Xpath for Size field for Original mattress
	@FindBy(xpath = "//div[@data-producttype='original']//div[@data-name='variation']")
	private WebElement CrossSellOriginalMattressSizeField;

	// Webelement for Size field for Original mattress
	public WebElement crossSellOriginalMattressSizeField() {
		return CrossSellOriginalMattressSizeField;
	}

	// Xpath for different size options for Original mattress when king category is
	// selected
	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-sku='SC-ORIG-K-75x72x6']")
	private WebElement CrossSellOriginalMattressKing75x72x6;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-sku='SC-ORIG-K-78x72x6']")
	private WebElement CrossSellOriginalMattressKing78x72x6;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-sku='SC-ORIG-K-75x72x10']")
	private WebElement CrossSellOriginalMattressKing75x72x10;

	// Webelement for for different size options for Original mattress when king
	// category is selected
	public WebElement crossSellOriginalMattressKing75x72x6() {
		return CrossSellOriginalMattressKing75x72x6;
	}

	public WebElement crossSellOriginalMattressKing78x72x6() {
		return CrossSellOriginalMattressKing78x72x6;
	}

	public WebElement crossSellOriginalMattressKing75x72x10() {
		return CrossSellOriginalMattressKing75x72x10;
	}

	// Xpath for Add to cart button for Original mattress when king category is
	// selected and size is 75x72x6
	@FindBy(xpath = "//span[@data-sku='SC-ORIG-K-75x72x6']")
	private WebElement CrossSellAddToCartOriginalMattressKing75x72x6;

	@FindBy(xpath = "//span[@data-sku='SC-ORIG-K-75x72x10']")
	private WebElement CrossSellAddToCartOriginalMattressKing75x72x10;

	@FindBy(xpath = "//span[@data-sku='SC-ORIG-K-78x72x6']")
	private WebElement CrossSellAddToCartOriginalMattressKing78x72x6;

	@FindBy(xpath = "//span[@data-sku='SC-ORIG-K-78x72x10']")
	private WebElement CrossSellAddToCartOriginalMattressKing78x72x10;

	// Webelement for Add to cart button for plus mattress when king category is
	// selected and size is 75x72x6
	public WebElement crossSellAddToCartOriginalMattressKing75x72x6() {
		return CrossSellAddToCartOriginalMattressKing75x72x6;
	}

	public WebElement crossSellAddToCartOriginalMattressKing75x72x10() {
		return CrossSellAddToCartOriginalMattressKing75x72x10;
	}

	public WebElement crossSellAddToCartOriginalMattressKing78x72x6() {
		return CrossSellAddToCartOriginalMattressKing78x72x6;
	}

	public WebElement crossSellAddToCartOriginalMattressKing78x72x10() {
		return CrossSellAddToCartOriginalMattressKing78x72x10;
	}

	// Xpath for Default add to cart button for Original mattress
	@FindBy(xpath = "//span[@data-sku='SC-ORIG-S-72x30x6']")
	private WebElement CrossSellAddToCartOriginalMattressSingle72x30x6;

	// Webelement for Default add to cart button for Original mattress
	public WebElement crossSellAddToCartOriginalMattressSingle72x30x6() {
		return CrossSellAddToCartOriginalMattressSingle72x30x6;
	}

	// Xpath for Height field for Original mattress
	@FindBy(xpath = "//div[@data-producttype='original']//div[@data-name='height']")
	private WebElement CrossSellOriginalMattressHeightField;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='10 inch']")
	private WebElement CrossSellOriginalMattressTenInchHeightOption;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='8 inch']")
	private WebElement CrossSellOriginalMattressEightInchHeightOption;

	@FindBy(xpath = "//div[@data-producttype='original']//li[@data-value='6 inch']")
	private WebElement CrossSellOriginalMattressSixInchHeightOption;

	// Webelement for Height field for Original mattress
	public WebElement crossSellOriginalMattressHeightField() {
		return CrossSellOriginalMattressHeightField;
	}

	public WebElement crossSellOriginalMattressTenInchHeightOption() {
		return CrossSellOriginalMattressTenInchHeightOption;
	}

	public WebElement crossSellOriginalMattressSixInchHeightOption() {
		return CrossSellOriginalMattressSixInchHeightOption;
	}

	public WebElement crossSellOriginalMattressEightInchHeightOption() {
		return CrossSellOriginalMattressEightInchHeightOption;
	}

	// Hybrid Latex mattress product in cross selling product section
	// Xpath for category field for Hybrid Latex mattress
	@FindBy(xpath = "//div[@data-producttype='latex']//div[@data-name='scategory']")
	private WebElement CrossSellLatexMattressCategoryField;

	// Webelement for category field for Hybrid Latex mattress
	public WebElement crossSellLatexMattressCategoryField() {
		return CrossSellLatexMattressCategoryField;
	}

	// Xpath for category options for Hybrid Latex mattress
	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-value='Single']")
	private WebElement CrossSellLatexMattressSingleCategory;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-value='Double']")
	private WebElement CrossSellLatexMattressDoubleCategory;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-value='Queen']")
	private WebElement CrossSellLatexMattressQueenCategory;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-value='King']")
	private WebElement CrossSellLatexMattressKingCategory;

	// Webelement for category options for Hybrid Latex mattress
	public WebElement crossSellLatexMattressSingleCategory() {
		return CrossSellLatexMattressSingleCategory;
	}

	public WebElement crossSellLatexMattressDoubleCategory() {
		return CrossSellLatexMattressDoubleCategory;
	}

	public WebElement crossSellLatexMattressQueenCategory() {
		return CrossSellLatexMattressQueenCategory;
	}

	public WebElement crossSellLatexMattressKingCategory() {
		return CrossSellLatexMattressKingCategory;
	}

	// Xpath for Size field for Hybrid Latex mattress
	@FindBy(xpath = "//div[@data-producttype='latex']//div[@data-name='variation']")
	private WebElement CrossSellLatexMattressSizeField;

	// Webelement for Size field for Hybrid Latex mattress
	public WebElement crossSellLatexMattressSizeField() {
		return CrossSellLatexMattressSizeField;
	}

	// Xpath for different size options for Hybrid Latex mattress when king category
	// is selected
	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-sku='SC-HYB-LATEX-Q-75x60x8']")
	private WebElement CrossSellLatexMattressQueen75x60x8;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-sku='SC-HYB-LATEX-Q-78x60x8']")
	private WebElement CrossSellLatexMattressQueen78x60x8;

	// Webelement for for different size options for Hybrid Latex mattress when king
	// category is selected
	public WebElement crossSellLatexMattressQueen75x60x8() {
		return CrossSellLatexMattressQueen75x60x8;
	}

	public WebElement crossSellLatexMattressQueen78x60x8() {
		return CrossSellLatexMattressQueen78x60x8;
	}

	// Xpath for Height field for Hybrid Latex mattress
	@FindBy(xpath = "//div[@data-producttype='latex']//div[@data-name='height']")
	private WebElement CrossSellLatexMattressHeightField;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-value='8 inch']")
	private WebElement CrossSellLatexMattressEightInchHeightOption;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-value='6 inch']")
	private WebElement CrossSellLatexMattressSixInchHeightOption;

	// Webelement for Height field for Hybrid Latex mattress
	public WebElement crossSellLatexMattressHeightField() {
		return CrossSellLatexMattressHeightField;
	}

	public WebElement crossSellLatexMattressEightInchHeightOption() {
		return CrossSellLatexMattressEightInchHeightOption;
	}

	public WebElement crossSellLatexMattressSixInchHeightOption() {
		return CrossSellLatexMattressSixInchHeightOption;
	}

	// Xpath for Add to cart button for Ohayo Tray
	@FindBy(xpath = "//span[@data-sku='SC-OHAYOTRAY-10X9X2']")
	private WebElement CrossSellAddToCartOhayoTray;

	// Webelement for Add to cart button for Ohayo Tray
	public WebElement crossSellAddToCartOhayoTray() {
		return CrossSellAddToCartOhayoTray;
	}

	// SoftTouch Memory foam pillow product in cross selling product section
	// Xpath for category field for SoftTouch Memory foam pillow
	@FindBy(xpath = "(//div[@data-producttype='pillow']//div[@data-name='scategory'])")
	private WebElement CrossSellSoftTouchMemoryPillowCategoryField;

	// Webelement for category field for SoftTouch Memory foam pillow
	public WebElement crossSellSoftTouchMemoryPillowCategoryField() {
		return CrossSellSoftTouchMemoryPillowCategoryField;
	}

	// Xpath for category options for Memory foam pillow
	@FindBy(xpath = "(//div[@data-producttype='pillow']//li[@data-value='Standard'])")
	private WebElement CrossSellSoftTouchMemoryPillowStandardCategory;

	@FindBy(xpath = "(//div[@data-producttype='pillow']//li[@data-value='President'])")
	private WebElement CrossSellSoftTouchMemoryPillowPresidentCategory;

	// Webelement for category options for Memory foam pillow
	public WebElement crossSellSoftTouchMemoryPillowStandardCategory() {
		return CrossSellSoftTouchMemoryPillowStandardCategory;
	}

	public WebElement crossSellSoftTouchMemoryPillowPresidentCategory() {
		return CrossSellSoftTouchMemoryPillowPresidentCategory;
	}

	// Xpath for Pack field for SoftTouchMemory foam pillow
	// @FindBy(xpath = "//div[@class='container_cross_sell pillow
	// ']//div[@data-name='pack']")
	@FindBy(xpath = "(//div[@data-producttype='pillow']//div[@data-name='pack'])")
	private WebElement CrossSellSoftTouchMemoryPillowPackField;

	// Webelement for Pack field for Memory foam pillow
	public WebElement crossSellSoftTouchMemoryPillowPackField() {
		return CrossSellSoftTouchMemoryPillowPackField;
	}

	// Xpath for different Pack options for SoftTouch Memory pillow when President
	// category is selected
	// @FindBy(xpath = "//div[@class='container_cross_sell pillow
	// ']//li[@value='pillow-2']")
	@FindBy(xpath = "(//div[@data-producttype='pillow']//li[@value='pillow-2'])")
	private WebElement CrossSellSoftTouchMemoryPillowPackOfTwo;

	// @FindBy(xpath = "//div[@class='container_cross_sell pillow
	// ']//li[@value='pillow-4']")
	@FindBy(xpath = "(//div[@data-producttype='pillow']//li[@value='pillow-4'])")
	private WebElement CrossSellSoftTouchMemoryPillowPackOfFour;

	// Webelement for different Pack options for Memory pillow when President
	// category is selected
	public WebElement crossSellSoftTouchMemoryPillowPackOfTwo() {
		return CrossSellSoftTouchMemoryPillowPackOfTwo;
	}

	public WebElement crossSellSoftTouchMemoryPillowPackOfFour() {
		return CrossSellSoftTouchMemoryPillowPackOfFour;
	}

	// Xpath for Add to cart button for SoftTouch Memory foam when President
	// category is selected and Pack is two
	@FindBy(xpath = "//span[@data-sku='SC-MFPILWSET2-BAM-P-28x18']")
	private WebElement CrossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo;

	// Webelement for Add to cart button for Memory foam when President category is
	// selected and Pack is two
	public WebElement crossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo() {
		return CrossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo;
	}

	// Xpath for Add to cart button for SoftTouch Memory foam when Standard category
	// is selected and Pack is four
	@FindBy(xpath = "//span[@data-sku='SC-MFPILWSET4-BAM-S-25x16']")
	private WebElement CrossSellAddToCartStandardSoftTouchMemoryPillowPackFour;

	@FindBy(xpath = "(//span[@data-sku='SC-MFPILW-BAM-S-25x16'])")
	private WebElement CrossSellAddToCartStandardSoftTouchMemoryPillowPackOne;

	// Webelement for Add to cart button for Memory foam when Standard category is
	// selected and Pack is four
	public WebElement crossSellAddToCartStandardSoftTouchMemoryPillowPackFour() {
		return CrossSellAddToCartStandardSoftTouchMemoryPillowPackFour;
	}

	public WebElement crossSellAddToCartStandardSoftTouchMemoryPillowPackOne() {
		return CrossSellAddToCartStandardSoftTouchMemoryPillowPackOne;
	}

	// Xpath for increment and decrement product quantity icon of SoftTouch Memory
	// pillow in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='pillow']//input[@class='plus'])")
	private WebElement CrossSellSoftTouchMemoryPillowIncrementQuantity;

	@FindBy(xpath = "(//div[@data-producttype='pillow']//input[@class='minus'])")
	private WebElement CrossSellSoftTouchMemoryPillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Hybrid
	// pillow in cross selling product section
	public WebElement crossSellSoftTouchMemoryPillowIncrementQuantity() {
		return CrossSellSoftTouchMemoryPillowIncrementQuantity;
	}

	public WebElement crossSellSoftTouchMemoryPillowDecreaseQuantity() {
		return CrossSellSoftTouchMemoryPillowDecreaseQuantity;
	}

	// Pillow Case product in cross selling product section
	// Xpath for Type field for pillow case product
	@FindBy(xpath = "(//div[@data-producttype='pillow_case']//div[@class='customselectedData'])")
	private WebElement CrossSellPillowCaseTypeField;

	// Webelement for Type field for pillow case product
	public WebElement crossSellPillowCaseTypeField() {
		return CrossSellPillowCaseTypeField;
	}

	// Xpath for Different Type options for pillow cases
	@FindBy(xpath = "//div[@data-producttype='pillow_case']//li[@data-value='Standard']")
	private WebElement CrossSellStandardPillowCases;

	@FindBy(xpath = "//div[@data-producttype='pillow_case']//li[@data-value='President']")
	private WebElement CrossSellPresidentPillowCases;

	@FindBy(xpath = "//div[@data-producttype='pillow_case']//li[@data-value='Cuddle']")
	private WebElement CrossSellCuddleTypePillowCases;

	// Webelement for Different Type options for pillow cases
	public WebElement crossSellStandardPillowCases() {
		return CrossSellStandardPillowCases;
	}

	public WebElement crossSellPresidentPillowCases() {
		return CrossSellPresidentPillowCases;
	}

	public WebElement crossSellCuddleTypePillowCases() {
		return CrossSellCuddleTypePillowCases;
	}

	// Xpath for Pack field for Pillow cases
	@FindBy(xpath = "(//div[@class='container_cross_sell pillow_case ']//div[@data-producttype='pillow_case'])")
	private WebElement CrossSellPillowCasesPackField;

	// Webelement for Pack field for Pillow cases
	public WebElement crossSellPillowCasesPackField() {
		return CrossSellPillowCasesPackField;
	}

	// Xpath for different Pack options for pillow cases
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//li[text()='Pack of 4']")
	private WebElement CrossSellPillowCasePackOfFour;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//li[text()='Pack of 8']")
	private WebElement CrossSellPillowCasePackOfEight;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//li[text()='Pack of 1']")
	private WebElement CrossSellPillowCasePackOfOne;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//li[text()='Pack of 2']")
	private WebElement CrossSellPillowCasePackOfTwo;

	// Webelement for different Pack options for Memory pillow when President
	// category is selected
	public WebElement crossSellPillowCasePackOfFour() {
		return CrossSellPillowCasePackOfFour;
	}

	public WebElement crossSellPillowCasePackOfEight() {
		return CrossSellPillowCasePackOfEight;
	}

	public WebElement crossSellPillowCasePackOfOne() {
		return CrossSellPillowCasePackOfOne;
	}

	public WebElement crossSellPillowCasePackOfTwo() {
		return CrossSellPillowCasePackOfTwo;
	}

	// Xpath for size field for Pillow case cross selling product
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//div[@class='customDropdown variations pillow_case']")
	private WebElement CrossSellPillowCaseSizeField;

	// Webelement for size field for Pillow case cross selling product
	public WebElement crossSellPillowCaseSizeField() {
		return CrossSellPillowCaseSizeField;
	}

	// Xpath for different size dropdown for pillow cases when Type is memmory foam
	// and Pack is four
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//li[@data-sku='SC-GRPILWCSSET2-S-28x18']")
	private WebElement CrossSellMemoryPillowTypePillowcasePackFour28x18;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case ']//li[@data-sku='SC-GRPILWCSSET2-P-33x21']")
	private WebElement CrossSellMemoryPillowTypePillowcasePackFour33x21;

	// Webelement for different size dropdown for pillow cases when Type is memmory
	// foam and Pack is four
	public WebElement crossSellMemoryPillowTypePillowcasePackFour28x18() {
		return CrossSellMemoryPillowTypePillowcasePackFour28x18;
	}

	public WebElement crossSellMemoryPillowTypePillowcasePackFour33x21() {
		return CrossSellMemoryPillowTypePillowcasePackFour33x21;
	}

	// Xpath for Add to cart button for pillow case when type is memory Foam and and
	// Pack is four
	@FindBy(xpath = "//span[@data-sku='SC-GRPILWCSSET2-S-28x18']")
	private WebElement CrossSellAddToCartButtonForStandardPillowcasePackOfFour;

	// Webelement for size field for Pillow case cross selling product
	public WebElement crossSellAddToCartButtonForStandardPillowcasePackOfFour() {
		return CrossSellAddToCartButtonForStandardPillowcasePackOfFour;
	}

	// Xpath for Add to cart button for Cuddle pillow case
	@FindBy(xpath = "//span[@data-sku='SC-DGRPILWCS-C-52x20']")
	private WebElement CrossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo;

	@FindBy(xpath = "//span[@data-sku='SC-TBLPILWCS-C-52x20']")
	private WebElement CrossSellAddToCartButtonForTwilightBlueCuddlePillowcasePackOfTwo;

	@FindBy(xpath = "//span[@data-sku='SC-BCRPILWCS-C-52x20']")
	private WebElement CrossSellAddToCartButtonForButterscoutchCreamCuddlePillowcasePackOfTwo;

	// Webelement for Add to cart button for Cuddle pillow case
	public WebElement crossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo() {
		return CrossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo;
	}

	public WebElement crossSellAddToCartButtonForTwilightBlueCuddlePillowcasePackOfTwo() {
		return CrossSellAddToCartButtonForTwilightBlueCuddlePillowcasePackOfTwo;
	}

	public WebElement crossSellAddToCartButtonForButterscoutchCreamCuddlePillowcasePackOfTwo() {
		return CrossSellAddToCartButtonForButterscoutchCreamCuddlePillowcasePackOfTwo;
	}

	// Xpath for Color options in cross sell for Cuddle pillow case
	@FindBy(xpath = "//li[@data-value='pc_dolphingrey']")
	private WebElement CrossSellDolPhinGrayCuddlePillowcaseColor;

	@FindBy(xpath = "//li[@data-value='pc_twilightblue']")
	private WebElement CrossSellTwilightBlueCuddlePillowcaseColor;

	@FindBy(xpath = "//li[@data-value='pc_butterscotchcream']")
	private WebElement CrossSellButterscoutchCreamCuddlePillowcaseColor;

	// Webelement for Color options in cross sell for Cuddle pillow case
	public WebElement crossSellDolPhinGrayCuddlePillowcaseColor() {
		return CrossSellDolPhinGrayCuddlePillowcaseColor;
	}

	public WebElement crossSellTwilightBlueCuddlePillowcaseColor() {
		return CrossSellTwilightBlueCuddlePillowcaseColor;
	}

	public WebElement crossSellButterscoutchCreamCuddlePillowcaseColor() {
		return CrossSellButterscoutchCreamCuddlePillowcaseColor;
	}

	// Xpath for all the products present in Shop from our Best seller products
	// section
	@FindBy(xpath = "//div[@id='product_page_629264']//a[@class='shop-more']")
	private WebElement PlusMattressShopNowButton;

	@FindBy(xpath = "//div[@id='product_page_98749']//a[@class='shop-more']")
	private WebElement MemoryFoamPillowShopNowButton;

	@FindBy(xpath = "//div[@id='product_page_629227']//a[@class='shop-more']")
	private WebElement OriginalMattressShopNowButton;

	@FindBy(xpath = "//div[@id='product_page_214599']//a[@class='shop-more']")
	private WebElement ReversibleComforterShopNowButton;

	@FindBy(xpath = "//div[@id='product_page_214583']//a[@class='shop-more']")
	private WebElement CloudPillowShopNowButton;

	// Webelement for all the products present in Our most loved products section
	public WebElement plusMattressShopNowButton() {
		return PlusMattressShopNowButton;
	}

	public WebElement memoryFoamPillowShopNowButton() {
		return MemoryFoamPillowShopNowButton;
	}

	public WebElement originalMattressShopNowButton() {
		return OriginalMattressShopNowButton;
	}

	public WebElement reversibleComforterShopNowButton() {
		return ReversibleComforterShopNowButton;
	}

	public WebElement cloudPillowShopNowButton() {
		return CloudPillowShopNowButton;
	}

	public void plusMattressInBestSellerProductSection() {
		Actions productscroll = new Actions(driver);
		productscroll.moveToElement(PlusMattressShopNowButton).build().perform();
	}

	public void memoryFoamPillowInBestSellerProductSection() {
		Actions productscroll = new Actions(driver);
		productscroll.moveToElement(MemoryFoamPillowShopNowButton).build().perform();

	}

	public void originalMattressInBestSellerProductSection() {
		Actions productscroll = new Actions(driver);
		productscroll.moveToElement(OriginalMattressShopNowButton).build().perform();
	}

	public void reversibleComforterInBestSellerProductSection() {
		Actions productscroll = new Actions(driver);
		productscroll.moveToElement(ReversibleComforterShopNowButton).build().perform();
	}

	public void cloudPillowInBestSellerProductSection() {
		Actions productscroll = new Actions(driver);
		productscroll.moveToElement(CloudPillowShopNowButton).build().perform();
	}

	// Xpath for Cross icon of offer modal
	@FindBy(xpath = "//*[@class='soundest-form-background-image-close ']")
	private WebElement CrossIconOfoffer;

	// Webelement for Cross icon of offer modal
	public WebElement crossIconOfoffer() {
		return CrossIconOfoffer;
	}

	// Xpath for Cross icon of offer modal
	@FindBy(xpath = "//button[@class='single_add_to_cart_button btn-block alt']")
	private WebElement AddtoCart;

	// Webelement for Cross icon of offer modal
	public WebElement addtoCart() {
		return AddtoCart;
	}

	public void closeoffer() {

		try {
			CrossIconOfoffer.click();
			log.info("Clicked on First modal cross icon");

		} catch (Exception e) {
			log.error("Offer modal is not shwoing");
		}
	}

	/*
	 * public void selectSize() throws Exception { Actions sizeselect = new
	 * Actions(driver);
	 * sizeselect.moveToElement(SizeDropdown).click(SizeDropdown).build().perform();
	 * 
	 * }
	 */

	// Qunatity dropdown selection section
	@FindBy(xpath = "//div[@class='product_main_quantity']")
	private WebElement QuantityField;

	// Webelement for single original mattress
	public WebElement quantityField() {
		return QuantityField;
	}

	// Xpath for Quantity selection box element
	@FindBy(xpath = "//div[@class='product_main_quantity']//input[@class='plus']")
	private WebElement IncreaseQuantity;

	@FindBy(xpath = "//div[@class='product_main_quantity']//input[@class='minus']")
	private WebElement DecreaseQuantity;

	@FindBy(xpath = "//input[@class='input-text qty text']")
	private WebElement EnterQuantityManually;

	// Webelement for Quantity selection box element
	public WebElement increaseQuantity() {
		return IncreaseQuantity;
	}

	public WebElement decreaseQuantity() {
		return DecreaseQuantity;
	}

	public WebElement enterQuantityManually() {
		return EnterQuantityManually;
	}

	public void quantityselect() {

		Actions cart = new Actions(driver);
		// cart.moveToElement(QuantityField).click(QuantityField).build().perform();
		cart.moveToElement(QuantityField).build().perform();

		// QuantityField.click();
		// QuantitySelection.click();
	}

	// Xpath for Changed Add to cart button
	@FindBy(xpath = "//button[@class='single_add_to_cart_button btn-block alt btn-orange inverse']")
	private WebElement ChangedAddToCartButton;

	// Webelement for Changed Add to cart button
	public WebElement changedAddToCartButton() {
		return ChangedAddToCartButton;
	}

	// Cross selling section product Add to cart button xpath section on product
	// details page
	@FindBy(xpath = "//span[@data-sku='SC-BBYHPILW-S-9x8']")
	private WebElement CrossSellAddToCartButtonForBabyHeadPillow;

	@FindBy(xpath = "//span[@data-sku='SC-BBYBOLPILW2-S-18x7']")
	private WebElement CrossSellAddToCartButtonForBabyBolsterPillow;

	@FindBy(xpath = "//span[@data-sku='SC-BBYCOMF-S-42x34']")
	private WebElement CrossSellAddToCartButtonForBabyComforter;

	@FindBy(xpath = "//span[@data-sku='SC-BBYCRBSHEET-S-52x28']")
	private WebElement CrossSellAddToCartButtonForBabyCribSheet;

	// Webelement option for Cross selling section Add to cart product button
	public WebElement crossSellAddToCartButtonForBabyHeadPillow() {
		return CrossSellAddToCartButtonForBabyHeadPillow;
	}

	public WebElement crossSellAddToCartButtonForBabyBolsterPillow() {
		return CrossSellAddToCartButtonForBabyBolsterPillow;
	}

	public WebElement crossSellAddToCartButtonForBabyComforter() {
		return CrossSellAddToCartButtonForBabyComforter;
	}

	public WebElement crossSellAddToCartButtonForBabyCribSheet() {
		return CrossSellAddToCartButtonForBabyCribSheet;
	}

	// Xpath for increment and decrement product quantity icon of Baby Bolster
	// pillow in cross selling product section
	@FindBy(xpath = "//div[@data-producttype='baby_bolsterpillow']//input[@class='plus']")
	private WebElement CrossSellBabyBolsterPillowIncrementQuantity;

	@FindBy(xpath = "//div[@data-producttype='baby_bolsterpillow']//input[@class='minus']")
	private WebElement CrossSellBabyBolsterPillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Baby
	// Bolster pillow in cross selling product section
	public WebElement crossSellBabyBolsterPillowIncrementQuantity() {
		return CrossSellBabyBolsterPillowIncrementQuantity;
	}

	public WebElement crossSellBabyBolsterPillowDecreaseQuantity() {
		return CrossSellBabyBolsterPillowDecreaseQuantity;
	}

	// Xpath for increment and decrement product quantity icon of Baby Head pillow
	// in cross selling product section
	@FindBy(xpath = "//div[@data-producttype='baby_headpillow']//input[@class='plus']")
	private WebElement CrossSellBabyHeadPillowIncrementQuantity;

	@FindBy(xpath = "//div[@data-producttype='baby_headpillow']//input[@class='minus']")
	private WebElement CrossSellBabyHeadPillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Baby
	// Head pillow in cross selling product section
	public WebElement crossSellBabyHeadPillowIncrementQuantity() {
		return CrossSellBabyHeadPillowIncrementQuantity;
	}

	public WebElement crossSellBabyHeadPillowDecreaseQuantity() {
		return CrossSellBabyHeadPillowDecreaseQuantity;
	}

	// Xpath for increment and decrement product quantity icon of Baby Crib Sheet in
	// cross selling product section
	@FindBy(xpath = "//div[@data-producttype='baby_cribsheet']//input[@class='plus']")
	private WebElement CrossSellBabyCribSheetIncrementQuantity;

	@FindBy(xpath = "//div[@data-producttype='baby_cribsheet']//input[@class='minus']")
	private WebElement CrossSellBabyCribSheetDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Baby
	// crib sheet in cross selling product section
	public WebElement crossSellBabyCribSheetIncrementQuantity() {
		return CrossSellBabyCribSheetIncrementQuantity;
	}

	public WebElement crossSellBabyCribSheetDecreaseQuantity() {
		return CrossSellBabyCribSheetDecreaseQuantity;
	}

	// Xpath for increment and decrement product quantity icon of Baby Comforter in
	// cross selling product section
	@FindBy(xpath = "//div[@data-producttype='baby_comforter']//input[@class='plus']")
	private WebElement CrossSellBabyComforterIncrementQuantity;

	@FindBy(xpath = "//div[@data-producttype='baby_comforter']//input[@class='minus']")
	private WebElement CrossSellBabyComforterDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Baby
	// Comforter in cross selling product section
	public WebElement crossSellBabyComforterIncrementQuantity() {
		return CrossSellBabyComforterIncrementQuantity;
	}

	public WebElement crossSellBabyComforterDecreaseQuantity() {
		return CrossSellBabyComforterDecreaseQuantity;
	}

	@FindBy(xpath = "//button[text()='Select Size']")
	private WebElement StickySelectSizeButton;

	@FindBy(xpath = "//span[@id='select_a_variation_error']")
	private WebElement SelectSizeErrorMessage;

	@FindBy(xpath = "//span[@id='picMsg']")
	private WebElement DeliveryTimelineErrorMessageForSelectingSize;

	public WebElement stickySelectSizeButton() {
		return StickySelectSizeButton;
	}

	public WebElement selectSizeErrorMessage() {
		return SelectSizeErrorMessage;
	}

	public WebElement deliveryTimelineErrorMessageForSelectingSize() {
		return DeliveryTimelineErrorMessageForSelectingSize;
	}

	public void scrollToDefaultAddToCart() {
		// List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To
		// Cart']"));
		WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).build().perform();
	}

	public void scrollToChangedAddToCart() {
		// List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To
		// Cart']"));
		WebElement add1 = driver.findElementByXPath(
				"(//button[@class='single_add_to_cart_button btn-block alt btn-orange inverse'])[2]");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).build().perform();
	}

	public void scrollToChangeCategoryDefaultAddToCart() {
		// List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To
		// Cart']"));
		WebElement add1 = driver.findElementByXPath(
				"(//button[@class='single_add_to_cart_button btn-block alt disabled wc-variation-selection-needed'])[2]");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).build().perform();
	}

	public void scrollToBuyBundleButton() {
		// List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To
		// Cart']"));
		WebElement add1 = driver.findElementByXPath("//button[@id='bundlePurchase']");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).build().perform();
	}

	public void defaultAddToCart() {
		// List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To
		// Cart']"));//div[@class='productDirectPurchase hidden_form
		// plus']//button[@type='button'][normalize-space()='Add To Cart']
		// WebElement add1 =
		// driver.findElementByXPath("(//button[@class='single_add_to_cart_button
		// btn-block alt'])[2]");
		WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).click(add1).build().perform();
	}

	public void changedaddToCart() {
		// List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To
		// Cart']"));//div[@class='productDirectPurchase hidden_form
		// plus']//button[@type='button'][normalize-space()='Add To Cart']
		WebElement add1 = driver.findElementByXPath(
				"(//button[@class='single_add_to_cart_button btn-block alt btn-orange inverse'])[2]");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).click(add1).build().perform();
	}

	public void switchingToChildWindow() {
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> It = s1.iterator();
		String parentWindow = It.next();
		String childWindow = It.next();
		driver.switchTo().window(childWindow);
	}

	// Check delivery timeline on product details page
	@FindBy(xpath = "//input[@id='pincode']")
	private WebElement EnterPincodeField;

	@FindBy(xpath = "//a[@onclick='checkPincode()']")
	private WebElement CheckPincodeButton;

	@FindBy(xpath = "//div[text()='Estimated Delivery: ']")
	private WebElement DeliveryTimelineMessage;

	// Webelement for Check delivery timeline on product details page
	public WebElement enterPincodeField() {
		return EnterPincodeField;
	}

	public WebElement checkPincodeButton() {
		return CheckPincodeButton;
	}

	public WebElement deliveryTimelineMessage() {
		return DeliveryTimelineMessage;
	}

	// Cross selling section for Fitted Bed Sheet Product
	// Xpath for category Type field of Fitted Bed Sheet cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//div[@data-name='scategory'])")
	private WebElement CrossSellFittedBedSheetCategoryField;

	// Webelement option for category Type field of Fitted Bed Sheet cross selling
	// product section
	public WebElement crossSellFittedBedSheetCategoryField() {
		return CrossSellFittedBedSheetCategoryField;
	}

	// Xpath for different category field of Fitted Bed Sheet cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-value='Queen'])")
	private WebElement CrossSellFittedBedSheetQueenCategoryField;

	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-value='King'])")
	private WebElement CrossSellFittedBedSheetKingCategoryField;

	// Webelement option for category of Fitted Bed Sheet cross selling product
	// section
	public WebElement crossSellFittedBedSheetQueenCategoryField() {
		return CrossSellFittedBedSheetQueenCategoryField;
	}

	public WebElement crossSellFittedBedSheetKingCategoryField() {
		return CrossSellFittedBedSheetKingCategoryField;
	}

	// Xpath for Different Color Option for fitted bed sheet in cross selling
	// product section
	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-value='dolphingrey'])")
	private WebElement CrossSellFittedBedSheetDolphinGrayColor;

	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-value='twilightblue'])")
	private WebElement CrossSellFittedBedSheetTwilightBlueColor;

	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-value='butterscotchcream'])")
	private WebElement CrossSellFittedBedSheetButterScoutchCreamColor;

	// Webelement for Different Color Option for fitted bed sheet in cross selling
	// product section
	public WebElement crossSellFittedBedSheetDolphinGrayColor() {
		return CrossSellFittedBedSheetDolphinGrayColor;
	}

	public WebElement crossSellFittedBedSheetTwilightBlueColor() {
		return CrossSellFittedBedSheetTwilightBlueColor;
	}

	public WebElement crossSellFittedBedSheetButterScoutchCreamColor() {
		return CrossSellFittedBedSheetButterScoutchCreamColor;
	}

	// Xpath for Size field of Fitted bedsheet in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//div[@data-name='variation'])")
	private WebElement CrossSellFittedBedSheetSizeField;

	// Webelement for Size field of Fitted bedsheet in cross selling product section
	public WebElement crossSellFittedBedSheetSizeField() {
		return CrossSellFittedBedSheetSizeField;
	}

	// Xpath for different size dropdown option for Fitted Bed Sheet in cross
	// selling product
	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-sku='SC-BCRFTDSHEET-Q-78x60'])")
	private WebElement CrossSellFittedBedSheetButterScoutchCreamColorQueen78x60Size;

	@FindBy(xpath = "(//div[@data-producttype='fitted_bedsheet']//li[@data-sku='SC-BCRFTDSHEET-Q-72x60'])")
	private WebElement CrossSellFittedBedSheetButterScoutchCreamColorQueen72x60Size;

	// Webelement for different size dropdown option for Fitted Bed Sheet in cross
	// selling product
	public WebElement crossSellFittedBedSheetButterScoutchCreamColorQueen78x60Size() {
		return CrossSellFittedBedSheetButterScoutchCreamColorQueen78x60Size;
	}

	public WebElement crossSellFittedBedSheetButterScoutchCreamColorQueen72x60Size() {
		return CrossSellFittedBedSheetButterScoutchCreamColorQueen72x60Size;
	}

	// Xpath for Add to cart button for different Fitted Bed sheet product variation
	// in cross selling product section
	@FindBy(xpath = "//span[@data-sku='SC-DGRFTDSHEET-K-78x72']")
	private WebElement CrossSellAddToCartButtonForKing78x72FittedBedSheetDolphinGray;

	@FindBy(xpath = "//span[@data-sku='SC-TBLFTDSHEET-K-78x72']")
	private WebElement CrossSellAddToCartButtonForKing78x72FittedBedSheetTwilightBlue;

	@FindBy(xpath = "//span[@data-sku='SC-BCRFTDSHEET-K-78x72']")
	private WebElement CrossSellAddToCartButtonForKing78x72FittedBedSheetButterScoutchCream;

	@FindBy(xpath = "//span[@data-sku='SC-DGRFTDSHEET-K-72x72']")
	private WebElement CrossSellAddToCartButtonForKing72x72FittedBedSheetDolphinGray;

	@FindBy(xpath = "//span[@data-sku='SC-TBLFTDSHEET-K-72x72']")
	private WebElement CrossSellAddToCartButtonForKing72x72FittedBedSheetTwilightBlue;

	@FindBy(xpath = "//span[@data-sku='SC-BCRFTDSHEET-K-72x72']")
	private WebElement CrossSellAddToCartButtonForKing72x72FittedBedSheetButterScoutchCream;

	@FindBy(xpath = "//span[@data-sku='SC-DGRFTDSHEET-Q-78x60']")
	private WebElement CrossSellAddToCartButtonForQueen78x60FittedBedSheetDolphinGray;

	@FindBy(xpath = "//span[@data-sku='SC-TBLFTDSHEET-Q-78x60']")
	private WebElement CrossSellAddToCartButtonForQueen78x60FittedBedSheetTwilightBlue;

	@FindBy(xpath = "//span[@data-sku='SC-BCRFTDSHEET-Q-78x60']")
	private WebElement CrossSellAddToCartButtonForQueen78x60FittedBedSheetButterScoutchCream;

	@FindBy(xpath = "//span[@data-sku='SC-DGRFTDSHEET-Q-72x60']")
	private WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetDolphinGray;

	@FindBy(xpath = "//span[@data-sku='SC-TBLFTDSHEET-Q-72x60']")
	private WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetTwilightBlue;

	@FindBy(xpath = "//span[@data-sku='SC-BCRFTDSHEET-Q-72x60']")
	private WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetButterScoutchCream;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement CrossSellAddToCartButtonForQueen78x60FittedBedSheetDolphinGray() {
		return CrossSellAddToCartButtonForQueen78x60FittedBedSheetDolphinGray;
	}

	public WebElement CrossSellAddToCartButtonForQueen78x60FittedBedSheetTwilightBlue() {
		return CrossSellAddToCartButtonForQueen78x60FittedBedSheetTwilightBlue;
	}

	public WebElement CrossSellAddToCartButtonForQueen78x60FittedBedSheetButterScoutchCream() {
		return CrossSellAddToCartButtonForQueen78x60FittedBedSheetButterScoutchCream;
	}

	public WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetDolphinGray() {
		return CrossSellAddToCartButtonForQueen72x60FittedBedSheetDolphinGray;
	}

	public WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetTwilightBlue() {
		return CrossSellAddToCartButtonForQueen72x60FittedBedSheetTwilightBlue;
	}

	public WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetButterScoutchCream() {
		return CrossSellAddToCartButtonForQueen72x60FittedBedSheetButterScoutchCream;
	}

	public WebElement CrossSellAddToCartButtonForKing78x72FittedBedSheetDolphinGray() {
		return CrossSellAddToCartButtonForKing78x72FittedBedSheetDolphinGray;
	}

	public WebElement CrossSellAddToCartButtonForKing78x72FittedBedSheetTwilightBlue() {
		return CrossSellAddToCartButtonForKing78x72FittedBedSheetTwilightBlue;
	}

	public WebElement CrossSellAddToCartButtonForKing78x72FittedBedSheetButterScoutchCream() {
		return CrossSellAddToCartButtonForKing78x72FittedBedSheetButterScoutchCream;
	}

	public WebElement CrossSellAddToCartButtonForKing72x72FittedBedSheetDolphinGray() {
		return CrossSellAddToCartButtonForKing72x72FittedBedSheetDolphinGray;
	}

	public WebElement CrossSellAddToCartButtonForKing72x72FittedBedSheetTwilightBlue() {
		return CrossSellAddToCartButtonForKing72x72FittedBedSheetTwilightBlue;
	}

	public WebElement CrossSellAddToCartButtonForKing72x72FittedBedSheetButterScoutchCream() {
		return CrossSellAddToCartButtonForKing72x72FittedBedSheetButterScoutchCream;
	}

	// Cross selling section for Luxe Comforter Product
	// Xpath for category Type field of Luxe Comforter cross selling product section
	@FindBy(xpath = "//div[@data-producttype='luxe_comforter']//div[@data-name='scategory']")
	private WebElement CrossSellLuxeComforterCategoryField;

	// Webelement option for category Type field of Luxe Comforter cross selling
	// product section
	public WebElement CrossSellLuxeComforterCategoryField() {
		return CrossSellLuxeComforterCategoryField;
	}

	// Xpath for different category field of Luxe Comforter cross selling product
	// section
	@FindBy(xpath = "//div[@data-producttype='luxe_comforter']//li[@data-value='Single']")
	private WebElement CrossSellLuxeComforterSingleCategoryField;

	@FindBy(xpath = "//div[@data-producttype='luxe_comforter']//li[@data-value='Double']")
	private WebElement CrossSellLuxeComforterDoubleCategoryField;

	// Webelement option for category of Luxe Comforter cross selling product
	// section
	public WebElement crossSellLuxeComforterSingleCategoryField() {
		return CrossSellLuxeComforterSingleCategoryField;
	}

	public WebElement crossSellLuxeComforterDoubleCategoryField() {
		return CrossSellLuxeComforterDoubleCategoryField;
	}

	// Xpath for Add to cart button for of Luxe Comforter cross selling product
	// section
	@FindBy(xpath = "//span[@data-sku='SC-EGWTLUXCOMF-S-90x60']")
	private WebElement CrossSellAddToCartButtonForSingleLuxeComforter;

	@FindBy(xpath = "//span[@data-sku='SC-EGWTLUXCOMF-D-90x100']")
	private WebElement CrossSellAddToCartButtonForDoubleLuxeComforter;

	// Webelement for Add to cart button for of Luxe Comforter cross selling product
	// section
	public WebElement crossSellAddToCartButtonForSingleLuxeComforter() {
		return CrossSellAddToCartButtonForSingleLuxeComforter;
	}

	public WebElement crossSellAddToCartButtonForDoubleLuxeComforter() {
		return CrossSellAddToCartButtonForDoubleLuxeComforter;
	}

	// Cross selling section for Hybrid Pillow Product
	// Xpath for category Type field of Hybrid Pillow cross selling product section
	@FindBy(xpath = "//div[@data-producttype='hybrid_pillow']//div[@data-name='scategory']")
	private WebElement CrossSellHybridPillowCategoryField;

	// Webelement option for category Type field of Hybrid Pillow cross selling
	// product section
	public WebElement crossSellHybridPillowCategoryField() {
		return CrossSellHybridPillowCategoryField;
	}

	// Xpath for different category field of Hybrid Pillow cross selling product
	// section
	@FindBy(xpath = "//div[@data-producttype='hybrid_pillow']//li[@data-value='Standard']")
	private WebElement CrossSellHybridPillowStandardCategoryOption;

	@FindBy(xpath = "//div[@data-producttype='hybrid_pillow']//li[@data-value='President']")
	private WebElement CrossSellHybridPillowPresidentCategoryOption;

	// Webelement option for category of Hybrid Pillow cross selling product section
	public WebElement crossSellHybridPillowStandardCategoryOption() {
		return CrossSellHybridPillowStandardCategoryOption;
	}

	public WebElement crossSellHybridPillowPresidentCategoryOption() {
		return CrossSellHybridPillowPresidentCategoryOption;
	}

	// Xpath for pack field of Hybrid pillow in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='hybrid_pillow']//div[@data-name='pack'])")
	private WebElement CrossSellPackFieldOfHybridPillow;

	// Webelement option for pack field of Hybrid pillow in cross selling product
	// section
	public WebElement crossSellPackFieldOfHybridPillow() {
		return CrossSellPackFieldOfHybridPillow;
	}

	// Xpath for pack field of Hybrid pillow in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='hybrid_pillow']//li[@data-value='pillow-1'])")
	private WebElement CrossSellPackOneOfHybridPillow;

	@FindBy(xpath = "(//div[@data-producttype='hybrid_pillow']//li[@data-value='pillow-2'])")
	private WebElement CrossSellPackTwoOfHybridPillow;

	// Webelement option for pack field of Hybrid pillow in cross selling product
	// section
	public WebElement crossSellPackOneOfHybridPillow() {
		return CrossSellPackOneOfHybridPillow;
	}

	public WebElement crossSellPackTwoOfHybridPillow() {
		return CrossSellPackTwoOfHybridPillow;
	}

	// Xpath for increment and decrement product quantity icon of Hybrid pillow in
	// cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='hybrid_pillow']//input[@class='plus'])")
	private WebElement CrossSellHybridPillowIncrementQuantity;

	@FindBy(xpath = "(//div[@data-producttype='hybrid_pillow']//input[@class='minus'])")
	private WebElement CrossSellHybridPillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Hybrid
	// pillow in cross selling product section
	public WebElement crossSellHybridPillowIncrementQuantity() {
		return CrossSellHybridPillowIncrementQuantity;
	}

	public WebElement crossSellHybridPillowDecreaseQuantity() {
		return CrossSellHybridPillowDecreaseQuantity;
	}

	// Cross selling section for CoolTec MemoryFoam Pillow Product
	// Xpath for category Type field of CoolTec MemoryFoam Pillow cross selling
	// product section
	@FindBy(xpath = "//div[@data-producttype='cooltecmemorypillow']//div[@data-name='scategory']")
	private WebElement CrossSellCoolTecMemoryFoamPillowCategoryField;

	// Webelement option for category Type field of CoolTec MemoryFoam Pillow cross
	// selling product section
	public WebElement crossSellCoolTecMemoryFoamPillowCategoryField() {
		return CrossSellCoolTecMemoryFoamPillowCategoryField;
	}

	// Xpath for different category field of CoolTec MemoryFoam Pillow cross selling
	// product section
	@FindBy(xpath = "//div[@data-producttype='cooltecmemorypillow']//li[@data-value='Standard']")
	private WebElement CrossSellCoolTecMemoryFoamPillowStandardCategoryOption;

	@FindBy(xpath = "//div[@data-producttype='cooltecmemorypillow']//li[@data-value='President']")
	private WebElement CrossSellCoolTecMemoryFoamPillowPresidentCategoryOption;

	// Webelement option for category of CoolTec MemoryFoam Pillow cross selling
	// product section
	public WebElement crossSellCoolTecMemoryFoamPillowStandardCategoryOption() {
		return CrossSellCoolTecMemoryFoamPillowStandardCategoryOption;
	}

	public WebElement crossSellCoolTecMemoryFoamPillowPresidentCategoryOption() {
		return CrossSellCoolTecMemoryFoamPillowPresidentCategoryOption;
	}

	// Xpath for pack field of CoolTec MemoryFoam pillow in cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='cooltecmemorypillow']//div[@data-name='pack'])")
	private WebElement CrossSellPackFieldOfCoolTecMemoryFoamPillow;

	// Webelement option for pack field of CoolTec MemoryFoam pillow in cross
	// selling product section
	public WebElement crossSellPackFieldOfCoolTecMemoryFoamPillow() {
		return CrossSellPackFieldOfCoolTecMemoryFoamPillow;
	}

	// Xpath for pack field of CoolTec MemoryFoam pillow in cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='cooltecmemorypillow']//li[@data-value='pillow-1'])")
	private WebElement CrossSellPackOneOfCoolTecMemoryFoamPillow;

	@FindBy(xpath = "(//div[@data-producttype='cooltecmemorypillow']//li[@data-value='pillow-2'])")
	private WebElement CrossSellPackTwoOfCoolTecMemoryFoamPillow;

	// Webelement option for pack field of CoolTec MemoryFoam pillow in cross
	// selling product section
	public WebElement crossSellPackOneOfCoolTecMemoryFoamPillow() {
		return CrossSellPackOneOfCoolTecMemoryFoamPillow;
	}

	public WebElement crossSellPackTwoOfCoolTecMemoryFoamPillow() {
		return CrossSellPackTwoOfCoolTecMemoryFoamPillow;
	}

	// Xpath for increment and decrement product quantity icon of CoolTec MemoryFoam
	// pillow in cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='cooltecmemorypillow']//input[@class='plus'])")
	private WebElement CrossSellCoolTecMemoryFoamPillowIncrementQuantity;

	@FindBy(xpath = "(//div[@data-producttype='cooltecmemorypillow']//input[@class='minus'])")
	private WebElement CrossSellCoolTecMemoryFoamPillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of
	// CoolTec MemoryFoam pillow in cross selling product section
	public WebElement crossSellCoolTecMemoryFoamPillowIncrementQuantity() {
		return CrossSellCoolTecMemoryFoamPillowIncrementQuantity;
	}

	public WebElement crossSellCoolTecMemoryFoamPillowDecreaseQuantity() {
		return CrossSellCoolTecMemoryFoamPillowDecreaseQuantity;
	}

	// Cross selling section for Duvet Cover Product
	// Xpath for Different Color Option for Duvet Cover in cross selling product
	// section
	@FindBy(xpath = "(//div[@data-producttype='duvet_cover']//li[@data-value='dc_dolphingrey'])")
	private WebElement CrossSellDuvetCoverDolphinGrayColor;

	@FindBy(xpath = "(//div[@data-producttype='duvet_cover']//li[@data-value='dc_twilightblue'])")
	private WebElement CrossSellDuvetCoverTwilightBlueColor;

	@FindBy(xpath = "(//div[@data-producttype='duvet_cover']//li[@data-value='dc_butterscotchcream'])")
	private WebElement CrossSellDuvetCoverButterScoutchCreamColor;

	// Webelement for Different Color Option for fitted bed sheet in cross selling
	// product section
	public WebElement crossSellDuvetCoverDolphinGrayColor() {
		return CrossSellDuvetCoverDolphinGrayColor;
	}

	public WebElement crossSellDuvetCoverTwilightBlueColor() {
		return CrossSellDuvetCoverTwilightBlueColor;
	}

	public WebElement crossSellDuvetCoverButterScoutchCreamColor() {
		return CrossSellDuvetCoverButterScoutchCreamColor;
	}

	// Xpath for Add to cart button for different Duvet Cover product variation in
	// cross selling product section
	@FindBy(xpath = "(//span[@data-sku='SC-DGRDVTCOVER-D-90x100'])")
	private WebElement CrossSellAddToCartButtonForDoubleDolphinGrayDuvetCover;

	@FindBy(xpath = "(//span[@data-sku='SC-TBLDVTCOVER-D-90x100'])")
	private WebElement CrossSellAddToCartButtonForDoubleTwilightBlueDuvetCover;

	@FindBy(xpath = "(//span[@data-sku='SC-BCRDVTCOVER-D-90x100'])")
	private WebElement CrossSellAddToCartButtonForDoubleButterScoutchCreamDuvetCover;

	// Webelement for Add to cart button for different Duvet Cover product variation
	// in cross selling product section
	public WebElement crossSellAddToCartButtonForDoubleDolphinGrayDuvetCover() {
		return CrossSellAddToCartButtonForDoubleDolphinGrayDuvetCover;
	}

	public WebElement crossSellAddToCartButtonForDoubleTwilightBlueDuvetCover() {
		return CrossSellAddToCartButtonForDoubleTwilightBlueDuvetCover;
	}

	public WebElement crossSellAddToCartButtonForDoubleButterScoutchCreamDuvetCover() {
		return CrossSellAddToCartButtonForDoubleButterScoutchCreamDuvetCover;
	}

	// Xpath for increment and decrement product quantity icon of cloud pillow in
	// cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='duvet_cover']//input[@class='plus'])")
	private WebElement CrossSellDuvetCoverIncrementQuantity;

	@FindBy(xpath = "(//div[@data-producttype='duvet_cover']//input[@class='minus'])")
	private WebElement CrossSellDuvetCoverDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of cloud
	// pillow in cross selling product section
	public WebElement crossSellDuvetCoverIncrementQuantity() {
		return CrossSellDuvetCoverIncrementQuantity;
	}

	public WebElement crossSellDuvetCoverDecreaseQuantity() {
		return CrossSellDuvetCoverDecreaseQuantity;
	}

	// spin the wheel pop up
	@FindBy(xpath = "//div[@class='wlwl-close-wheel']")
	private WebElement SpinTheWheelCrossIconOffer;

	// Webelement for spin the wheel pop up
	public WebElement spinTheWheelCrossIconOffer() {
		return SpinTheWheelCrossIconOffer;
	}

	// Xpath for Add to cart button
	@FindBy(xpath = "(//span[@data-sku='SC-ULTM-Q-78x60x8'])")
	private WebElement CrossSellAddToCartButtonForQueenUltima78x60x8;

	@FindBy(xpath = "(//span[@data-sku='SC-ORIG-Q-78x60x6'])")
	private WebElement CrossSellAddToCartButtonForQueenOriginal78x60x6;

	@FindBy(xpath = "(//span[@data-sku='SC-HYB-LATEX-Q-78x60x6'])")
	private WebElement CrossSellAddToCartButtonForQueenLatex78x60x6;

	@FindBy(xpath = "(//span[@data-sku='SC-HYB-LATEX-Q-78x60x8'])")
	private WebElement CrossSellAddToCartButtonForQueenLatex78x60x8;

	// Webelement for Add to cart button
	public WebElement crossSellAddToCartButtonForQueenUltima78x60x8() {
		return CrossSellAddToCartButtonForQueenUltima78x60x8;
	}

	public WebElement crossSellAddToCartButtonForQueenOriginal78x60x6() {
		return CrossSellAddToCartButtonForQueenOriginal78x60x6;
	}

	public WebElement crossSellAddToCartButtonForQueenLatex78x60x6() {
		return CrossSellAddToCartButtonForQueenLatex78x60x6;
	}

	public WebElement crossSellAddToCartButtonForQueenLatex78x60x8() {
		return CrossSellAddToCartButtonForQueenLatex78x60x8;
	}

	// Xpath for different size options for Latex mattress when king category is
	// selected
	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-sku='SC-HYB-LATEX-K-75x72x6']")
	private WebElement CrossSellLatexMattressKing75x72x6;

	@FindBy(xpath = "//div[@data-producttype='latex']//li[@data-sku='SC-HYB-LATEX-K-75x72x8']")
	private WebElement CrossSellLatexMattressKing75x72x8;

	// Webelement for for different size options for Latex mattress when king
	// category is selected
	public WebElement crossSellLatexMattressKing75x72x6() {
		return CrossSellLatexMattressKing75x72x6;
	}

	public WebElement crossSellLatexMattressKing75x72x8() {
		return CrossSellLatexMattressKing75x72x8;
	}

	// Xpath for Add to cart button for Latex mattress when king category is
	// selected
	@FindBy(xpath = "//span[@data-sku='SC-HYB-LATEX-K-75x72x6']")
	private WebElement CrossSellAddToCartLatexMattressKing75x72x6;

	@FindBy(xpath = "//span[@data-sku='SC-HYB-LATEX-K-78x72x6']")
	private WebElement CrossSellAddToCartLatexMattressKing78x72x6;

	@FindBy(xpath = "//span[@data-sku='SC-HYB-LATEX-K-75x72x8']")
	private WebElement CrossSellAddToCartLatexMattressKing75x72x8;

	// Webelement for Add to cart button for Latex mattress when king category is
	// selected
	public WebElement crossSellAddToCartLatexMattressKing75x72x6() {
		return CrossSellAddToCartLatexMattressKing75x72x6;
	}

	public WebElement crossSellAddToCartLatexMattressKing78x72x6() {
		return CrossSellAddToCartLatexMattressKing78x72x6;
	}

	public WebElement crossSellAddToCartLatexMattressKing75x72x8() {
		return CrossSellAddToCartLatexMattressKing75x72x8;
	}

	// Cross selling section for Couple Pillow Product
	@FindBy(xpath = "//div[@data-producttype='couple_pillow']//div[@data-name='scategory']")
	private WebElement CrossSellCouplePillowCategoryField;

	// Webelement option for category Type field of Couple Pillow cross selling
	// product section
	public WebElement crossSellCouplePillowCategoryField() {
		return CrossSellCouplePillowCategoryField;
	}

	// Xpath for dropdown category option of Couple Pillow Product variation in
	// cross selling product section
	@FindBy(xpath = "//li[@data-value='Left Hand']")
	private WebElement CrossSellLeftHandSideCouplePillowCategoryOption;

	@FindBy(xpath = "//li[@data-value='Right Hand']")
	private WebElement CrossSellRightHandSideCouplePillowCategoryOption;

	// Webelement for Add to cart button for different Couple Pillow Product
	// variation in cross selling product section
	public WebElement crossSellLeftHandSideCouplePillowCategoryOption() {
		return CrossSellLeftHandSideCouplePillowCategoryOption;
	}

	public WebElement crossSellRightHandSideCouplePillowCategoryOption() {
		return CrossSellRightHandSideCouplePillowCategoryOption;
	}

	// Xpath for Add to cart button for different Couple Pillow Product variation in
	// cross selling product section
	@FindBy(xpath = "(//span[@data-sku='SC-LHCUPLPILW-SP-S-26x16'])")
	private WebElement CrossSellAddToCartButtonForLeftHandSideCouplePillow;

	@FindBy(xpath = "(//span[@data-sku='SC-RHCUPLPILW-SP-S-26x16'])")
	private WebElement CrossSellAddToCartButtonForRightHandSideCouplePillow;

	// Webelement for Add to cart button for different Couple Pillow Product
	// variation in cross selling product section
	public WebElement crossSellAddToCartButtonForLeftHandSideCouplePillow() {
		return CrossSellAddToCartButtonForLeftHandSideCouplePillow;
	}

	public WebElement crossSellAddToCartButtonForRightHandSideCouplePillow() {
		return CrossSellAddToCartButtonForRightHandSideCouplePillow;
	}

	// Xpath for increment and decrement product quantity icon of Couple pillow in
	// cross selling product section
	@FindBy(xpath = "(//div[@data-producttype='couple_pillow']//input[@class='plus'])")
	private WebElement CrossSellCouplePillowIncrementQuantity;

	@FindBy(xpath = "(//div[@data-producttype='couple_pillow']//input[@class='minus'])")
	private WebElement CrossSellCouplePillowDecreaseQuantity;

	// Webelement option for increment and decrement product quantity icon of Couple
	// pillow in cross selling product section
	public WebElement crossSellCouplePillowIncrementQuantity() {
		return CrossSellCouplePillowIncrementQuantity;
	}

	public WebElement crossSellCouplePillowDecreaseQuantity() {
		return CrossSellCouplePillowDecreaseQuantity;
	}

	// Xpath for Cross Sell Products Title text
	@FindBy(xpath = "//span[@class='product_cross_sell_title']")
	private WebElement CrossSellProductsTitle;

	// Webelement for Cross Sell Products Title text
	public WebElement crossSellProductsTitle() {
		return CrossSellProductsTitle;
	}

	public void openWebsite() {

		driver.get(prop.getProperty("url"));
		// driver.get("https://sleepycat.in/");
		log.info("Website opened Successfully");

		// wait = new WebDriverWait(driver, 10);
		// driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		// wait.until(ExpectedConditions.visibilityOf(spinTheWheelCrossIconOffer()));
		// spinTheWheelCrossIconOffer().click();
		// log.info("Click on cross icon of spin The Wheel Offer");

	}

	public void crossSellDefaultWhiteColorAddToCartButtonforComforter() {

		CrossSellAddToCartButtonForSingleWhiteColorComforter.click();
		// js.executeScript("arguments[0].click();",
		// CrossSellAddToCartButtonForSingleWhiteColorComforter);
		log.info("Clicked on Add to cart button of Single white Comforter");
	}

	public void crossSellDefaultAddToCartButtonforComforter() {

		CrossSellAddToCartButtonForSingleLimeColorComforter.click();
		// CrossSellAddToCartButtonForSingleCoffeeColorComforter.click();
		// js.executeScript("arguments[0].click();",
		// CrossSellAddToCartButtonForSingleCoffeeColorComforter);
		log.info("Clicked on Add to cart button of Single Lime Comforter");
	}

	public void crossSellComforterChangeMultipleOptionAddToCartButton() throws Exception {

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellComforterCategoryField());
		CrossSellComforterCategoryField.click();
		log.info("Clicked on category field for Comforter");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellDoubleCategoryComforter());
		CrossSellDoubleCategoryComforter.click();
		log.info("Clicked on cross Sell Double Category Comforter option");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellComforterCoffeeColor());
		CrossSellComforterCoffeeColor.click();
		log.info("Clicked on cross Sell Comforter Coffee Color option");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellAddToCartButtonForDoubleCategoryCoffeeComforter());
		CrossSellAddToCartButtonForDoubleCategoryCoffeeComforter.click();
		log.info("Click on add to cart product button of Comforter");

	}

	public void crossSellCloudPillowChangeMultipleOptionAddToCartButton() throws Exception {

		CrossSellCloudPillowCategoryField.click();
		log.info("Clicked on category field for cloud pillow");

		CrossSellPresidentCategoryCloudPillow.click();
		log.info("Clicked on President type option from the dropdown");

		CrossSellPackFieldOfCloudPillow.click();
		log.info("Clicked on Pack field for cloud pillow");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellPackFourOfCloudPillow());
		CrossSellPackFourOfCloudPillow.click();
		log.info("Clicked on Pack of 4 option from dropdown");

		Thread.sleep(1000);
		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellCloudPillowIncrementQuantity());
		CrossSellCloudPillowIncrementQuantity.click();
		log.info("Increment quantity to two");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellCloudPillowIncrementQuantity());
		CrossSellCloudPillowIncrementQuantity.click();
		log.info("Increment quantity to Three");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellCloudPillowDecreaseQuantity());
		CrossSellCloudPillowDecreaseQuantity.click();
		log.info("Decrement quantity to two");

		CrossSellAddtocartPresidentCloudPillowSet4.click();
		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellAddtocartPresidentCloudPillowSet4());
		log.info("Clicked on add to cart button of Cloud pillow");
	}

	public void crossSellDefaultAddToCartButtonforCloudpillow() {

		CrossSellAddToCartButtonForCloudPillow.click();
		log.info("Click on add to cart product button of cloud pillow");
	}

	public void crossSellSoftTouchMemoryPillowChangeMultipleOptionAddToCartButton() throws Exception {

		CrossSellSoftTouchMemoryPillowCategoryField.click();
		log.info("Clicked on category field for SoftTouch Memory pillow");

		CrossSellSoftTouchMemoryPillowPresidentCategory.click();
		log.info("Clicked on President type option from the dropdown");

		Thread.sleep(1000);
		CrossSellSoftTouchMemoryPillowPackField.click();
		log.info("Clicked on Pack field for SoftTouch Memory pillow");

		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellSoftTouchMemoryPillowPackOfTwo());
		CrossSellSoftTouchMemoryPillowPackOfTwo.click();
		log.info("Clicked on Pack of 2 option from dropdown");

		CrossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo.click();
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellAddToCartPresidentSoftTouchMemoryPillowPackTwo());
		log.info("Click on add to cart product button of President SoftTouch Memory pillow Pack of 2");

	}

	public void crossSellDefaultAddToCartButtonforCuddlepillow() {

		CrossSellAddToCartButtonForCuddlePillow.click();
		log.info("Click on add to cart product button of cuddle pillow");
		// js.executeScript("arguments[0].click();",
		// CrossSellAddToCartButtonForSingleCoffeeColorComforter);
	}

	public void crossSellDefaultWhiteProtectorAddToCartButton() {

		CrossSellAddtocartSingleWhiteProtector72x36.click();
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellAddtocartSingleWhiteProtector72x36());
		log.info("Click on add to cart product button of Single Protector");
	}

	public void crossSellDefaultGrayProtectorAddToCartButton() {

		CrossSellAddtocartSingleGreyProtector72x36.click();
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellAddtocartSingleWhiteProtector72x36());
		log.info("Click on add to cart product button of Single Protector");

	}

	public void crossSellChangeMultipleOptionPillowCaseAddToCartButton() throws Exception {

		CrossSellPillowCaseTypeField.click();
		log.info("Clicked on Type field for pillow Cases");

		CrossSellPresidentPillowCases.click();
		log.info("Clicked on President pillow cases type from drodown");

		CrossSellPillowCaseTypeField.click();
		log.info("Clicked on Type field for pillow Cases");

		CrossSellStandardPillowCases.click();
		log.info("Clicked on Standard pillow cases type from drodown");

		CrossSellPillowCaseTypeField.click();
		log.info("Clicked on Type field for pillow Cases");

		CrossSellCuddleTypePillowCases.click();
		log.info("Clicked on Cuddle pillow cases type from drodown");

		Thread.sleep(1000);
		CrossSellTwilightBlueCuddlePillowcaseColor.click();
		log.info("Clicked on Twilight blue color for pillow Cases");

		CrossSellButterscoutchCreamCuddlePillowcaseColor.click();
		log.info("Clicked on Butterscoutch Cream color for pillow Cases");

		CrossSellDolPhinGrayCuddlePillowcaseColor.click();
		log.info("Clicked on Dolphin Gray color for pillow Cases");

		CrossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo.click();
		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",productdetail.crossSellAddToCartButtonForDolPhinGrayCuddlePillowcasePackOfTwo());
		log.info("Clicked on add to cart button of Cuddle pillow Cases Pack of Two");

	}

	public void crossSellChangeMultipleOptionDuvetCoverAddToCartButton() throws Exception {

		CrossSellDuvetCoverTwilightBlueColor.click();
		log.info("Click on Twilight Blue Color for Duvet Cover product");

		CrossSellDuvetCoverButterScoutchCreamColor.click();
		log.info("Click on ButterScoutch Cream Color for Duvet Cover product");

		CrossSellDuvetCoverDolphinGrayColor.click();
		log.info("Click on Dolphin Gray Color for Duvet Cover product");

		Thread.sleep(1000);
		CrossSellDuvetCoverIncrementQuantity.click();
		log.info("Increment quantity to two");

		CrossSellDuvetCoverIncrementQuantity.click();
		log.info("Increment quantity to Three");

		CrossSellDuvetCoverDecreaseQuantity.click();
		log.info("Decrement quantity to two");

		CrossSellAddToCartButtonForDoubleDolphinGrayDuvetCover.click();
		log.info("Clicked on add to cart button of Duvet Cover");

	}

	public void crossSellChangeMultipleOptionFittedBedSheetAddToCartButton() throws Exception {

		CrossSellFittedBedSheetCategoryField.click();
		log.info("Clicked on cross Sell Fitted Bed Sheet Category field");

		Thread.sleep(1000);
		CrossSellFittedBedSheetKingCategoryField.click();
		log.info("Clicked on King Category for Fitted Bed Sheet");

		CrossSellFittedBedSheetCategoryField.click();
		log.info("Again Clicked on cross Sell Fitted Bed Sheet Category field");

		CrossSellFittedBedSheetQueenCategoryField.click();
		log.info("Clicked on Queen Category for Fitted Bed Sheet");

		CrossSellFittedBedSheetDolphinGrayColor.click();
		log.info("Click on Dolphin Gray Color for fitted Bed sheet product");

		CrossSellFittedBedSheetTwilightBlueColor.click();
		log.info("Click on Twilight Blue Color for fitted Bed sheet product");

		CrossSellFittedBedSheetButterScoutchCreamColor.click();
		log.info("Click on ButterScoutch Cream Color for fitted Bed sheet product");

		CrossSellFittedBedSheetSizeField.click();
		log.info("Click on Twilight Blue Color for fitted Bed sheet product");

		CrossSellFittedBedSheetButterScoutchCreamColorQueen72x60Size.click();
		log.info("Click on ButterScoutch Cream Color for fitted Bed sheet product");

		CrossSellFittedBedSheetSizeField.click();
		log.info("Click on Twilight Blue Color for fitted Bed sheet product");

		CrossSellFittedBedSheetButterScoutchCreamColorQueen78x60Size.click();
		log.info("Click on ButterScoutch Cream Color for fitted Bed sheet product");

		Thread.sleep(2000);
		CrossSellAddToCartButtonForQueen78x60FittedBedSheetButterScoutchCream.click();
		log.info("Click on add to cart product button of Queen FittedBed sheet product");

	}

	public void crossSellChangeMultipleOptionGrayProtectorAddToCartButton() throws Exception {

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellGreyColorProtector());
		CrossSellGreyColorProtector.click();
		log.info("Clicked on cross Sell Gray color option in Protector");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellWhiteColorProtector());
		CrossSellWhiteColorProtector.click();
		log.info("Clicked on cross Sell White color option in Protector");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellGreyColorProtector());
		CrossSellGreyColorProtector.click();
		log.info("Clicked on cross Sell Gray color option in Protector");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellProtectorCategoryField());
		CrossSellProtectorCategoryField.click();
		log.info("Clicked on category field for Protector");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellQueenCategoryProtector());
		CrossSellQueenCategoryProtector.click();
		log.info("Clicked on cross Sell Queen Category option in Protector");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",
		// productdetail.crossSellProtectorSizeField());
		CrossSellProtectorSizeField.click();
		log.info("Clicked on cross Sell Protector Size Field");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click()",
		// productdetail.crossSellQueenProtector78x60());
		CrossSellQueenProtector78x60.click();
		log.info("Click on one size option from dropdown");

		// ((JavascriptExecutor)driver).executeScript("arguments[0].click()",
		// productdetail.crossSellAddToCartQueenProtector78x60());
		CrossSellAddToCartQueenProtector78x60.click();
		log.info("Click on add to cart product button of Protector");

	}

	public void crossSellChangeMultipleOptionWhiteProtectorAddToCartButton() throws Exception {

		Actions move = new Actions(driver);
		CrossSellWhiteColorProtector.click();
		log.info("Clicked on cross Sell White color option in Protector");

		CrossSellGreyColorProtector.click();
		log.info("Clicked on cross Sell Gray color option in Protector");

		CrossSellProtectorCategoryField.click();
		log.info("Clicked on category field for Protector");

		CrossSellQueenCategoryProtector.click();
		log.info("Clicked on cross Sell Queen Category option in Protector");

		CrossSellProtectorSizeField.click();
		log.info("Clicked on cross Sell Protector Size Field");

		move.moveToElement(CrossSellQueenProtector78x60).build().perform();
		CrossSellQueenProtector78x60.click();
		log.info("Click on one size option from dropdown");

		CrossSellAddToCartQueenProtector78x60.click();
		log.info("Click on add to cart product button of Protector");

	}

	public void crossSellChangeMultipleOptionLuxeComforterAddToCartButton() throws Exception {

		CrossSellLuxeComforterCategoryField.click();
		log.info("Clicked on category field for Luxe Comforter");

		CrossSellLuxeComforterDoubleCategoryField.click();
		log.info("Clicked on Double category for Luxe Comforter");

		CrossSellLuxeComforterCategoryField.click();
		log.info("Clicked again on category field for Luxe Comforter");

		CrossSellLuxeComforterSingleCategoryField.click();
		log.info("Clicked on Single category for Luxe Comforter");

		CrossSellAddToCartButtonForSingleLuxeComforter.click();
		log.info("Click on add to cart product button of Single Luxe comforter");

	}

	public void crossSellDefaultQueenOriginalMattressAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForQueenOriginal78x60x6.click();
		log.info("Click on add to cart product button of Queen Original mattress");

	}

	public void crossSellDefaultQueenUltimaMattressAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForQueenUltima78x60x8.click();
		log.info("Click on add to cart product button of Queen Ultima mattress");

	}

	public void crossSellDefaultQueenHybridLatexMattressAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForQueenLatex78x60x6.click();
		// CrossSellAddToCartButtonForQueenLatex78x60x8.click();
		log.info("Click on add to cart product button of Queen Latex mattress");

	}

	public void crossSellChangeMultipleOptionUltimaMattressAddToCartButton() throws Exception {

		CrossSellUltimaMattressCategoryField.click();
		log.info("Clicked on category field for Ultima mattress");

		CrossSellUltimaMattressKingCategory.click();
		log.info("Clicked on king category for Ultima mattress");

		CrossSellUltimaMattressHeightField.click();
		log.info("Clicked on Height field for Ultima mattress");

		CrossSellUltimaMattressTenInchHeight.click();
		log.info("Clicked on Ten inch height from the dropdown");

		CrossSellUltimaMattressSizeField.click();
		log.info("Clicked on Size field");

		CrossSellUltimaMattressKing75x72x10.click();
		log.info("Clicked on one Size option from the dropdown field");

		CrossSellAddToCartUltimaMattressKing75x72x10.click();
		log.info("Clicked on Add to cart button of Ultima mattress product");

	}

	public void crossSellChangeMultipleOptionOriginalMattressAddToCartButton() throws Exception {

		CrossSellOriginalMattressCategoryField.click();
		log.info("Clicked on category field for Original mattress");

		CrossSellOriginalMattressKingCategory.click();
		log.info("Clicked on king category for Original mattress");

		CrossSellOriginalMattressHeightField.click();
		log.info("Clicked on Height field for Original mattress");

		CrossSellOriginalMattressTenInchHeightOption.click();
		log.info("Clicked on Ten inch height from the dropdown");

		CrossSellOriginalMattressSizeField.click();
		log.info("Clicked on Size field");

		CrossSellOriginalMattressKing75x72x10.click();
		log.info("Clicked on one Size option from the dropdown field");

		CrossSellAddToCartOriginalMattressKing75x72x10.click();
		log.info("Clicked on Add to cart button of Original mattress product");

	}

	public void crossSellChangeMultipleOptionLatexMattressAddToCartButton() throws Exception {

		CrossSellLatexMattressCategoryField.click();
		log.info("Clicked on category field for Latex mattress");

		CrossSellLatexMattressKingCategory.click();
		log.info("Clicked on king category for Latex mattress");

		CrossSellLatexMattressHeightField.click();
		log.info("Clicked on Height field for Latex mattress");

		CrossSellLatexMattressEightInchHeightOption.click();
		log.info("Clicked on Eight inch height from the dropdown");

		CrossSellLatexMattressSizeField.click();
		log.info("Clicked on Size field");

		CrossSellLatexMattressKing75x72x8.click();
		log.info("Clicked on one Size option from the dropdown field");

		CrossSellAddToCartLatexMattressKing75x72x8.click();
		log.info("Clicked on Add to cart button of Latex mattress product");

	}

	public void crossSellDefaultBabyHeadPillowAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForBabyHeadPillow.click();
		log.info("Clicked on cross Sell Add to cart button for Baby Head Pillow");

	}

	public void crossSellDefaultBabyComforterAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForBabyComforter.click();
		log.info("Clicked on cross Sell Add to cart button for Baby comforter");

	}

	public void crossSellDefaultBabyCribSheetAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForBabyCribSheet.click();
		log.info("Clicked on cross Sell Add to cart button for Baby Crib Fitted Sheet");

	}

	public void crossSellChangeMultipleOptionBabyCribSheetAddToCartButton() throws Exception {

		CrossSellBabyCribSheetIncrementQuantity.click();
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellBabyCribSheetIncrementQuantity());
		log.info("Clicked on plus icon and increment the Baby Crib sheet quantity to Two");

		CrossSellBabyCribSheetIncrementQuantity.click();
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellBabyCribSheetIncrementQuantity());
		log.info("Clicked on plus icon and increment the Baby Crib sheet quantity to Three");

		CrossSellBabyCribSheetDecreaseQuantity.click();
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].click();",productdetail.crossSellBabyCribSheetDecreaseQuantity());
		log.info("Clicked on minus icon and decrement the Baby Crib sheet quantity to Two");

		/*
		 * ((JavascriptExecutor) driver).executeScript("arguments[0].click();",
		 * productdetail.crossSellAddToCartButtonForBabyCribSheet()); log.
		 * info("Clicked on cross Sell Add to cart button for Baby Crib Fitted Sheet");
		 */

		CrossSellAddToCartButtonForBabyCribSheet.click();
		log.info("Clicked on cross Sell Add to cart button for Baby Crib Fitted Sheet");

	}

	public void crossSellDefaultBabyBolsterPillowAddToCartButton() throws Exception {

		CrossSellAddToCartButtonForBabyBolsterPillow.click();
		log.info("Clicked on cross Sell Add to cart button for Baby Bolster pillow");

	}

	public void crossSellChangeMultipleOptionCouplePillowAddToCartButton() throws Exception {

		CrossSellCouplePillowCategoryField.click();
		log.info("Clicked on couple pillow category field");

		CrossSellRightHandSideCouplePillowCategoryOption.click();
		log.info("Clicked on Right hand couple pillow option");

		CrossSellCouplePillowCategoryField.click();
		log.info("Clicked on couple pillow category field");

		CrossSellLeftHandSideCouplePillowCategoryOption.click();
		log.info("Clicked on Right hand couple pillow option");

		CrossSellCouplePillowCategoryField.click();
		log.info("Clicked on couple pillow category field");

		CrossSellRightHandSideCouplePillowCategoryOption.click();
		log.info("Clicked on Right hand couple pillow option");

		CrossSellCouplePillowIncrementQuantity.click();
		log.info("Clicked on Increment Quantity of couple pillow option");

		CrossSellCouplePillowIncrementQuantity.click();
		log.info("Clicked on Increment Quantity of couple pillow option");

		CrossSellCouplePillowDecreaseQuantity.click();
		log.info("Clicked on Decrease Quantity of couple pillow option");

		CrossSellAddToCartButtonForRightHandSideCouplePillow.click();
		log.info("Clicked on add to cart option for couple pillow");

	}

}
