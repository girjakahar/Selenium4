package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CuddlePillow {
	
	static RemoteWebDriver driver;
	
	 public CuddlePillow(RemoteWebDriver driver) throws Exception
	   {
         this.driver = driver; 
         PageFactory.initElements(driver, this);
       }
	 
		/*
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-GRBDPILWSET-S-50x19']")
		 * private WebElement CuddlePillowProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * cuddlePillowProductAddedInCart() { return CuddlePillowProductAddedInCart; }
		 */
	
	 
	    //Add to cart button
		@FindBy(xpath = "(//button[@data-productid='214595'])[2]")
	    private WebElement CuddlePillowAddToCartButton;
		
		// Webelement for different Pack size on product details page of Cloud Pillow
		public WebElement cuddlePillowAddToCartButton() {
			return CuddlePillowAddToCartButton;
		}
		
	public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
		    //WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
			cart.moveToElement(CuddlePillowAddToCartButton).click(CuddlePillowAddToCartButton).build().perform();
		}

}
