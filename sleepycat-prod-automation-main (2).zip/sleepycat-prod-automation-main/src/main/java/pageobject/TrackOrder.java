package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrackOrder {
	
	static RemoteWebDriver driver;

    public TrackOrder(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }

   //Xpath for order number field
    @FindBy(xpath = "//input[@id='orderid']")
    private WebElement OrderNumber;
    
   //Webelement for order number field
   public WebElement orderNumber() {
  		return OrderNumber;
  	}
   
   //Xpath for Submit Button 
   @FindBy(xpath = "//input[@id='tracksubmit']")
   private WebElement TrackOrderSubmitButton;
   
   //Webelement for Submit Button 
   public WebElement trackOrderSubmitButton() {
 		return TrackOrderSubmitButton;
 	}
   
   //Xpath for Order details not found info message on track order page
   @FindBy(xpath = "//div[@class='invalid-order-text']")
   private WebElement OrderDetailsNotFoundMessage;
   
   //Webelement for Order details not found info message on track order page
   public WebElement orderDetailsNotFoundMessage() {
 		return OrderDetailsNotFoundMessage;
 	}
   
   //Xpath for Try Again option on track order page
   @FindBy(xpath = "//div[@class='invalid-order']//a")
   private WebElement TryAgainOption;
   
   //Webelement for Try Again option on track order page
   public WebElement tryAgainOption() {
 		return TryAgainOption;
 	}
   
   //Xpath for Order Number on track order page
   @FindBy(xpath = "//div[@class='order-no']")
   private WebElement OrderNumberDetails;
   
   //Webelement for for Order Number on track order page
   public WebElement orderNumberDetails() {
 		return OrderNumberDetails;
 	}
   
   

}
