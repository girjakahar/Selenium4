package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SoftTouchMemoryFoamPillow {
	
	static RemoteWebDriver driver;
	
	 public SoftTouchMemoryFoamPillow(RemoteWebDriver driver) throws Exception
	   {
         this.driver = driver; 
         PageFactory.initElements(driver, this);
       }
	 
	//Xpath for Cloud pillow Standard,President Category option on product details page
	@FindBy(xpath = "//li[text()='President']")
    private WebElement PresidentCategory;
			
    @FindBy(xpath = "//li[text()='Standard']")
	private WebElement StandardCategory;
			
    // Webelement for Cloud pillow President Category option on product details page
	public WebElement presidentCategory() {
		return PresidentCategory;
	}
			
	public WebElement standardCategory() {
		return StandardCategory;
	}
	
	//Xpath for different Pack size on product details page of memory Pillow
	@FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='pillow-1']")
    private WebElement OnePillowPackSize;
			
    @FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='pillow-2']")
	private WebElement TwoPillowPackSize;
	    
    @FindBy(xpath = "//div[@class='attr attr_Pack ']//li[@data-value='pillow-4']")
    private WebElement FourPillowPackSize;
		
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement onePillowPackSize() {
		return OnePillowPackSize;
	}
		
	public WebElement twoPillowPackSize() {
		return TwoPillowPackSize;
	}
		
	public WebElement fourPillowPackSize() {
		return FourPillowPackSize;
	}
	 
	/*
	 * //Product added in cart XPath
	 * 
	 * @FindBy(xpath =
	 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PILLOW-S-26x16x4']")
	 * private WebElement MemoryFoamPillowProductAddedInCart;
	 * 
	 * // Webelement for Product added in cart XPath public WebElement
	 * memoryFoamPillowProductAddedInCart() { return
	 * MemoryFoamPillowProductAddedInCart; }
	 * 
	 * //Product added in cart XPath
	 * 
	 * @FindBy(xpath =
	 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILWSET4-P-28x18']")
	 * private WebElement MemoryFoamPillowSetOfFourProductAddedInCart;
	 * 
	 * // Webelement for Product added in cart XPath public WebElement
	 * memoryFoamPillowSetOfFourProductAddedInCart() { return
	 * MemoryFoamPillowSetOfFourProductAddedInCart; }
	 */
	 
	//Add to cart button
	@FindBy(xpath = "(//button[@data-productid='98749'])[2]")
    private WebElement SoftTouchPillowAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement softTouchPillowAddToCartButton() {
		return SoftTouchPillowAddToCartButton;
	}
	
	public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
	        //WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
			cart.moveToElement(SoftTouchPillowAddToCartButton).click(SoftTouchPillowAddToCartButton).build().perform();
		}

}
