package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllBundleProductDetailsPage {
	
	static RemoteWebDriver driver;

    public AllBundleProductDetailsPage(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }
    
  //Xpath for King Variation Original Mattress dropdown field
    @FindBy(xpath = "//li[@data-sizenumeric='72 x 72 x 8']")
    private WebElement KingOriginalMattressBundle72x72x8;
    
    @FindBy(xpath = "//li[@data-sizenumeric='75 x 72 x 8']")
    private WebElement KingOriginalMattressBundle75x72x8;
    
    @FindBy(xpath = "//li[@data-sizenumeric='78 x 72 x 8']")
    private WebElement KingOriginalMattressBundle78x72x8;
       
    
    //Webelement for King Variation Original Mattress dropdown field
    public WebElement kingOriginalMattressBundle72x72x8() {
  		return KingOriginalMattressBundle72x72x8;
  	}
    
    public WebElement kingOriginalMattressBundle75x72x8() {
  		return KingOriginalMattressBundle75x72x8;
  	}
    
    public WebElement kingOriginalMattressBundle78x72x8() {
  		return KingOriginalMattressBundle78x72x8;
  	}
    
    //Xpath for Queen Variation Original Mattress dropdown field
    @FindBy(xpath = "//li[@data-sizenumeric='72 x 60 x 8']")
    private WebElement QueenOriginalMattressBundle72x60x8;
    
    @FindBy(xpath = "//li[@data-sizenumeric='78 x 60 x 8']")
    private WebElement QueenOriginalMattressBundle78x60x8;
    
    @FindBy(xpath = "//li[@data-sizenumeric='75 x 66 x 8']")
    private WebElement QueenOriginalMattressBundle75x66x8;
       
    
    //Webelement for Queen Variation Original Mattress dropdown field
    public WebElement queenOriginalMattressBundle72x60x8() {
  		return QueenOriginalMattressBundle72x60x8;
  	}
    
    public WebElement queenOriginalMattressBundle78x60x8() {
  		return QueenOriginalMattressBundle78x60x8;
  	}
    
    public WebElement queenOriginalMattressBundle75x66x8() {
  		return QueenOriginalMattressBundle75x66x8;
  	}
    
   //Xpath for color Variation of Comforter field
    @FindBy(xpath = "(//li[@data-value='white'])")
    private WebElement BundleComforterWhiteColor;
    
    @FindBy(xpath = "(//li[@data-value='pink'])")
    private WebElement BundleComforterPinkColor;
    
    @FindBy(xpath = "(//li[@data-value='coffee'])")
    private WebElement BundleComforterCoffeeColor;
    
    @FindBy(xpath = "(//li[@data-value='lime'])")
    private WebElement BundleComforterLimeColor;
    
    @FindBy(xpath = "(//li[@data-value='blue'])")
    private WebElement BundleComforterBlueColor;
       
    
    //Webelement for color Variation of Comforter field
    public WebElement bundleComforterWhiteColor() {
  		return BundleComforterWhiteColor;
  	}
    
    public WebElement bundleComforterPinkColor() {
  		return BundleComforterPinkColor;
  	}
    
    public WebElement bundleComforterCoffeeColor() {
  		return BundleComforterCoffeeColor;
  	}
    
    public WebElement bundleComforterLimeColor() {
  		return BundleComforterLimeColor;
  	}
    
    public WebElement bundleComforterBlueColor() {
  		return BundleComforterBlueColor;
  	}
   
    
    //Xpath for Single Variation Original Mattress dropdown field
    @FindBy(xpath = "//li[@data-sizenumeric='72 x 36 x 6']")
    private WebElement SingleOriginalMattressBundle72x36x6;
    
    @FindBy(xpath = "//li[@data-sizenumeric='75 x 36 x 6']")
    private WebElement SingleOriginalMattressBundle75x36x6;
    
    @FindBy(xpath = "//li[@data-sizenumeric='78 x 36 x 6']")
    private WebElement SingleOriginalMattressBundle78x36x6;
       
    
    //Webelement for Single Variation Original Mattress dropdown field
    public WebElement singleOriginalMattressBundle72x36x6() {
  		return SingleOriginalMattressBundle72x36x6;
  	}
    
    public WebElement singleOriginalMattressBundle75x36x6() {
  		return SingleOriginalMattressBundle75x36x6;
  	}
    
    public WebElement singleOriginalMattressBundle78x36x6() {
  		return SingleOriginalMattressBundle78x36x6;
  	}
    
    
    //Xpath for Baby Mattress dropdown variations 
    @FindBy(xpath = "//li[@data-sizenumeric='48 x 24 x 4']")
    private WebElement BabyMattressBundle48x24x4;
    
    @FindBy(xpath = "//li[@data-sizenumeric='52 x 28 x 4']")
    private WebElement BabyMattressBundle52x28x4;
 
    //Webelement for Baby Mattress dropdown variations 
    public WebElement babyMattressBundle48x24x4() {
  		return BabyMattressBundle48x24x4;
  	}
    
    public WebElement babyMattressBundle52x28x4() {
  		return BabyMattressBundle52x28x4;
  	}
    

}
