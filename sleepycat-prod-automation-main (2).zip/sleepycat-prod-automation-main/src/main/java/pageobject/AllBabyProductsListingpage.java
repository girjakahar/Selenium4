package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllBabyProductsListingpage {
	
	static RemoteWebDriver driver;
	
	 public AllBabyProductsListingpage(RemoteWebDriver driver) throws Exception
	   {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
     }
	 
	   // Xpath for All Baby products learn more section
	   @FindBy(xpath = "(//div[@data-producttype='baby_headpillow']//a[text()='SHOP NOW'])")
	   private WebElement BabyHeadPillowShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='baby_bolsterpillow']//a[text()='SHOP NOW'])")
	   private WebElement BabyBolsterPillowShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='baby_comforter']//a[text()='SHOP NOW'])")
	   private WebElement BabyComforterShopNow;
		
	   @FindBy(xpath = "(//div[@data-producttype='baby_cribsheet']//a[text()='SHOP NOW'])")
	   private WebElement BabyCribSheetShopNow;
	   
	   @FindBy(xpath = "(//div[@data-producttype='baby']//a[text()='SHOP NOW'])")
	   private WebElement BabyMattressShopNow;
	   
		
		// Webelement for All Baby products learn more section
		public WebElement babyHeadPillowShopNow() {
			return BabyHeadPillowShopNow;
		}

		public WebElement babyBolsterPillowShopNow() {
			return BabyBolsterPillowShopNow;
		}

		public WebElement babyComforterShopNow() {
			return BabyComforterShopNow;
		}

		public WebElement babyCribSheetShopNow() {
			return BabyCribSheetShopNow;
		}
		
		public WebElement babyMattressShopNow() {
			return BabyMattressShopNow;
		}

}
