package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LatexMattress {
	
	static RemoteWebDriver driver;
	
	 public LatexMattress(RemoteWebDriver driver) throws Exception
	   {
        this.driver = driver; 
        PageFactory.initElements(driver, this);
       }
	 
	//Latex mattress size section on product details page
	// Dropdown size options in latex mattress and when category is King
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-K-72x72x6']")
    private WebElement KingLatex72x72x6;
	
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-K-75x72x6']")
    private WebElement KingLatex75x72x6;
	
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-K-78x72x6']")
    private WebElement KingLatex78x72x6;
	
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-Q-78x60x6']")
    private WebElement QueenLatex78x60x6;
	
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-S-78x36x6']")
	private WebElement SingleLatex78x36x6;
    
	// Webelement when Inch,cm or feet dimension is selected in latex mattress and when category is king
	public WebElement kingLatex72x72x6() {
		return KingLatex72x72x6;
	}

	public WebElement kingLatex75x72x6() {
		return KingLatex75x72x6;
	}
				
	public WebElement kingLatex78x72x6() {
		return KingLatex78x72x6;
	}
	
	public WebElement queenLatex78x60x6() {
		return QueenLatex78x60x6;
	}
	
	public WebElement SingleLatex78x36x6() {
		return SingleLatex78x36x6;
	}
		
		
	// Dropdown options in latex mattress and when category is Single
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-S-72x36x6']")
    private WebElement SingleLatex72x36x6;
	
	@FindBy(xpath = "//li[@data-sku='SC-HYB-LATEX-S-75x36x6']")
    private WebElement SingleLatex75x36x6;				
   //Above xpath can also be used when cm or feet is selected as dimension for 190 x 91 x 17 cm and 6.25' x 3' x 0.58' feet
		

   // Webelement when Inch,cm or feet dimension is selected in latex mattress and when category is Single
   public WebElement singleLatex72x36x6() {
		return SingleLatex72x36x6;
	}
   public WebElement singleLatex75x36x6() {
		return SingleLatex75x36x6;
	}
	
	//Add to cart button
	@FindBy(xpath = "(//button[@data-productid='89654'])[2]")
    private WebElement LatexMattressAddToCartButton;
	
	// Webelement for different Pack size on product details page of Cloud Pillow
	public WebElement latexMattressAddToCartButton() {
		return LatexMattressAddToCartButton;
	}
	
	public void addToCart() {
	    //WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
		cart.moveToElement(LatexMattressAddToCartButton).click(LatexMattressAddToCartButton).build().perform();
	}
		
	 
	 
}
