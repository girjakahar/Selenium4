package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OhayoBed {
	
	static RemoteWebDriver driver;
	
	 public OhayoBed(RemoteWebDriver driver) throws Exception
	 {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
     }
	 
		/*
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OHAYOBED-Q-84x65x13']")
		 * private WebElement OhayoBedQueenCategoryProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * ohayoBedQueenCategoryProductAddedInCart() { return
		 * OhayoBedQueenCategoryProductAddedInCart; }
		 * 
		 * //Product added in cart XPath
		 * 
		 * @FindBy(xpath =
		 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OHAYOBED-K-84x77x13']")
		 * private WebElement OhayoBedKingCategoryProductAddedInCart;
		 * 
		 * // Webelement for Product added in cart XPath public WebElement
		 * ohayoBedKingCategoryProductAddedInCart() { return
		 * OhayoBedKingCategoryProductAddedInCart; }
		 */
	 
	    //Add to cart button
		@FindBy(xpath = "(//button[@data-productid='671178'])[2]")
	    private WebElement OhayoBedAddToCartButton;
		
		// Webelement for different Pack size on product details page of Cloud Pillow
		public WebElement ohayoBedAddToCartButton() {
			return OhayoBedAddToCartButton;
		}
		
	 public void addToCart() {
			//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));//div[@class='productDirectPurchase hidden_form plus']//button[@type='button'][normalize-space()='Add To Cart']
	        //WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
			//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
	        Actions cart = new Actions(driver);
			cart.moveToElement(OhayoBedAddToCartButton).click(OhayoBedAddToCartButton).build().perform();
		}

}
