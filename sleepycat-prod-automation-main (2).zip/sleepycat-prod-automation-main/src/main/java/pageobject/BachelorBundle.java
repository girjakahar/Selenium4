package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BachelorBundle {
	
	static RemoteWebDriver driver;

    public BachelorBundle(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }
    
    
    //Xpath for Category field and its values
    @FindBy(xpath = "(//div[@class='product_upper_variations_bundle']//div[@class='customselectedData'])")
    private WebElement SelectSizeDropdownField;
    
    //Webelement for Category field and its values   
    public WebElement selectSizeDropdownField() {
  		return SelectSizeDropdownField;
  	}
    
    //Add to cart button
  	@FindBy(xpath = "(//button[@data-productid='2193915'])[2]")
      private WebElement CampusBundleAddToCartButton;
  	
  	//Webelement for Add to cart button
  	public WebElement campusBundleAddToCartButton() {
  		return CampusBundleAddToCartButton;
  	}
  	
  	public void addToCart() {
  		//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
  		//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
  		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
  		Actions cart = new Actions(driver);
  		cart.moveToElement(CampusBundleAddToCartButton).click(CampusBundleAddToCartButton).build().perform();
  	}

}
