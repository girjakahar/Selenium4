package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LuxeComforter {
	
	static RemoteWebDriver driver;

	public LuxeComforter(RemoteWebDriver driver) throws Exception
    {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
    }
	
		
		//Add to cart button
	    @FindBy(xpath = "(//button[@data-productid='2138818'])[2]")
	    private WebElement LuxeComforterAddToCartButton;
				
		// Webelement for 
		public WebElement luxeComforterAddToCartButton() {
			return LuxeComforterAddToCartButton;
		}
		 
		 public void addToCart() {
				//List<AndroidElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
				//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
				//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
			    Actions cart = new Actions(driver);
				cart.moveToElement(LuxeComforterAddToCartButton).click(LuxeComforterAddToCartButton).build().perform();
			}

}
