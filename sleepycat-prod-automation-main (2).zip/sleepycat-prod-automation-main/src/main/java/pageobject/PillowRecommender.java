package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PillowRecommender {
	
	static RemoteWebDriver driver;

	   public PillowRecommender(RemoteWebDriver driver) throws Exception
	    {
	      this.driver = driver; 
	      PageFactory.initElements(driver, this);
	    }
		
	   // Xpath for First question options of Pillow recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-184-0']")
	   private WebElement BelowTwentyNine;
		
	   @FindBy(xpath = "//label[@id='nf-label-field-184-1']")
	   private WebElement ProAdultThirtyToFoutyFive;
		
	   @FindBy(xpath = "//label[@id='nf-label-field-184-2']")
	   private WebElement StillYoungFourtySixToSixty ;
		
	   @FindBy(xpath = "//label[@id='nf-label-field-184-3']")
	   private WebElement RetiredAndChillingSixtyAndAbove;
	   
	   @FindBy(xpath = "//button[@data-field='nf-field-184']")
	   private WebElement FirstNextbutton;
		
		// Webelement for First question options of Pillow recommender
		public WebElement belowTwentyNine() {
			return BelowTwentyNine;
		}

		public WebElement proAdultThirtyToFoutyFive() {
			return ProAdultThirtyToFoutyFive;
		}
		
		public WebElement stillYoungFourtySixToSixty() {
			return StillYoungFourtySixToSixty;
		}

		public WebElement retiredAndChillingSixtyAndAbove() {
			return RetiredAndChillingSixtyAndAbove;
		}
		
		public WebElement firstNextbutton() {
			return FirstNextbutton;
		}
		
		   //Xpath for Second question options of Pillow recommender
		   @FindBy(xpath = "//label[@id='nf-label-field-185-0']")
		   private WebElement   DangerouslyLowBelowFourHoursOption;
				
		   @FindBy(xpath = "//label[@id='nf-label-field-185-1']")
		   private WebElement   JustAboutEnoughBetweenFourToSixHoursOption;
				
		   @FindBy(xpath = "//label[@id='nf-label-field-185-2']")
		   private WebElement  IdealSixToEightHoursOption;
				
		   @FindBy(xpath = "//label[@id='nf-label-field-185-3']")
		   private WebElement   ABitMuchOverEightHoursOption;
			   
		   @FindBy(xpath = "//button[@data-field='nf-field-185'][2]")
		   private WebElement SecondNextbutton;
		   
		   @FindBy(xpath = "//button[@data-field='nf-field-185']")
		   private WebElement SecondQuestionBackButton;
				
			// Webelement for Second question options of Pillow recommender
			public WebElement dangerouslyLowBelowFourHoursOption() {
				return DangerouslyLowBelowFourHoursOption;
			}

			public WebElement justAboutEnoughBetweenFourToSixHoursOption() {
				return JustAboutEnoughBetweenFourToSixHoursOption;
			}
				
			public WebElement idealSixToEightHoursOption() {
				return IdealSixToEightHoursOption;
			}

			public WebElement aBitMuchOverEightHoursOption() {
				return ABitMuchOverEightHoursOption;
			}
				
			public WebElement secondNextbutton() {
				return SecondNextbutton;
			}
			
			public WebElement secondQuestionBackButton() {
				return SecondQuestionBackButton;
			}
			
			
			   // Xpath for Third question options of Pillow recommender
			   @FindBy(xpath = "//label[@id='nf-label-field-186-0']")
			   private WebElement   BackOption;
						
			   @FindBy(xpath = "//label[@id='nf-label-field-186-1']")
			   private WebElement   SideOption;
						
			   @FindBy(xpath = "//label[@id='nf-label-field-186-2']")
			   private WebElement   StomachOption;
						
			   @FindBy(xpath = "//label[@id='nf-label-field-186-3']")
			   private WebElement   ItsDifferentEverydayOption;
					   
			   @FindBy(xpath = "//button[@data-field='nf-field-186'][2]")
			   private WebElement ThirdNextbuttonOption;
			   
			   @FindBy(xpath = "//button[@data-field='nf-field-186']")
			   private WebElement ThirdQuestionBackButton;
						
			   // Webelement for Third question options of Pillow recommender
				public WebElement backOption() {
					return BackOption;
				}

				public WebElement sideOption() {
					return SideOption;
				}
						
				public WebElement stomachOption() {
					return StomachOption;
				}

				public WebElement itsDifferentEverydayOption() {
					return ItsDifferentEverydayOption;
				}
										
				public WebElement thirdQuestionBackButton() {
					return ThirdQuestionBackButton;
				}
						
				public WebElement thirdNextbuttonOption() {
					return ThirdNextbuttonOption;
				}
				
				   //Xpath for Fourth question options of Pillow recommender
				   @FindBy(xpath = "//label[@id='nf-label-field-187-0']")
				   private WebElement   ComfortedToTheCoreOption;
								
				   @FindBy(xpath = "//label[@id='nf-label-field-187-1']")
				   private WebElement   SupportedAroundTheHeadAndNeckOption;
								
				   @FindBy(xpath = "//label[@id='nf-label-field-187-2']")
				   private WebElement   CoolAndComfyMinusTheHeatOption;
								
				   @FindBy(xpath = "//label[@id='nf-label-field-187-3']")
				   private WebElement   CuddledLikeinAHugOption;
				   
				   @FindBy(xpath = "//label[@id='nf-label-field-187-4']")
				   private WebElement   LappingInLuxuryOption;
								
				   @FindBy(xpath = "//label[@id='nf-label-field-187-5']")
				   private WebElement  AllOfTheAboveOption;
							   
				   @FindBy(xpath = "//button[@data-field='nf-field-187']")
				   private WebElement FourthQuestionBackButton;
							   
				   @FindBy(xpath = "//button[@data-field='nf-field-187'][2]")
				   private WebElement FourthNextbutton;
								
				   // Webelement for Fourth question options of Pillow recommender
				   public WebElement comfortedToTheCoreOption() {
						return ComfortedToTheCoreOption;
					}

				   public WebElement supportedAroundTheHeadAndNeckOption() {
						return SupportedAroundTheHeadAndNeckOption;
					}
								
			       public WebElement coolAndComfyMinusTheHeatOption() {
						return CoolAndComfyMinusTheHeatOption;
					}

			       public WebElement cuddledLikeinAHugOption() {
						return CuddledLikeinAHugOption;
					}
			       
			       public WebElement lappingInLuxuryOption() {
						return LappingInLuxuryOption;
					}

			       public WebElement allOfTheAboveOption() {
						return AllOfTheAboveOption;
					}
								
			       public WebElement fourthQuestionBackButton() {
						return FourthQuestionBackButton;
					}
								
			       public WebElement fourthNextbutton() {
						return FourthNextbutton;
					}
			       
			       //Xpath for Fifth question options of Pillow recommender
				   @FindBy(xpath = "//label[@id='nf-label-field-188-0']")
				   private WebElement  SuperSoftOption;
								
				   @FindBy(xpath = "//label[@id='nf-label-field-188-1']")
				   private WebElement  MediumSoftOption;
								
				   @FindBy(xpath = "//label[@id='nf-label-field-188-2']")
				   private WebElement   MediumFirmOption;
				   
				   @FindBy(xpath = "//label[@id='nf-label-field-188-3']")
				   private WebElement   FirmOption;
				   
				   @FindBy(xpath = "//input[@id='nf-field-189']")
				   private WebElement Submit;
								
				   // Webelement for Fifth question options of Pillow recommender
				   public WebElement superSoftOption() {
						return SuperSoftOption;
					}

				   public WebElement mediumSoftOption() {
						return MediumSoftOption;
					}
				   
				   public WebElement mediumFirmOption() {
						return MediumFirmOption;
					}
								
			       public WebElement firmOption() {
						return FirmOption;
					}

			       public WebElement submit() {
						return Submit;
				   }
			       
			       //Xpath for mattress recommender result page
			       @FindBy(xpath = "//input[@id='recommenderEmailInput']")
				   private WebElement  EnterEmailField ;
							   
			       @FindBy(xpath = "//button[@id='saveEmail']")
				   private WebElement  SignUpButton ;
			       
			       @FindBy(xpath = "//p[@id='skipEmail']")
				   private WebElement  SkipEmailOption ;
								
				   // Webelement for mattress recommender result page
				   public WebElement enterEmailField() {
						return EnterEmailField;
					}

				   public WebElement signUpButton() {
						return SignUpButton;
					}
				   
				   public WebElement skipEmailOption() {
						return SkipEmailOption;
					}
				   
				    //Add to cart button for different mattress product on mattress recommender result page
					@FindBy(xpath = "//span[@data-product='2096307']")
				    private WebElement HybridPillowAddToCartButton;
					
					@FindBy(xpath = "//span[@data-product='214583']")
				    private WebElement CloudPillowAddToCartButton;
					
					@FindBy(xpath = "//span[@data-product='98749']")
				    private WebElement SoftTouchMemoryFoamPillowAddToCartButton;
					
					@FindBy(xpath = "//span[@data-product='2096528']")
				    private WebElement CoolTecMemoryFoamPillowAddToCartButton;
					
					// Webelement for Add to cart button for different mattress product on mattress recommender result page
					public WebElement hybridPillowAddToCartButton() {
						return HybridPillowAddToCartButton;
					}
					
					public WebElement cloudPillowAddToCartButton() {
						return CloudPillowAddToCartButton;
					}
					
					public WebElement softTouchMemoryFoamPillowAddToCartButton() {
						return SoftTouchMemoryFoamPillowAddToCartButton;
					}
					
					public WebElement coolTecMemoryFoamPillowAddToCartButton() {
						return CoolTecMemoryFoamPillowAddToCartButton;
					}
					
					   // Xpath for Item Added To Cart Message
					   @FindBy(xpath = "//span[text()='Item added to cart']")
					   private WebElement  ItemAddedToCartMessage ;
									
					   // Webelement for Item Added To Cart Message
					   public WebElement itemAddedToCartMessage() {
							return ItemAddedToCartMessage;
						}

}
