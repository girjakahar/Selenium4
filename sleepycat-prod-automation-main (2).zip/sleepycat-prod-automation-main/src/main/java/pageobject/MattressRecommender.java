package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MattressRecommender {
	
	static RemoteWebDriver driver;

	   public MattressRecommender(RemoteWebDriver driver) throws Exception
	    {
	      this.driver = driver; 
	      PageFactory.initElements(driver, this);
	    }
		
	   // Xpath for First question options of mattress recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-176-0']")
	   private WebElement BelowTwentyNine;
		
	   @FindBy(xpath = "//label[@id='nf-label-field-176-1']")
	   private WebElement BetweenThirtyAndFourtyFive;
		
	   @FindBy(xpath = "//label[@id='nf-label-field-176-2']")
	   private WebElement BetweenFourtySixAndSixty;
		
	   @FindBy(xpath = "//label[@id='nf-label-field-176-3']")
	   private WebElement SixtyAndAbove;
	   
	   @FindBy(xpath = "//button[@data-field='nf-field-176']")
	   private WebElement FirstNextbutton;
		
		// Webelement for First question options of mattress recommender
		public WebElement belowTwentyNine() {
			return BelowTwentyNine;
		}

		public WebElement betweenThirtyAndFourtyFive() {
			return BetweenThirtyAndFourtyFive;
		}
		
		public WebElement betweenFourtySixAndSixty() {
			return BetweenFourtySixAndSixty;
		}

		public WebElement sixtyAndAbove() {
			return SixtyAndAbove;
		}
		
		public WebElement firstNextbutton() {
			return FirstNextbutton;
		}
		
		
		// Xpath for Second question options of mattress recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-177-0']")
	   private WebElement  WellknownfoamOption;
			
	   @FindBy(xpath = "//label[@id='nf-label-field-177-1']")
	   private WebElement  GoodolCoirOrCottonOption;
			
	   @FindBy(xpath = "//label[@id='nf-label-field-177-2']")
	   private WebElement  TrustySpringOption;
			
	   @FindBy(xpath = "//label[@id='nf-label-field-177-3']")
	   private WebElement  NewAgeMemoryFoamOption;
		   
	   @FindBy(xpath = "//button[@data-field='nf-field-177'][2]")
	   private WebElement SecondNextbutton;
	   
	   @FindBy(xpath = "//button[@data-field='nf-field-177']")
	   private WebElement SecondQuestionBackButton;
			
		// Webelement for Second question options of mattress recommender
		public WebElement wellknownfoamOption() {
			return WellknownfoamOption;
		}

		public WebElement goodolCoirOrCottonOption() {
			return GoodolCoirOrCottonOption;
		}
			
		public WebElement trustySpringOption() {
			return TrustySpringOption;
		}

		public WebElement newAgeMemoryFoamOption() {
			return NewAgeMemoryFoamOption;
		}
			
		public WebElement secondNextbutton() {
			return SecondNextbutton;
		}
		
		public WebElement secondQuestionBackButton() {
			return SecondQuestionBackButton;
		}
		
		
		// Xpath for Third question options of mattress recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-178-0']")
	   private WebElement  AchesAndPainsOption;
				
	   @FindBy(xpath = "//label[@id='nf-label-field-178-1']")
	   private WebElement  NightSweatsOption;
				
	   @FindBy(xpath = "//label[@id='nf-label-field-178-2']")
	   private WebElement  InterruptedSleepOption;
				
	   @FindBy(xpath = "//label[@id='nf-label-field-178-3']")
	   private WebElement  OverweightOption;
			   
	   @FindBy(xpath = "//label[@id='nf-label-field-178-4']")
	   private WebElement  SomethingElseOption;
			   
	   @FindBy(xpath = "//button[@data-field='nf-field-178'][2]")
	   private WebElement ThirdNextbuttonOption;
	   
	   @FindBy(xpath = "//button[@data-field='nf-field-178']")
	   private WebElement ThirdQuestionBackButton;
				
	   // Webelement for Third question options of mattress recommender
		public WebElement achesAndPainsOption() {
			return AchesAndPainsOption;
		}

		public WebElement nightSweatsOption() {
			return NightSweatsOption;
		}
				
		public WebElement interruptedSleepOption() {
			return InterruptedSleepOption;
		}

		public WebElement overweightOption() {
			return OverweightOption;
		}
				
		public WebElement somethingElseOption() {
			return SomethingElseOption;
		}
			
		public WebElement thirdQuestionBackButton() {
			return ThirdQuestionBackButton;
		}
				
		public WebElement thirdNextbuttonOption() {
			return ThirdNextbuttonOption;
		}
		
	   // Xpath for Fourth question options of mattress recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-179-0']")
	   private WebElement  OnTheSideOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-179-1']")
	   private WebElement  OnTheBackOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-179-2']")
	   private WebElement  OnTheTummyOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-179-3']")
	   private WebElement  KeepsChangingOption;
				   
	   @FindBy(xpath = "//button[@data-field='nf-field-179']")
	   private WebElement FourthQuestionBackButton;
				   
	   @FindBy(xpath = "//button[@data-field='nf-field-179'][2]")
	   private WebElement FourthNextbutton;
					
	   // Webelement for Fourth question options of mattress recommender
	   public WebElement onTheSideOption() {
			return OnTheSideOption;
		}

	   public WebElement onTheBackOption() {
			return OnTheBackOption;
		}
					
       public WebElement onTheTummyOption() {
			return OnTheTummyOption;
		}

       public WebElement keepsChangingOption() {
			return KeepsChangingOption;
		}
					
       public WebElement fourthQuestionBackButton() {
			return FourthQuestionBackButton;
		}
					
       public WebElement fourthNextbutton() {
			return FourthNextbutton;
		}
       
       
      // Xpath for Fifth question options of mattress recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-180-0']")
	   private WebElement  CoolAndRefreshingOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-180-1']")
	   private WebElement  PlushOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-180-2']")
	   private WebElement   BouncyOption ;
	   
	   @FindBy(xpath = "//label[@id='nf-label-field-180-3']")
	   private WebElement  ComfortAndSupportOption;
	   
	   @FindBy(xpath = "//button[@data-field='nf-field-180']")
	   private WebElement FifthQuestionBackButton;
				   
	   @FindBy(xpath = "//button[@data-field='nf-field-180'][2]")
	   private WebElement FifthNextbuttonOption;
					
	   // Webelement for Fifth question options of mattress recommender
	   public WebElement coolAndRefreshingOption() {
			return CoolAndRefreshingOption;
		}

	   public WebElement plushOption() {
			return PlushOption;
		}
					
       public WebElement bouncyOption() {
			return BouncyOption;
		}

       public WebElement comfortAndSupportOption() {
			return ComfortAndSupportOption;
	   }
       
       public WebElement fifthQuestionBackButton() {
			return FifthQuestionBackButton;
		}

      public WebElement fifthNextbuttonOption() {
			return FifthNextbuttonOption;
	   }
       
       
      // Xpath for Sixth question options of mattress recommender
	   @FindBy(xpath = "//label[@id='nf-label-field-181-0']")
	   private WebElement  SoftOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-181-1']")
	   private WebElement  MediumSoftOption;
					
	   @FindBy(xpath = "//label[@id='nf-label-field-181-2']")
	   private WebElement   FirmOption;
	   
	   @FindBy(xpath = "//input[@id='nf-field-182']")
	   private WebElement Submit;
					
	   // Webelement for Third question options of mattress recommender
	   public WebElement softOption() {
			return SoftOption;
		}

	   public WebElement mediumSoftOption() {
			return MediumSoftOption;
		}
					
       public WebElement firmOption() {
			return FirmOption;
		}

       public WebElement submit() {
			return Submit;
	   }
       
       //Xpath for mattress recommender result page
       @FindBy(xpath = "//input[@id='recommenderEmailInput']")
	   private WebElement  EnterEmailField ;
				   
       @FindBy(xpath = "//button[@id='saveEmail']")
	   private WebElement  SignUpButton ;
       
       @FindBy(xpath = "//p[@id='skipEmail']")
	   private WebElement  SkipEmailOption ;
					
	   // Webelement for mattress recommender result page
	   public WebElement enterEmailField() {
			return EnterEmailField;
		}

	   public WebElement signUpButton() {
			return SignUpButton;
		}
	   
	   public WebElement skipEmailOption() {
			return SkipEmailOption;
		}
	   
	   
	   //Xpath for different mattress suggestion result for mattress recommender
       @FindBy(xpath = "//span[text()='Plus Mattress']")
	   private WebElement  PlusMattressSuggestion ;
				   
       @FindBy(xpath = "//span[text()='Original Mattress']")
	   private WebElement  OriginalMattressSuggestion ;
       
       @FindBy(xpath = "//span[text()='Latex Mattress']")
	   private WebElement  LatexMattressSuggestion ;
					
	   // Webelement for Third question options of mattress recommender
	   public WebElement plusMattressSuggestion() {
			return PlusMattressSuggestion;
		}

	   public WebElement originalMattressSuggestion() {
			return OriginalMattressSuggestion;
		}
	   
	   public WebElement latexMattressSuggestion() {
			return LatexMattressSuggestion;
		}
	   
	   // Xpath for retry link on Mattress recommender link
	   @FindBy(xpath = "//a[@class='refresh']")
	   private WebElement  RetryLink ;
					
	   // Webelement for retry link on Mattress recommender link
	   public WebElement retryLink() {
			return RetryLink;
		}
	   
	    //Add to cart button for different mattress product on mattress recommender result page
		@FindBy(xpath = "//span[@data-product='89654']")
	    private WebElement LatexMattressAddToCartButton;
		
		@FindBy(xpath = "//span[@data-product='629264']")
	    private WebElement UltimaMattressAddToCartButton;
		
		@FindBy(xpath = "//span[@data-product='629227']")
	    private WebElement OriginalMattressAddToCartButton;
		
		// Webelement for Add to cart button for different mattress product on mattress recommender result page
		public WebElement latexMattressAddToCartButton() {
			return LatexMattressAddToCartButton;
		}
		
		public WebElement ultimaMattressAddToCartButton() {
			return UltimaMattressAddToCartButton;
		}
		
		public WebElement originalMattressAddToCartButton() {
			return OriginalMattressAddToCartButton;
		}
		
		   // Xpath for Item Added To Cart Message
		   @FindBy(xpath = "//span[text()='Item added to cart']")
		   private WebElement  ItemAddedToCartMessage ;
						
		   // Webelement for Item Added To Cart Message
		   public WebElement itemAddedToCartMessage() {
				return ItemAddedToCartMessage;
			}
	   
	   



}
