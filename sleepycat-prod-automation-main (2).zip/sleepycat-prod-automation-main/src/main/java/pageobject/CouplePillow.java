package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CouplePillow {
	
	static RemoteWebDriver driver;
	
	 public CouplePillow(RemoteWebDriver driver) throws Exception
	   {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
     }
	 
	//Xpath for Category option on product details page
			@FindBy(xpath = "//li[text()='Left Hand']")
		    private WebElement LeftHandOption;
				
		    @FindBy(xpath = "//li[text()='Right Hand']")
			private WebElement RightHandOption;
				
		    // Webelement for Category option on product details page
			public WebElement leftHandOption() {
				return LeftHandOption;
			}
				
			public WebElement rightHandOption() {
				return RightHandOption;
			}
			
			 
			//Add to cart button
			@FindBy(xpath = "//button[@data-productid='2492616']")
		    private WebElement CouplePillowAddToCartButton;
			
			// Webelement for Add to cart button of Couple pillow
			public WebElement couplePillowAddToCartButton() {
				return CouplePillowAddToCartButton;
			}
			 
			public void addToCart() {
					//List<AndroidElement> add = driver.findElements(By.xpath("//button[@class='single_add_to_cart_button btn-block alt']"));
					//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
					//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
					Actions cart = new Actions(driver);
					cart.moveToElement(CouplePillowAddToCartButton).click(CouplePillowAddToCartButton).build().perform();
				}

}
