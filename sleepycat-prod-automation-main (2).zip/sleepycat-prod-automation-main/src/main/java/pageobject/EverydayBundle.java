package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EverydayBundle {
	
	static RemoteWebDriver driver;

    public EverydayBundle(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }
    
    
    //Xpath for Category field and its values
    @FindBy(xpath = "(//div[@class='product_upper_variations_bundle']//div[@class='customselectedData'])[1]")
    private WebElement MainCategoryDropdownField;
    
    @FindBy(xpath = "(//div[@class='product_upper_variations_bundle']//div[@class='customselectedData'])[2]")
    private WebElement SelectSizeDropdownField;
    
    @FindBy(xpath = "(//li[@data-value='King'])")
    private WebElement KingCategoryDropdownField;
    
    @FindBy(xpath = "(//li[@data-value='Queen'])")
    private WebElement QueenCategoryDropdownField;
       
    
    //Webelement for Category field and its values
    public WebElement mainCategoryDropdownField() {
  		return MainCategoryDropdownField;
  	}
    
    public WebElement selectSizeDropdownField() {
  		return SelectSizeDropdownField;
  	}
    
    public WebElement kingCategoryDropdownField() {
  		return KingCategoryDropdownField;
  	}
    
    public WebElement queenCategoryDropdownField() {
  		return QueenCategoryDropdownField;
  	}
    
    
    //Add to cart button
  	@FindBy(xpath = "(//button[@data-productid='2195992'])[2]")
      private WebElement EveryDayBundleAddToCartButton;
  	
  	// Webelement for Add to cart button
  	public WebElement everyDayBundleAddToCartButton() {
  		return EveryDayBundleAddToCartButton;
  	}
  	
  	public void addToCart() {
  		//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
  		//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
  		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
  		Actions cart = new Actions(driver);
  		cart.moveToElement(EveryDayBundleAddToCartButton).click(EveryDayBundleAddToCartButton).build().perform();
  	}

}
