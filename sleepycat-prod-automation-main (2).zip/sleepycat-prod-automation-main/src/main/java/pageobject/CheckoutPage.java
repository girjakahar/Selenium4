package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CheckoutPage {
	
	static RemoteWebDriver driver;
	
	//Contact details section
	@FindBy(name = "billing_first_name")
    private WebElement Billing_First_Name;
    
    @FindBy(id = "billing_last_name")
    private WebElement Billing_Last_Name;
    
    @FindBy(id = "billing_email")
    private WebElement Billing_Email;
    
    @FindBy(id = "billing_phone")
    private WebElement Billing_Phone;
    
    @FindBy(xpath = "//label[@for='billing_allow_wp_updates']")
    private WebElement WhatsappCheckbox;
    
    @FindBy(xpath = "//a[text()='Continue to Shipping']")
    private WebElement ContinueShipping;
	
	//Webelements for Contact details section
	public WebElement billingFirstName()
	{
		return Billing_First_Name;
	}
	public WebElement billingLastName()
	{
		return Billing_Last_Name;
	}
	public WebElement billingEmail()
	{
		return Billing_Email;
	}
	public WebElement billingPhone()
	{
		return Billing_Phone;
	}
	public WebElement whatsappCheckbox()
	{
		return WhatsappCheckbox;
	}
	public WebElement continueShipping()
	{
		return ContinueShipping;
	}
	
	//Billing address section 
	@FindBy(id = "billing_address_1")
    private WebElement House;
    
    @FindBy(id = "billing_address_2")
    private WebElement Street;
    
    @FindBy(id = "billing_postcode")
    private WebElement Billing_Postcode;
    
    @FindBy(id = "billing_city")
    private WebElement Billing_City;
    
    @FindBy(id = "place_order")
    private WebElement Place_Order;
	
	//Webelements for billing address details section
	public WebElement house()
	{
		return House;
	}
	
	public WebElement street()
	{
		return Street;
	}
	
	public WebElement billing_Postcode()
	{
		return Billing_Postcode;
	}
	
	public WebElement billing_City()
	{
		return Billing_City;
	}
	
	public WebElement Place_Order()
	{
		return Place_Order;
	}
	
	//Xpath for Razoepay payment gateway
	//@FindBy(xpath = "//*[@id='merchant']")
	@FindBy(xpath = "//div[@data-block='rzp.cluster']")
    private WebElement RazorpayFrame;
	
	//Webelements for billing address details section
	public WebElement razorpayFrame()
	{
		return RazorpayFrame;
	}
	
	public void selectState()
	{
		WebElement state = driver.findElement(By.id("billing_state"));
		Select drpstate = new Select(state);
		drpstate.selectByVisibleText("Maharashtra");
	}
	
	//Snapmint paymnet gateway radio buttob selection
	//Xpath for Snapmint Radio Option on checkout page
	@FindBy(xpath = "//li[@class='wc_payment_method payment_method_snapmint']")
	 private WebElement SnapmintRadioOption;
		
	//Webelements for Snapmint Radio Option on checkout page
    public WebElement snapmintRadioOption()
	{
		return SnapmintRadioOption;
	}
    
    //Xpath for Snapmint logo on sanpmint otp verification page
  	@FindBy(xpath = "//img[@class='logo']")
  	 private WebElement SnapmintGateway;
  		
  	//Webelements for Snapmint logo on sanpmint otp verification page
      public WebElement snapmintGateway()
  	{
  		return SnapmintGateway;
  	}
	
	public CheckoutPage(RemoteWebDriver driver) { //to provide life to driver in different test cases where this Landing page object is used we have added this method

		this.driver=driver; //this vaiable is created to give life to driver
	    PageFactory.initElements(driver, this);
	}

}
