package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class KnittedThrow {
	
	static RemoteWebDriver driver;
	
	 public KnittedThrow(RemoteWebDriver driver) throws Exception
	   {
        this.driver = driver; 
        PageFactory.initElements(driver, this);
       }
	
	        //Xpath for Different style option for Muslin Throw product details page
			@FindBy(xpath = "//li[@data-value='biscottibeige']")
		    private WebElement BiscottiBeigeColor;

			@FindBy(xpath = "//li[@data-value='pineappleyellow']")
		    private WebElement PineappleYellowColor;
			
			@FindBy(xpath = "//li[@data-value='pebblegrey']")
		    private WebElement PebbleGreyColor;
			
		    // Webelement for Color options of Weighted Blanket on product details page
			public WebElement biscottiBeigeColor() {
				return BiscottiBeigeColor;
			}
					
			public WebElement pineappleYellowColor() {
				return PineappleYellowColor;
			}
			
			public WebElement pebbleGreyColor() {
				return PebbleGreyColor;
			}
			
			 
			        //Add to cart button
					@FindBy(xpath = "(//button[@data-productid='2138926'])[2]")
				    private WebElement KnittedThrowAddToCartButton;
					
					// Webelement for different Pack size on product details page of Cloud Pillow
					public WebElement knittedThrowAddToCartButton() {
						return KnittedThrowAddToCartButton;
					}
					
			 public void addToCart() {
					//List<AndroidElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));
					//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
					//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
				    Actions cart = new Actions(driver);
					cart.moveToElement(KnittedThrowAddToCartButton).click(KnittedThrowAddToCartButton).build().perform();
				}

}
