package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReviewOrder {
	
	static RemoteWebDriver driver;

    public ReviewOrder(RemoteWebDriver driver) throws Exception
   {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
   }


   //Xpath for Write review buuton
    @FindBy(xpath = "//button[@class='btn btn-orange featherx-add-review']")
    private WebElement WrieReviewButton;
    
   //Webelement for Write review button
   public WebElement wrieReviewButton() {
  		return WrieReviewButton;
  	}
   
   //Xpath for Submit review modal
   @FindBy(xpath = "//div[@class='sgpb-main-html-content-wrapper']")
   private WebElement SubmitReviewModal;
   
   //Webelement for Submit review modal
   public WebElement submitReviewModal() {
 		return SubmitReviewModal;
 	}
   
   //Xpath for Select Product Name Dropdown
   @FindBy(xpath = "//select[@class='select-css']")
   private WebElement SelectProductNameDropdown;
   
   //Webelement for Select Product Name Dropdown
   public WebElement selectProductNameDropdown() {
 		return SelectProductNameDropdown;
 	}

}
