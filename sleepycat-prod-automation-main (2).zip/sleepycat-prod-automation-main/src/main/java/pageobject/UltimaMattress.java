package pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.MyPageFactory;

public class UltimaMattress {
	
	static RemoteWebDriver driver;
	
	 public UltimaMattress(RemoteWebDriver driver) throws Exception
	   {
       this.driver = driver; 
       PageFactory.initElements(driver, this);
      }
	 
	//Ultima mattress size section on product details page
    // Dropdown option when Inch is selected in Plus mattress and when category is Single
    @FindBy(xpath = "//li[@data-sku='SC-ULTM-S-72x30x8']")
    private WebElement SingleUltima72x30x8;
		
	@FindBy(xpath = "//li[@data-sku='SC-ULTM-S-72x36x8']")
    private WebElement SingleUltima72x36x8;
	
	@FindBy(xpath = "//li[@data-sku='SC-ULTM-S-78x30x8']")
    private WebElement SingleUltima78x30x8;
	
	@FindBy(xpath = "//li[@data-sku='SC-ULTM-K-75x72x10']")
    private WebElement KingUltima75x72x10;

	// Webelement when Inch is selected in Plus mattress and when category is Single
	public WebElement singleUltima72x30x8() {
		return SingleUltima72x30x8;
	}

	public WebElement singleUltima72x36x8() {
		return SingleUltima72x36x8;
	}
	
	public WebElement singleUltima78x30x8() {
		return SingleUltima78x30x8;
	}
	
	public WebElement kingUltima75x72x10() {
		return KingUltima75x72x10;
	}

			
    // Dropdown option when Inch is selected in Plus mattress and when category is queen
	@FindBy(xpath = "//li[@data-sku='SC-ULTM-Q-72x60x8']")
    private WebElement QueenUltima72x60x8;
		
	@FindBy(xpath = "//li[@data-sku='SC-ULTM-Q-75x60x8']")
    private WebElement QueenUltima75x60x8;

	// Webelement when Inch is selected in Plus mattress and when category is queen
	public WebElement QueenUltima72x60x8() {
		return QueenUltima72x60x8;
	}

	public WebElement queenUltima72x60x8() {
		return QueenUltima72x60x8;
	}
			
			
		
	//Xpath for 10 inch Height on Plus mattress page
	@FindBy(xpath = "//li[@data-value='10 inch']")
    private WebElement TenInchHeight;
		
	@FindBy(xpath = "//li[@data-value='8 inch']")
    private WebElement EightInchHeight;
			
	// Webelement option for 10 inch Height on Plus mattress page
	public WebElement tenInchHeight() {
		return TenInchHeight;
	}
			
	public WebElement eightInchHeight() {
		return EightInchHeight;
	}
			
		
	// Xpath for Dropdown option when category is Queen on Plus mattress and height is 10 inch
	@FindBy(xpath = "//li[@data-sku='SC-PLUS-Q-75x60x10']")
    private WebElement QueenPlus75x60x10;
		
	@FindBy(xpath = "//li[@data-sku='SC-PLUS-Q-78x60x10']")
    private WebElement QueenPlus78x60x10;
				
	// Webelement option for Dropdown option when category is Queen on Plus mattress and height is 10 inch
	public WebElement queenPlus75x60x10() {
		return QueenPlus75x60x10;
	}

	public WebElement queenPlus78x60x10() {
		return QueenPlus78x60x10;
	}
	// Size dropdown section 
	@FindBy(xpath = "//div[@Class='variations attr']")
    private WebElement PlusMattressSizeDropdown;
			
	//Webelement for sizeDropdown field
	public WebElement plusMattressSizeDropdown() {
		return PlusMattressSizeDropdown;
	}
	
	/*
	 * //Product added in cart XPath
	 * 
	 * @FindBy(xpath =
	 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PLUS-S-72x30x8']")
	 * private WebElement ProductAddedInCart;
	 * 
	 * // Webelement for Product added in cart XPath public WebElement
	 * productAddedInCart() { return ProductAddedInCart; }
	 * 
	 * //Product added in cart XPath
	 * 
	 * @FindBy(xpath =
	 * "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PLUS-S-72x30x8']")
	 * private WebElement SingleCategory72x30x8ProductAddedInCart;
	 * 
	 * // Webelement for Product added in cart XPath public WebElement
	 * singleCategory72x30x8ProductAddedInCart() { return
	 * SingleCategory72x30x8ProductAddedInCart; }
	 */
	//Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PLUS-Q-75x60x8']")
    private WebElement CustomCategoryProductAddedInCart;

	// Webelement for Product added in cart XPath
	public WebElement customCategoryProductAddedInCart() {
		return CustomCategoryProductAddedInCart;
	}
	
	
	
	/*
	 * public void selectSize() throws Exception { Actions sizeselect = new
	 * Actions(driver); sizeselect.moveToElement(PlusMattressSizeDropdown).click(
	 * PlusMattressSizeDropdown).build().perform();
	 * sizeselect.moveToElement(SinglePlus72x36x8).click(SinglePlus72x36x8).click().
	 * build().perform();
	 * 
	 * }
	 */
	
	        //Add to cart button
			@FindBy(xpath = "(//button[@data-productid='629264'])[2]")
		    private WebElement UltimaMattressAddToCartButton;
			
			// Webelement for different Pack size on product details page of Cloud Pillow
			public WebElement ultimaMattressAddToCartButton() {
				return UltimaMattressAddToCartButton;
			}
			
	public void defaultAddToCart() {
		//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));//div[@class='productDirectPurchase hidden_form plus']//button[@type='button'][normalize-space()='Add To Cart']
		//WebElement add1 = driver.findElementByXPath("(//button[@class='single_add_to_cart_button btn-block alt'])[2]");
		//WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt']");
		Actions cart = new Actions(driver);
		cart.moveToElement(UltimaMattressAddToCartButton).click(UltimaMattressAddToCartButton).build().perform();
	}
	
	public void changedaddToCart() {
		//List<WebElement> add = driver.findElements(By.xpath("//button[text()='Add To Cart']"));//div[@class='productDirectPurchase hidden_form plus']//button[@type='button'][normalize-space()='Add To Cart']
		WebElement add1 = driver.findElementByXPath("//button[@class='single_add_to_cart_button btn-block alt btn-orange inverse']");
		Actions cart = new Actions(driver);
		cart.moveToElement(add1).click(add1).build().perform();
	}

}
