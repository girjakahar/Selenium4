package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllMattressProductsListingPage {
	
	static RemoteWebDriver driver;
	
	 public AllMattressProductsListingPage(RemoteWebDriver driver) throws Exception
	   {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
     }
	
	   // Xpath for Banner section 
	   @FindBy(xpath = "(//a[text()='SHOP NOW'])[2]")
	   private WebElement UltimaMattressShopNow;
		
	   @FindBy(xpath = "(//a[text()='SHOP NOW'])[3]")
	   private WebElement LatexMattressShopNow;
		
	   @FindBy(xpath = "(//a[text()='SHOP NOW'])[1]")
	   private WebElement OriginalMattressShopNow;
		
	   @FindBy(xpath = "(//a[text()='SHOP NOW'])[4]")
	   private WebElement BabyMattressShopNow;
	   
	   //@FindBy(xpath = "//div[@class='linkToCompareMattress']/div/a")
	   @FindBy(xpath = "//div[text()='Compare mattresses']")
	   private WebElement CompareMattressButton;
		
		// Webelement for banner section
		public WebElement ultimaMattressShopNow() {
			return UltimaMattressShopNow;
		}

		public WebElement latexMattressShopNow() {
			return LatexMattressShopNow;
		}

		public WebElement originalMattressShopNow() {
			return OriginalMattressShopNow;
		}

		public WebElement babyMattressShopNow() {
			return BabyMattressShopNow;
		}
		
		public WebElement compareMattressButton() {
			return CompareMattressButton;
		}
		
		public void hybridLatexMattressShopNowclick() 
	    {		
	 	  Actions categoryscroll = new Actions(driver); 
	 	  //categoryscroll.moveToElement(PillowsCategory).click().build().perform();
	 	  categoryscroll.moveToElement(LatexMattressShopNow).click().build().perform();		
	 	}

}
