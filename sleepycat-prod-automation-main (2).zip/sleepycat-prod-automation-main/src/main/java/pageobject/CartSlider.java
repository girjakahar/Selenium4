package pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.MyPageFactory;

public class CartSlider {

	static RemoteWebDriver driver;

	// Contour CoolTec Memory foam pillow product in cross selling product section
	// in cart slider
	// Xpath for Pack field for CoolTec Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contourcooltecmemorypillow ']//div[@data-name='pack']")
	private WebElement CrossSellCartContourCoolTecPillowPackField;

	// Webelement for Pack field for CoolTec Memory foam pillow
	public WebElement CrossSellCartContourCoolTecPillowPackField() {
		return CrossSellCartContourCoolTecPillowPackField;
	}

	// Xpath for Pack of One for CoolTec Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contourcooltecmemorypillow ']//li[@value='pillow-1']")
	private WebElement CrossSellCartContourCoolTecPillowPackOfOne;

	// Webelement for Pack of One field for CoolTec Memory foam pillow
	public WebElement CrossSellCartContourCoolTecPillowPackOfOne() {
		return CrossSellCartContourCoolTecPillowPackField;
	}

	// Xpath for Pack of Two for CoolTec Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contourcooltecmemorypillow ']//li[@value='pillow-2']")
	private WebElement CrossSellCartContourCoolTecPillowPackOfTwo;

	// Webelement for Pack of Two field for CoolTec Memory foam pillow
	public WebElement crossSellCartContourCoolTecPillowPackOfTwo() {
		return CrossSellCartContourCoolTecPillowPackOfTwo;
	}

	// Xpath for Pack of Four for CoolTec Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contourcooltecmemorypillow ']//li[@value='pillow-4']")
	private WebElement CrossSellCartContourCoolTecPillowPackOfFour;

	// Webelement for Pack of Four field for CoolTec Memory foam pillow
	public WebElement crossSellCartContourCoolTecPillowPackOfFour() {
		return CrossSellCartContourCoolTecPillowPackOfFour;
	}

	// Xpath for Add to Cart button in cart cross sell when Pack of Four is selected
	// for CoolTec Memory foam pillow
	@FindBy(xpath = "//span[@data-sku='SC-MFPILWSET4-CLT-S-25x16']")
	private WebElement CrossSellAddToCartButtonForContourCoolTecPillowPackOfFour;

	// Webelement for Add to Cart button in cart cross sell when Pack of Four is
	// selected for CoolTec Memory foam pillow
	public WebElement crossSellAddToCartButtonForContourCoolTecPillowPackOfFour() {
		return CrossSellAddToCartButtonForContourCoolTecPillowPackOfFour;
	}

	// Contour SoftTouch Memory foam pillow product in cross selling product section
	// in cart slider
	// Xpath for Pack field for Contour SoftTouch Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contoursofttouchpillow ']//div[@data-name='pack']")
	private WebElement CrossSellCartContourSoftTouchPillowPackField;

	// Webelement for Pack field for CoolTec Memory foam pillow
	public WebElement crossSellCartContourSoftTouchPillowPackField() {
		return CrossSellCartContourSoftTouchPillowPackField;
	}

	// Xpath for Pack of One for SoftTouch Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contoursofttouchpillow ']//li[@value='pillow-1']")
	private WebElement CrossSellCartContourSoftTouchPillowPackOfOne;

	// Webelement for Pack of One field for CoolTec Memory foam pillow
	public WebElement crossSellCartContourSoftTouchPillowPackOfOne() {
		return CrossSellCartContourSoftTouchPillowPackField;
	}

	// Xpath for Pack of Two for SoftTouch Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contoursofttouchpillow ']//li[@value='pillow-2']")
	private WebElement CrossSellCartContourSoftTouchPillowPackOfTwo;

	// Webelement for Pack of Two field for CoolTec Memory foam pillow
	public WebElement crossSellCartContourSoftTouchPillowPackOfTwo() {
		return CrossSellCartContourSoftTouchPillowPackOfTwo;
	}

	// Xpath for Pack of Four for SoftTouch Memory foam pillow
	@FindBy(xpath = "//div[@class='container_cross_sell contoursofttouchpillow ']//li[@value='pillow-4']")
	private WebElement CrossSellCartContourSoftTouchPillowPackOfFour;

	// Webelement for Pack of Four field for CoolTec Memory foam pillow
	public WebElement crossSellCartContourSoftTouchPillowPackOfFour() {
		return CrossSellCartContourSoftTouchPillowPackOfFour;
	}

	// Xpath for Add to Cart button in cart cross sell when Pack of Four is selected
	// for CoolTec Memory foam pillow
	@FindBy(xpath = "//span[@data-sku='SC-MFPILWSET4-BAM-C-25x16']")
	private WebElement CrossSellAddToCartButtonForContourSoftTouchPillowPackOfFour;

	// Webelement for Add to Cart button in cart cross sell when Pack of Four is
	// selected for CoolTec Memory foam pillow
	public WebElement crossSellAddToCartButtonForContourSoftTouchPillowPackOfFour() {
		return CrossSellAddToCartButtonForContourSoftTouchPillowPackOfFour;
	}

	// Contour Cooltec Pillow Product is added in cart slider
	// Xpath for Contour category CoolTec MemoryFoam pillow product added in cart
	// slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILW-CLT-C-25x16']")
	private WebElement ContourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart;

	// Webelement for Contour category CoolTec MemoryFoam pillow product added in
	// cart slider
	public WebElement contourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart() {
		return ContourCoolTecMemoryFoamPillowPackOfOneProductAddedInCart;
	}

	// Xpath for Contour category CoolTec MemoryFoam pillow product added in cart
	// slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILWSET4-CLT-S-25x16']")
	private WebElement ContourCategoryCoolTecMemoryFoamPillowPackOfFourProductAddedInCart;

	// Webelement for Contour category CoolTec MemoryFoam pillow product added in
	// cart slider
	public WebElement contourCategoryCoolTecMemoryFoamPillowPackOfFourProductAddedInCart() {
		return ContourCategoryCoolTecMemoryFoamPillowPackOfFourProductAddedInCart;
	}

	// Contour SoftTouch Pillow Product is added in cart slider
	// Xpath for Contour category SoftTouch MemoryFoam pillow product added in cart
	// slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILW-BAM-C-25x16']")
	private WebElement ContourSoftTouchMemoryFoamPillowPackOfOneProductAddedInCart;

	// Webelement for Contour category SoftTouch MemoryFoam pillow product added in
	// cart slider
	public WebElement contourSoftTouchMemoryFoamPillowPackOfOneProductAddedInCart() {
		return ContourSoftTouchMemoryFoamPillowPackOfOneProductAddedInCart;
	}

	// Xpath for Contour category SoftTouch MemoryFoam pillow product added in cart
	// slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILWSET4-BAM-C-25x16']")
	private WebElement ContourSoftTouchMemoryFoamPillowPackOfFourProductAddedInCart;

	// Webelement for Contour category SoftTouch MemoryFoam pillow product added in
	// cart slider
	public WebElement contourSoftTouchMemoryFoamPillowPackOfFourProductAddedInCart() {
		return ContourSoftTouchMemoryFoamPillowPackOfFourProductAddedInCart;
	}

	// Cross selling products image link xpath in cart slider
	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/comforter/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingComforterImage;

	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/pillow-memory-foam-pillow/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingMemoryPillowImage;

	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/mattress-protector/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingProtectorImage;

	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/cloud-pillow/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingCloudPillowImage;

	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/weighted-blanket/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingWeightedBlanketImage;

	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/pillow-pregnancy-body-pillow/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingCuddlePillowImage;

	@FindBy(xpath = "//a[@href='https://sleepycat.in/product/pillow-case/']//img[@class='img-responsive alsoBuy-image']")
	private WebElement CrossSellingPillowCaseImage;

	// Web element for Cross selling products image link in cart slider
	public WebElement crossSellingComforterImage() {
		return CrossSellingComforterImage;
	}

	public WebElement crossSellingMemoryPillowImage() {
		return CrossSellingMemoryPillowImage;
	}

	public WebElement crossSellingProtectorImage() {
		return CrossSellingProtectorImage;
	}

	public WebElement crossSellingCloudPillowImage() {
		return CrossSellingCloudPillowImage;
	}

	public WebElement crossSellingWeightedBlanketImage() {
		return CrossSellingWeightedBlanketImage;
	}

	public WebElement crossSellingCuddlePillowImage() {
		return CrossSellingCuddlePillowImage;
	}

	public WebElement crossSellingPillowCaseImage() {
		return CrossSellingPillowCaseImage;
	}

	// next and previous icon xpath in cart slider
	@FindBy(xpath = "//div[@class='cart-cross-sell-section-wrap cross-selling-section']//a[@class='lSNext']")
	private WebElement NextCrossProduct;

	@FindBy(xpath = "//div[@class='cart-cross-sell-section-wrap cross-selling-section']//a[@class='lSPrev']")
	private WebElement PreviousCrossProduct;

	// next and previous icon webelement in cart slider
	public WebElement nextCrossProduct() {
		return NextCrossProduct;
	}

	public WebElement previousCrossProduct() {
		return PreviousCrossProduct;
	}

	// Default Add to cart button xpath for Cross selling products in cart slider
	@FindBy(xpath = "//span[@data-sku='SC-COMF-S-90x60']")
	private WebElement DefaultAddtoCartSingleComforter;

	@FindBy(xpath = "//span[@data-sku='SC-PILLOW-S-26x16x4']")
	private WebElement DefaultAddtoCartStandardSetOffOneMemoryFoamPillow;

	@FindBy(xpath = "//span[@data-sku='SC-PROT-S-75x36']")
	private WebElement DefaultAddtoCartSingleProtector75x36;

	@FindBy(xpath = "//span[@data-sku='SC-CLPILW-S-27x18']")
	private WebElement DefaultAddtoCartStandardPackOfOneCloudPillow;

	@FindBy(xpath = "//span[@data-sku='SC-CLWTBLANKET-S-75x50']")
	private WebElement DefaultAddtoCartGreyColorWeightedBlanket;

	@FindBy(xpath = "//span[@data-sku='SC-GRBDPILWSET-S-50x19']")
	private WebElement DefaultAddtoCartCuddlePillow;

	@FindBy(xpath = "//span[@data-sku='SC-GRPILWCS-P-33x21']")
	private WebElement DefaultAddtoCartCloudPillowCasePackofTwo;

	// Webelement for different Add to cart button for products
	public WebElement defaultAddtoCartSingleComforter() {
		return DefaultAddtoCartSingleComforter;
	}

	public WebElement defaultAddtoCartStandardSetOffOneMemoryFoamPillow() {
		return DefaultAddtoCartStandardSetOffOneMemoryFoamPillow;
	}

	public WebElement defaultAddtoCartSingleProtector75x36() {
		return DefaultAddtoCartSingleProtector75x36;
	}

	public WebElement defaultAddtoCartStandardPackOfOneCloudPillow() {
		return DefaultAddtoCartStandardPackOfOneCloudPillow;
	}

	public WebElement defaultAddtoCartGreyColorWeightedBlanket() {
		return DefaultAddtoCartGreyColorWeightedBlanket;
	}

	public WebElement defaultAddtoCartCuddlePillow() {
		return DefaultAddtoCartCuddlePillow;
	}

	public WebElement defaultAddtoCartCloudPillowCasePackofTwo() {
		return DefaultAddtoCartCloudPillowCasePackofTwo;
	}

	// Xpath for different component after adding any products to cart
	@FindBy(xpath = "//button[@class='close_slider']")
	private WebElement ClosecartSlider;

	@FindBy(xpath = "//div[@class='quantity checkout_page_box']//input[@class='plus']")
	private WebElement IncrementQuantity;

	@FindBy(xpath = "//div[@class='quantity checkout_page_box']//input[@class='minus']")
	private WebElement DecreseQuantity;

	@FindBy(xpath = "//button[@class='product-remove']//i[@class='fa fa-trash']")
	private WebElement RemoveProduct;

	// Webelement for different component after adding any products to cart
	public WebElement closecartSlider() {
		return ClosecartSlider;
	}

	public WebElement incrementQuantity() {
		return IncrementQuantity;
	}

	public WebElement decreseQuantity() {
		return DecreseQuantity;
	}

	public WebElement removeProduct() {
		return RemoveProduct;
	}

	// Securecheckout button xpath in cart slider
	@FindBy(xpath = "//button[@id='secure_checkout']")
	private WebElement SecureCheckout;

	// Securecheckout button webelement in cart slider
	public WebElement secureCheckout() {
		return SecureCheckout;
	}

	// Xpath for helpguide text link in cart slider
	@FindBy(xpath = "//span[@class='sizeChart']")
	private WebElement MattressHelpGuideLinkText;

	// Webelement for helpguide text link in cart slider
	public WebElement mattressHelpGuideLinkText() {
		return MattressHelpGuideLinkText;
	}

	// Xpath for Mattress helpguide in image
	@FindBy(xpath = "//*[@id='myTabContent1']//*[contains(@class, 'tab-pane fade active show')]/img")
	private WebElement MattressGuideImage;

	// Webelement for Mattress helpguide in image
	public WebElement mattressGuideImage() {
		return MattressGuideImage;
	}

	// Pillow cases product added in cart slider
	// President pillow case Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DGRPILWCS-P-32x20']")
	private WebElement DolphinGrayColorPresidentPillowCasePackOfTwoProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-TBLPILWCS-P-32x20']")
	private WebElement TwlightBlueColorPresidentPillowCasePackOfTwoProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BCRPILWCS-P-32x20']")
	private WebElement ButterScoutchColorPresidentPillowCasePackOfTwoProductAddedInCart;

	// Webelement for President pillow case Product added in cart XPath
	public WebElement dolphinGrayColorPresidentPillowCasePackOfTwoProductAddedInCart() {
		return DolphinGrayColorPresidentPillowCasePackOfTwoProductAddedInCart;
	}

	public WebElement twlightBlueColorPresidentPillowCasePackOfTwoProductAddedInCart() {
		return TwlightBlueColorPresidentPillowCasePackOfTwoProductAddedInCart;
	}

	public WebElement butterScoutchColorPresidentPillowCasePackOfTwoProductAddedInCart() {
		return ButterScoutchColorPresidentPillowCasePackOfTwoProductAddedInCart;
	}

	// Standard pillow case Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DGRPILWCS-S-28x18']")
	private WebElement DolphinGrayColorStandardPillowCasePackOfTwoProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-TBLPILWCS-S-28x18']")
	private WebElement TwlightBlueColorStandardPillowCasePackOfTwoProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BCRPILWCS-S-28x18']")
	private WebElement ButterScoutchColorStandardPillowCasePackOfTwoProductAddedInCart;

	// Webelement for Standard pillow case Product added in cart XPath
	public WebElement dolphinGrayColorStandardPillowCasePackOfTwoProductAddedInCart() {
		return DolphinGrayColorStandardPillowCasePackOfTwoProductAddedInCart;
	}

	public WebElement twlightBlueColorStandardPillowCasePackOfTwoProductAddedInCart() {
		return TwlightBlueColorStandardPillowCasePackOfTwoProductAddedInCart;
	}

	public WebElement butterScoutchColorStandardPillowCasePackOfTwoProductAddedInCart() {
		return ButterScoutchColorStandardPillowCasePackOfTwoProductAddedInCart;
	}

	// Cross selling section for Protector in cart slider
	// Xpath for category Type field of comforter cross selling product section
	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//div[@data-value='Single']")
	private WebElement CrossSellCartProtectorCategoryField;

	// Webelement option for category Type field of comforter cross selling product
	// section
	public WebElement crossSellCartProtectorCategoryField() {
		return CrossSellCartProtectorCategoryField;
	}

	// Xpath for different category field of comforter cross selling product section
	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//span[text()='Single']")
	private WebElement CrossSellCartSingleCategoryProtector;

	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//span[text()='Double']")
	private WebElement CrossSellCartDoubleCategoryProtector;

	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//span[text()='King']")
	private WebElement CrossSellCartKingCategoryProtector;

	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//span[text()='Queen']")
	private WebElement CrossSellCartQueenCategoryProtector;

	// Webelement option for Double category of comforter cross selling product
	// section
	public WebElement crossSellCartSingleCategoryProtector() {
		return CrossSellCartSingleCategoryProtector;
	}

	public WebElement crossSellCartDoubleCategoryProtector() {
		return CrossSellCartDoubleCategoryProtector;
	}

	public WebElement crossSellCartKingCategoryProtector() {
		return CrossSellCartKingCategoryProtector;
	}

	public WebElement crossSellCartQueenCategoryProtector() {
		return CrossSellCartQueenCategoryProtector;
	}

	// Xpath for Size field of Protector cross selling product section
	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//div[@name='variations protector']")
	private WebElement CrossSellCartProtectorSizeField;

	// Webelement option for category Type field of comforter cross selling product
	// section
	public WebElement crossSellCartProtectorSizeField() {
		return CrossSellCartProtectorSizeField;
	}

	// Xpath for Different Size dropdown field of Protector in cross selling product
	// section
	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//li[@data-sku='SC-PROT-D-75x48']")
	private WebElement CrossSellCartDoubleProtector75x48;

	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//li[@data-sku='SC-PROT-D-78x48']")
	private WebElement CrossSellCartDoubleProtector78x48;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement crossSellCartDoubleProtector75x48() {
		return CrossSellCartDoubleProtector75x48;
	}

	public WebElement crossSellCartDoubleProtector78x48() {
		return CrossSellCartDoubleProtector78x48;
	}

	// Xpath for Different Size dropdown field of Protector in cross selling product
	// section
	@FindBy(xpath = "//span[@data-sku='SC-PROT-D-75x48']")
	private WebElement CrossSellCartAddToCartDoubleProtector75x48;

	@FindBy(xpath = "//span[@data-sku='SC-PROT-D-78x48']")
	private WebElement CrossSellCartAddToCartDoubleProtector78x48;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement crossSellCartAddToCartDoubleProtector75x48() {
		return CrossSellCartAddToCartDoubleProtector75x48;
	}

	public WebElement crossSellCartAddToCartDoubleProtector78x48() {
		return CrossSellCartAddToCartDoubleProtector78x48;
	}

	// Xpath for Different Size dropdown field of Protector in cross selling product
	// section when category is queen
	@FindBy(xpath = "//div[@class='container_cross_sell protector on-sale lslide']//li[@data-sku='SC-PROT-Q-78x60']")
	private WebElement CrossSellCartQueenProtector78x60;

	// Webelement for Different Size dropdown field of Protector in cross selling
	// product section
	public WebElement crossSellCartQueenProtector78x60() {
		return CrossSellCartQueenProtector78x60;
	}

	// Xpath for Add to cart button when Protector in cross selling product section
	@FindBy(xpath = "//span[@data-sku='SC-PROT-Q-78x60']")
	private WebElement CrossSellCartAddToCartQueenProtector78x60;

	// Webelement for Add to cart button when Protector Protector in cross selling
	// product section
	public WebElement crossSellCartAddToCartQueenProtector78x60() {
		return CrossSellCartAddToCartQueenProtector78x60;
	}

	// Xpath for Defaut Add to cart button when Single Protector in cross selling
	// product section
	@FindBy(xpath = "//span[@data-sku='SC-PROT-S-78x36']")
	private WebElement CrossSellCartAddToCartSingleProtector78x36;

	// Webelement for Add to cart button when Protector Protector in cross selling
	// product section
	public WebElement crossSellCartAddToCartSingleProtector78x36() {
		return CrossSellCartAddToCartSingleProtector78x36;
	}

	// Cross sell Weighted Blanket product in cart slider
	// Xpath for pack field of cloud pillow in cross selling product section
	@FindBy(xpath = "//div[@class='container_cross_sell weighted_blanket lslide']//li[@data-value='wbpink']")
	private WebElement CrossSellCartWeightedBlanketPinkColor;

	@FindBy(xpath = "//div[@class='container_cross_sell weighted_blanket lslide']//li[@data-value='wbgrey']")
	private WebElement CrossSellCartWeightedBlanketGreyColor;

	// Webelement option for pack field of weighted blanket in cross selling product
	// section
	public WebElement crossSellCartWeightedBlanketPinkColor() {
		return CrossSellCartWeightedBlanketPinkColor;
	}

	public WebElement crossSellCartWeightedBlanketGreyColor() {
		return CrossSellCartWeightedBlanketGreyColor;
	}

	// Xpath for Add to cart button for weighted blanket in cross selling product
	// section in cart slider when color is pink
	@FindBy(xpath = "//span[@data-sku='SC-BNWTBLANKET-S-75x50']")
	private WebElement CrossSellCartAddToCartWeightedBlanketPinkColor;

	// Webelement option for pack field of weighted blanket in cross selling product
	// section
	public WebElement crossSellCartAddToCartWeightedBlanketPinkColor() {
		return CrossSellCartAddToCartWeightedBlanketPinkColor;
	}

	// Luxe Comforter Product is added in cart slider
	// Xpath for Single category Luxe Comforter product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-EGWTLUXCOMF-S-90x60']")
	private WebElement SingleCategoryLuxeComforterProductAddedInCart;

	// Webelement for Single category Luxe Comforter product added in cart slider
	public WebElement singleCategoryLuxeComforterProductAddedInCart() {
		return SingleCategoryLuxeComforterProductAddedInCart;
	}

	// Xpath for Double category Luxe Comforter product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-EGWTLUXCOMF-D-90x100']")
	private WebElement DoubleCategoryLuxeComforterProductAddedInCart;

	// Webelement for Double category Luxe Comforter product added in cart slider
	public WebElement doubleCategoryLuxeComforterProductAddedInCart() {
		return DoubleCategoryLuxeComforterProductAddedInCart;
	}

	// Knitted Throw Product is added in cart slider
	// Xpath for Biscotti Beige color Knitted Throw product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BSBGTHR-S-49X59']")
	private WebElement BiscottiBeigeKnittedThrowProductAddedInCart;

	// Webelement for Biscotti Beige color Knitted Throw product added in cart
	// slider
	public WebElement biscottiBeigeKnittedThrowProductAddedInCart() {
		return BiscottiBeigeKnittedThrowProductAddedInCart;
	}

	// Xpath for Pineapple yellow color Knitted Throw product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PNYLTHR-S-49X59']")
	private WebElement PineappleYellowKnittedThrowProductAddedInCart;

	// Webelement for Pineapple yellow color Knitted Throw product added in cart
	// slider
	public WebElement pineappleYellowKnittedThrowProductAddedInCart() {
		return PineappleYellowKnittedThrowProductAddedInCart;
	}

	// Xpath for Pebble grey color Knitted Throw product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PBGRTHR-S-49X59']")
	private WebElement PebbleGreyKnittedThrowProductAddedInCart;

	// Webelement for Pebble grey color Knitted Throw product added in cart slider
	public WebElement pebbleGreyKnittedThrowProductAddedInCart() {
		return PebbleGreyKnittedThrowProductAddedInCart;
	}

	// Pillow Case product in cross selling product section in cart slider
	// Xpath for Type field for pillow case product
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//div[@data-value='Cloud Pillow Case']")
	private WebElement CrossSellCartPillowCaseTypeField;

	// Webelement for Type field for pillow case product
	public WebElement crossSellCartPillowCaseTypeField() {
		return CrossSellCartPillowCaseTypeField;
	}

	// Xpath for Different Type options for pillow cases
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//li[@data-value='Memory Foam Pillow Case']")
	private WebElement CrossSellCartMemoryCaseTypeForPillowCases;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//li[@data-value='Cuddle Pillow Case']")
	private WebElement CrossSellCartCuddleCaseTypeForPillowCases;

	// Webelement for Different Type options for pillow cases
	public WebElement crossSellCartMemoryCaseTypeForPillowCases() {
		return CrossSellCartMemoryCaseTypeForPillowCases;
	}

	public WebElement crossSellCartCuddleCaseTypeForPillowCases() {
		return CrossSellCartCuddleCaseTypeForPillowCases;
	}

	// Xpath for Pack field for Pillow cases
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//div[@data-value='case-2']")
	private WebElement CrossSellCartPillowCasesPackField;

	// Webelement for Pack field for Pillow cases
	public WebElement crossSellCartPillowCasesPackField() {
		return CrossSellCartPillowCasesPackField;
	}

	// Xpath for different Pack options for pillow cases
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//li[text()='Pack of 4']")
	private WebElement CrossSellCartPillowCasePackOfFour;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//li[text()='Pack of 8']")
	private WebElement CrossSellCartPillowCasePackOfEight;

	// Webelement for different Pack options for Memory pillow when President
	// category is selected
	public WebElement crossSellCartPillowCasePackOfFour() {
		return CrossSellCartPillowCasePackOfFour;
	}

	public WebElement crossSellCartPillowCasePackOfEight() {
		return CrossSellCartPillowCasePackOfEight;
	}

	// Xpath for size field for Pillow case cross selling product
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//div[@class='customDropdown variations pillow_case']")
	private WebElement CrossSellCartPillowCaseSizeField;

	// Webelement for size field for Pillow case cross selling product
	public WebElement crossSellCartPillowCaseSizeField() {
		return CrossSellCartPillowCaseSizeField;
	}

	// Xpath for different size dropdown for pillow cases when Type is memory foam
	// and Pack is four
	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//li[@data-sku='SC-GRPILWCSSET2-S-28x18']")
	private WebElement CrossSellCartMemoryPillowTypePillowcasePackFour28x18;

	@FindBy(xpath = "//div[@class='container_cross_sell pillow_case lslide']//li[@data-sku='SC-GRPILWCSSET2-P-33x21']")
	private WebElement CrossSellCartMemoryPillowTypePillowcasePackFour33x21;

	// Webelement for different size dropdown for pillow cases when Type is memmory
	// foam and Pack is four
	public WebElement crossSellCartMemoryPillowTypePillowcasePackFour28x18() {
		return CrossSellCartMemoryPillowTypePillowcasePackFour28x18;
	}

	public WebElement crossSellCartMemoryPillowTypePillowcasePackFour33x21() {
		return CrossSellCartMemoryPillowTypePillowcasePackFour33x21;
	}

	// Xpath for Add to cart button for pillow case when type is memory Foam and and
	// Pack is four
	@FindBy(xpath = "//span[@data-sku='SC-GRPILWCSSET2-S-28x18']")
	private WebElement CrossSellCartAddToCartMemoryPillowTypePillowcasePackOfFour;

	// Webelement for Add to cart button for pillow case when type is memory Foam
	// and and Pack is four
	public WebElement crossSellCartAddToCartMemoryPillowTypePillowcasePackOfFour() {
		return CrossSellCartAddToCartMemoryPillowTypePillowcasePackOfFour;
	}

	// Cloud Pillow products added in cart
	// Cross selling president category cloud pillow Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CLPILWSET4-P-32x20']")
	private WebElement PresidentCategoryCloudPillowPackOfFourProductAddedInCart;

	// Webelement for Cross selling president category cloud pillow Product added in
	// cart XPath
	public WebElement presidentCategoryCloudPillowPackOfFourProductAddedInCart() {
		return PresidentCategoryCloudPillowPackOfFourProductAddedInCart;
	}

	// President category Cloud Pillow Pack of Two Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CLPILWSET2-P-32x20']")
	private WebElement PresidentCategoryCloudPillowPackOfTwoProductAddedInCart;

	// Webelement for President category Cloud Pillow Pack of Two Product added in
	// Cart
	public WebElement presidentCategoryCloudPillowPackOfTwoProductAddedInCart() {
		return PresidentCategoryCloudPillowPackOfTwoProductAddedInCart;
	}

	// Standard category Cloud Pillow Pack of Two Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CLPILW-S-27x18']")
	private WebElement StandardCategoryCloudPillowPackOfOneProductAddedInCart;

	// Webelement for Standard category Cloud Pillow Pack of Two added in cart XPath
	public WebElement standardCategoryCloudPillowPackOfOneProductAddedInCart() {
		return StandardCategoryCloudPillowPackOfOneProductAddedInCart;
	}

	// Protector product added in cart slider
	// Single category protector Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PROT-S-72x36']")
	private WebElement SingleCategoryGreyColorProtector72x36ProductAddedInCart;

	// Webelement for Single category protector Product added in cart
	public WebElement singleCategoryGreyColorProtector72x36ProductAddedInCart() {
		return SingleCategoryGreyColorProtector72x36ProductAddedInCart;
	}

	// Single category protector Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PROT-WT-S-72x36']")
	private WebElement SingleCategoryWhiteProtector72x36ProductAddedInCart;

	// Webelement for Single category protector Product added in cart
	public WebElement singleCategoryWhiteProtector72x36ProductAddedInCart() {
		return SingleCategoryWhiteProtector72x36ProductAddedInCart;
	}

	// Double category protector Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PROT-D-75x48']")
	private WebElement DoubleCategoryProtector75x48ProductAddedInCart;

	// Webelement for Double category protector Product added in cart
	public WebElement doubleCategoryProtector75x48ProductAddedInCart() {
		return DoubleCategoryProtector75x48ProductAddedInCart;
	}

	// Comforter product added in cart slider
	// Cross selling Double category coffee color Comforter Product added in cart
	// XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CFCOMF-D-90x100']")
	private WebElement DoubleCategoryCoffeColorComforterProductAddedInCart;

	// Webelement for Cross selling Double category coffee color Comforter Product
	// added in cart XPath
	public WebElement doubleCategoryCoffeColorComforterProductAddedInCart() {
		return DoubleCategoryCoffeColorComforterProductAddedInCart;
	}

	// Single category Comforter Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-COMF-S-90x60']")
	private WebElement SingleCategoryWhiteColorComforterProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-LMCOMF-S-90x60']")
	private WebElement SingleCategoryAcidLimeColorComforterProductAddedInCart;

	// Webelement for Single category Comforter Product added in cart
	public WebElement singleCategoryWhiteColorComforterProductAddedInCart() {
		return SingleCategoryWhiteColorComforterProductAddedInCart;
	}

	public WebElement singleCategoryAcidLimeColorComforterProductAddedInCart() {
		return SingleCategoryAcidLimeColorComforterProductAddedInCart;
	}

	// Ultima mattress products added in cart slider
	// Single category plus mattress Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ULTM-S-72x30x8']")
	private WebElement UltimaMattressSingleCategory72x30x8ProductAddedInCart;

	// Webelement for King category plus mattress Product added in cart
	public WebElement ultimaMattressSingleCategory72x30x8ProductAddedInCart() {
		return UltimaMattressSingleCategory72x30x8ProductAddedInCart;
	}

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ULTM-S-72x36x8']")
	private WebElement SingleCategoryUltima72x36x8ProductAddedInCart;

	// Webelement for single category Ultima Mattress Product added in Cart
	public WebElement singleCategoryUltima72x36x8ProductAddedInCart() {
		return SingleCategoryUltima72x36x8ProductAddedInCart;
	}

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ULTM-K-75x72x10']")
	private WebElement KingCategoryUltima75x72x10ProductAddedInCart;

	// Webelement for King category Ultima Mattress Product added in Cart
	public WebElement kingCategoryUltima75x72x10ProductAddedInCart() {
		return KingCategoryUltima75x72x10ProductAddedInCart;
	}

	// Custom category Ultima Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ULTM-Q-78x60x8']")
	private WebElement CustomCategoryUltimaProduct78x60x8AddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ULTM-Q-78x60x10']")
	private WebElement CustomCategoryUltimaProduct78x60x10AddedInCart;

	// Webelement for Custom category Ultima Mattress Product added in Cart
	public WebElement customCategoryUltimaProduct78x60x8AddedInCart() {
		return CustomCategoryUltimaProduct78x60x8AddedInCart;
	}

	public WebElement customCategoryUltimaProduct78x60x10AddedInCart() {
		return CustomCategoryUltimaProduct78x60x10AddedInCart;
	}

	// Cross selling Cart slider Memory Pillow Type pack of four product added in
	// cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-GRPILWCSSET2-S-28x18']")
	private WebElement CrossSellCartMemoryPillowTypePillowcasePackOfFourProductAddedInCart;

	// Webelement for Cross selling Cart slider Memory Pillow Type pack of four
	// product added in cart
	public WebElement CrossSellCartMemoryPillowTypePillowcasePackOfFourProductAddedInCart() {
		return CrossSellCartMemoryPillowTypePillowcasePackOfFourProductAddedInCart;
	}

	// SoftTouchMemory Foam Pillow Products added in cart XPath
	// President category Memory pillow pack of Two Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILWSET2-BAM-P-28x18']")
	private WebElement PresidentCategorySoftTouchMemoryPillowPackOfTwoProductAddedInCart;

	// Webelement for Cross selling President category Memory pillow pack of Two
	// Product added in cart XPath
	public WebElement presidentCategorySoftTouchMemoryPillowPackOfTwoProductAddedInCart() {
		return PresidentCategorySoftTouchMemoryPillowPackOfTwoProductAddedInCart;
	}

	// Standard category Memory pillow pack of one Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILW-BAM-S-25x16']")
	private WebElement StandardCategorySoftTouchMemoryPillowPackOfOneProductAddedInCart;

	// Webelement for Cross selling President category Memory pillow pack of Two
	// Product added in cart XPath
	public WebElement standardCategorySoftTouchMemoryPillowPackOfOneProductAddedInCart() {
		return StandardCategorySoftTouchMemoryPillowPackOfOneProductAddedInCart;
	}

	// Standard category Memory pillow pack of Four Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MFPILWSET4-BAM-S-25x16']")
	private WebElement StandardCategorySoftTouchMemoryPillowPackOfFourProductAddedInCart;

	// Webelement for Standard category Memory pillow pack of Four Product added in
	// cart XPath
	public WebElement standardCategorySoftTouchMemoryPillowPackOfFourProductAddedInCart() {
		return StandardCategorySoftTouchMemoryPillowPackOfFourProductAddedInCart;
	}

	// Metal Bed product added in cart slider
	// Single category Metal bed Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BED-S-78x36x16']")
	private WebElement MetalBedSingleCategoryProductAddedInCart;

	// Webelement for Single category Metal bed Product added in cart
	public WebElement metalBedSingleCategoryProductAddedInCart() {
		return MetalBedSingleCategoryProductAddedInCart;
	}

	// Ohayo Bed product added in cart slider
	// Queen category Ohayo bed Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OHAYOBED-Queen-84x65x13']")
	private WebElement OhayoBedQueenCategoryProductAddedInCart;

	// Webelement for Queen category Ohayo bed Product added in cart
	public WebElement ohayoBedQueenCategoryProductAddedInCart() {
		return OhayoBedQueenCategoryProductAddedInCart;
	}

	// King category Ohayo bed Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OHAYOBED-King-84x77x13']")
	private WebElement OhayoBedKingCategoryProductAddedInCart;

	// Webelement for King category Ohayo bed Product added in cart
	public WebElement ohayoBedKingCategoryProductAddedInCart() {
		return OhayoBedKingCategoryProductAddedInCart;
	}

	// Ohayo Day Bed Products added in cart
	// Xpath for Ohayo Day Bed product is added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OHAYODAYBED-77X41X13']")
	private WebElement OhayoDayBedProductAddedInCart;

	// Webelement for Ohayo Day Bed product is added in cart slider
	public WebElement ohayoDayBedProductAddedInCart() {
		return OhayoDayBedProductAddedInCart;
	}

	// Ohayo Bed Tray Products added in cart
	// Xpath for Ohayo Bed Tray product is added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OHAYOTRAY-10X9X2']")
	private WebElement OhayoBedTrayProductAddedInCart;

	// Webelement for Ohayo Bed Tray product is added in cart slider
	public WebElement ohayoBedTrayProductAddedInCart() {
		return OhayoBedTrayProductAddedInCart;
	}

	// Cuddle pillow product added in cart slider
	// Standard category Cuddle Pillow Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-GRBDPILWSET-S-50x19']")
	private WebElement StandardCategoryCuddlePillowProductAddedInCart;

	// Webelement for President category Cloud Pillow Pack of Two Product added in
	// Cart
	public WebElement standardCategoryCuddlePillowProductAddedInCart() {
		return StandardCategoryCuddlePillowProductAddedInCart;
	}

	// Original mattress product added in cart slider
	// Double category Original Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-D-75x48x6']")
	private WebElement DoubleCategoryOriginalMattress75x48x6ProductAddedInCart;

	// Webelement for Double category Original Mattress Product added in Cart
	public WebElement doubleCategoryOriginalMattress75x48x6ProductAddedInCart() {
		return DoubleCategoryOriginalMattress75x48x6ProductAddedInCart;
	}

	// Double category Original Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-D-72x48x6']")
	private WebElement DoubleCategoryOriginalMattress72x48x6ProductAddedInCart;

	// Webelement for Double category Original Mattress Product added in Cart
	public WebElement doubleCategoryOriginalMattress72x48x6ProductAddedInCart() {
		return DoubleCategoryOriginalMattress72x48x6ProductAddedInCart;
	}

	// Cross selling King category Original Mattress Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-K-75x72x6']")
	private WebElement OriginalMattressKingCategory75x72x6ProductAddedInCart;

	// Webelement for Cross selling King category Original Mattress Product added in
	// cart XPath
	public WebElement originalMattressKingCategory75x72x6ProductAddedInCart() {
		return OriginalMattressKingCategory75x72x6ProductAddedInCart;
	}

	// King category Original Mattress Bundle Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIGBDL-K-72x72x6']")
	private WebElement OriginalMattressKingCategory72x72x6BundleProductAddedInCart;

	// Webelement for King category Original Mattress Bundle Product added in cart
	public WebElement originalMattressKingCategory72x72x6BundleProductAddedInCart() {
		return OriginalMattressKingCategory72x72x6BundleProductAddedInCart;
	}

	// Single category Original Mattress Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-S-78x36x6']")
	private WebElement SingleCategoryOriginalMattress78x36x6ProductAddedInCart;

	// Webelement for Single category Original Mattress Product added in Cart
	public WebElement singleCategoryOriginalMattress78x36x6ProductAddedInCart() {
		return SingleCategoryOriginalMattress78x36x6ProductAddedInCart;
	}

	// Single category Original Mattress Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-S-72x30x6']")
	private WebElement SingleCategoryOriginalMattress72x30x6ProductAddedInCart;

	// Webelement for Single category Original Mattress Product added in Cart
	public WebElement singleCategoryOriginalMattress72x30x6ProductAddedInCart() {
		return SingleCategoryOriginalMattress72x30x6ProductAddedInCart;
	}

	// Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-Q-78x60x6']")
	private WebElement CustomCategoryOriginalMattress78x60x6ProductAddedInCart;

	// Webelement for Product added in cart XPath
	public WebElement customCategoryOriginalMattress78x60x6ProductAddedInCart() {
		return CustomCategoryOriginalMattress78x60x6ProductAddedInCart;
	}

	// Latex mattress product added in cart slider
	// Queen category Latex Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-LATEX-Q-75x60x7']")
	private WebElement QueenCategoryLatexMattress75x60x7ProductAddedInCart;

	// Webelement for Queen category Latex Mattress Product added in Cart
	public WebElement queenCategoryLatexMattress75x60x7ProductAddedInCart() {
		return QueenCategoryLatexMattress75x60x7ProductAddedInCart;
	}

	// Custom category Latex Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYB-LATEX-Q-75x60x6']")
	private WebElement CustomCategoryLatexMattress75x60x6ProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYB-LATEX-Q-78x60x6']")
	private WebElement CustomCategoryLatexMattress78x60x6ProductAddedInCart;

	// Webelement for Custom category Latex Mattress Product added in cart XPath
	public WebElement customCategoryLatexMattress75x60x6ProductAddedInCart() {
		return CustomCategoryLatexMattress75x60x6ProductAddedInCart;
	}

	public WebElement customCategoryLatexMattress78x60x6ProductAddedInCart() {
		return CustomCategoryLatexMattress78x60x6ProductAddedInCart;
	}

	// Single category Latex Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYB-LATEX-S-75x36x6']")
	private WebElement SingleCategoryHybridLatexMattress75x36x6ProductAddedInCart;

	// Webelement for Single category Latex Mattress Product added in Cart
	public WebElement singleCategoryHybridLatexMattress75x36x6ProductAddedInCart() {
		return SingleCategoryHybridLatexMattress75x36x6ProductAddedInCart;
	}

	// King category Latex Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYB-LATEX-K-75x72x6']")
	private WebElement KingCategoryHybridLatexMattress75x72x6ProductAddedInCart;

	// Webelement for King category Latex Mattress Product added in Cart
	public WebElement kingCategoryHybridLatexMattress75x72x6ProductAddedInCart() {
		return KingCategoryHybridLatexMattress75x72x6ProductAddedInCart;
	}

	// Single category Latex Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYB-LATEX-S-72x30x6']")
	private WebElement SingleCategoryHybridLatexMattress72x30x6ProductAddedInCart;

	// Webelement for Single category Latex Mattress Product added in Cart
	public WebElement singleCategoryHybridLatexMattress72x30x6ProductAddedInCart() {
		return SingleCategoryHybridLatexMattress72x30x6ProductAddedInCart;
	}

	// Plus mattress product added in cart slider
	// Double category Plus Mattress Product added in Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PLUS-D-75x48x8']")
	private WebElement DoubleCategoryPlusMattress75x48x8ProductAddedInCart;

	// Webelement for Double category Plus Mattress Product added in Cart
	public WebElement doubleCategoryPlusMattress75x48x8ProductAddedInCart() {
		return DoubleCategoryPlusMattress75x48x8ProductAddedInCart;
	}

	// Baby mattress Product added in cart slider
	// Xpath for Single category Baby mattress product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BABY-S-48x24x4']")
	private WebElement SingleCategoryBabyMattress48x24x4ProductAddedInCart;

	// Webelement for Single category Baby mattress product added in cart slider
	public WebElement singleCategoryBabyMattress48x24x4ProductAddedInCart() {
		return SingleCategoryBabyMattress48x24x4ProductAddedInCart;
	}

	// Xpath for Single category Baby mattress product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BABY-S-52x28x4']")
	private WebElement SingleCategoryBabyMattress52x28x4ProductAddedInCart;

	// Webelement for Single category Baby mattress product added in cart slider
	public WebElement singleCategoryBabyMattress52x28x4ProductAddedInCart() {
		return SingleCategoryBabyMattress52x28x4ProductAddedInCart;
	}

	// Pet bed Products added in cart slider
	// Xpath for Original category medium Pet bed product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PETBEDORIG-M-36x26']")
	private WebElement OriginalCategoryMediumPetBed36x26ProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PETBEDORIG-N.Blue-M-36x26']")
	private WebElement OriginalCategoryMediumBlueColorPetBed36x26ProductAddedInCart;

	// Webelement for Original category medium Pet bed product added in cart slider
	public WebElement originalCategoryMediumPetBed36x26ProductAddedInCart() {
		return OriginalCategoryMediumPetBed36x26ProductAddedInCart;
	}

	public WebElement originalCategoryMediumBlueColorPetBed36x26ProductAddedInCart() {
		return OriginalCategoryMediumBlueColorPetBed36x26ProductAddedInCart;
	}

	// Xpath for Original category Large Pet bed product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PETBEDORIG-L-46x32']")
	private WebElement OriginalCategoryLargePetBed46x32ProductAddedInCart;

	// Webelement for Original category Large Pet bed product added in cart slider
	public WebElement originalCategoryLargePetBed46x32ProductAddedInCart() {
		return OriginalCategoryLargePetBed46x32ProductAddedInCart;
	}

	// Xpath for Orthopedic category Large Pet bed product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PETBEDORTHO-L-48x24']")
	private WebElement OrthopedicCategoryLargePetBed48x24ProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PETBEDORTHO-N.Blue-L-48X24']")
	private WebElement OrthopedicCategoryBlueColorLargePetBed48x24ProductAddedInCart;

	// Webelement for Orthopedic category Large Pet bed product added in cart slider
	public WebElement orthopedicCategoryLargePetBed48x24ProductAddedInCart() {
		return OrthopedicCategoryLargePetBed48x24ProductAddedInCart;
	}

	public WebElement orthopedicCategoryBlueColorLargePetBed48x24ProductAddedInCart() {
		return OrthopedicCategoryBlueColorLargePetBed48x24ProductAddedInCart;
	}

	// Weighted Blanket product in cart slider
	// Xpath for Grey color Weighted Blanket Product Added In Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CLWTBLANKET-S-75x50']")
	private WebElement GreyWeightedBlanketProductAddedInCart;

	// Webelement for Grey color Weighted Blanket Product Added In Cart
	public WebElement greyWeightedBlanketProductAddedInCart() {
		return GreyWeightedBlanketProductAddedInCart;
	}

	// Xpath for Blushed Nude color Weighted Blanket Product Added In Cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BNWTBLANKET-S-75x50']")
	private WebElement BlushedNudeWeightedBlanketProductAddedInCart;

	// Webelement for Blushed Nude color Weighted Blanket Product Added In Cart
	public WebElement blushedNudeWeightedBlanketProductAddedInCart() {
		return BlushedNudeWeightedBlanketProductAddedInCart;
	}

	// Xpath for Midnight Blue Color Weighted Blanket product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-MBWTBLANKET-S-75x50']")
	private WebElement MidnightBlueWeightedBlanketProductAddedInCart;

	// Webelement for Midnight Blue Color Weighted Blanket product added in cart
	// slider
	public WebElement midnightBlueWeightedBlanketProductAddedInCart() {
		return MidnightBlueWeightedBlanketProductAddedInCart;
	}

	// Adjustable Pillow Products added in cart XPath
	// Adjustable Pillow Standard category Pack of one Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ADMFPILW-S-25x16']")
	private WebElement StandardCategoryAdjustablePillowPackOfOneProductAddedInCart;

	// Webelement for Adjustable Pillow Standard category Pack of one
	public WebElement standardCategoryAdjustablePillowPackOfOneProductAddedInCart() {
		return StandardCategoryAdjustablePillowPackOfOneProductAddedInCart;
	}

	// Adjustable Pillow Standard category Pack of Two Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ADMFPILWSET2-S-25x16']")
	private WebElement StandardCategoryAdjustablePillowPackOfTwoProductAddedInCart;

	// Webelement for Adjustable Pillow Standard category Pack of Two
	public WebElement standardCategoryAdjustablePillowPackOfTwoProductAddedInCart() {
		return StandardCategoryAdjustablePillowPackOfTwoProductAddedInCart;
	}

	// Baby products added in cart slider xpath
	// Baby Head Pillow Standard category Pack of One Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BBYHPILW-S-9x8']")
	private WebElement StandardCategoryBabyHeadPillowProductAddedInCart;

	// Webelement for Baby Head Pillow Standard category Pack of One Product
	public WebElement standardCategoryBabyHeadPillowProductAddedInCart() {
		return StandardCategoryBabyHeadPillowProductAddedInCart;
	}

	// Baby Bolster Pillow Standard category Pack of Two Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BBYBOLPILW2-S-18x7']")
	private WebElement StandardCategoryBabyBolsterPillowProductAddedInCart;

	// Webelement for Baby Head Pillow Standard category Pack of One Product
	public WebElement standardCategoryBabyBolsterPillowProductAddedInCart() {
		return StandardCategoryBabyBolsterPillowProductAddedInCart;
	}

	// Baby Comforter added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BBYCOMF-S-42x34']")
	private WebElement StandardCategoryBabyComforterProductAddedInCart;

	// Webelement for Baby Comforter Standard category
	public WebElement standardCategoryBabyComforterProductAddedInCart() {
		return StandardCategoryBabyComforterProductAddedInCart;
	}

	// Baby Crib Fitted Sheet added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BBYCRBSHEET-S-52x28']")
	private WebElement StandardCategoryPackOfOneBabyCribSheetProductAddedInCart;

	// Webelement for Baby Crib Fitted Sheet
	public WebElement standardCategoryPackOfOneBabyCribSheetProductAddedInCart() {
		return StandardCategoryPackOfOneBabyCribSheetProductAddedInCart;
	}

	// Nap Pillow Products added in cart XPath
	// Nap Pillow Standard category Pack of one Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-NAPILW-S-14x10']")
	private WebElement StandardCategoryNapPillowPackOfOneProductAddedInCart;

	// Webelement for Nap Pillow Standard category Pack of one
	public WebElement standardCategoryNapPillowPackOfOneProductAddedInCart() {
		return StandardCategoryNapPillowPackOfOneProductAddedInCart;
	}

	// Nap Pillow Standard category Pack of Two Product added in cart XPath
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-NAPILWSET2-S-14x10']")
	private WebElement StandardCategoryNapPillowPackOfTwoProductAddedInCart;

	// Webelement for Nap Pillow Standard category Pack of Two
	public WebElement standardCategoryNapPillowPackOfTwoProductAddedInCart() {
		return StandardCategoryNapPillowPackOfTwoProductAddedInCart;
	}

	// Hybrid Pillow Product is added in cart slider
	// Xpath for Standard category Hybrid pillow product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYBPILW-S-26X16']")
	private WebElement StandardCategoryHybridPillowProductAddedInCart;

	// Webelement for Standard category Hybrid pillow product added in cart slider
	public WebElement standardCategoryHybridPillowProductAddedInCart() {
		return StandardCategoryHybridPillowProductAddedInCart;
	}

	// Xpath for President category Hybrid pillow product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYBPILW-P-30x18']")
	private WebElement PresidentCategoryHybridPillowProductAddedInCart;

	// Webelement for President category Hybrid pillow product added in cart slider
	public WebElement presidentCategoryHybridPillowProductAddedInCart() {
		return PresidentCategoryHybridPillowProductAddedInCart;
	}

	// Slim Pillow Product is added in cart slider
	// Xpath for Standard category Hybrid pillow product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-SLMPILW-S-26X16']")
	private WebElement StandardCategorySlimPillowProductAddedInCart;

	// Webelement for Standard category Hybrid pillow product added in cart slider
	public WebElement standardCategorySlimPillowProductAddedInCart() {
		return StandardCategorySlimPillowProductAddedInCart;
	}

	// Xpath for President category Slim pillow product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-SLMPILW-P-30X18']")
	private WebElement PresidentCategorySlimPillowProductAddedInCart;

	// Webelement for President category Slim pillow product added in cart slider
	public WebElement presidentCategorySlimPillowProductAddedInCart() {
		return PresidentCategorySlimPillowProductAddedInCart;
	}

	// Cuddle pillow case product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DGRPILWCS-C-52x20']")
	private WebElement DolPhinGrayColorCuddlePillowCasePackofOneProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-TBLPILWCS-C-52x20']")
	private WebElement TwilightBlueColorCuddlePillowCasePackofOneProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BCRPILWCS-C-52x20']")
	private WebElement ButterScoutchCreamColorCuddlePillowCasePackofOneProductAddedInCart;

	// Webelement for Cuddle pillow case product added in cart slider
	public WebElement dolPhinGrayColorCuddlePillowCasePackofOneProductAddedInCart() {
		return DolPhinGrayColorCuddlePillowCasePackofOneProductAddedInCart;
	}

	public WebElement twilightBlueColorCuddlePillowCasePackofOneProductAddedInCart() {
		return TwilightBlueColorCuddlePillowCasePackofOneProductAddedInCart;
	}

	public WebElement butterScoutchCreamColorCuddlePillowCasePackofOneProductAddedInCart() {
		return ButterScoutchCreamColorCuddlePillowCasePackofOneProductAddedInCart;
	}

	// Xpath for Everyday bundle product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-EB-ORIG-78X72X8-CLPLW2-S-PROT-CFCOMF-90X100']")
	private WebElement EveryDayBundleKing78x72x8CoffeeColorProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-EB-ORIG-72X72X8-CLPLW2-S-PROT-COMF-90X100']")
	private WebElement EveryDayBundleKing72x72x8WhiteColorProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-EB-ORIG-72X72X8-CLPLW2-S-PROT-PKCOMF-90X100']")
	private WebElement EveryDayBundleKing72x72x8PinkColorProductAddedInCart;

	// Webelement for Everyday bundle product added in cart slider
	public WebElement everyDayBundleKing78x72x8CoffeeColorProductAddedInCart() {
		return EveryDayBundleKing78x72x8CoffeeColorProductAddedInCart;
	}

	public WebElement everyDayBundleKing72x72x8WhiteColorProductAddedInCart() {
		return EveryDayBundleKing72x72x8WhiteColorProductAddedInCart;
	}

	public WebElement everyDayBundleKing72x72x8PinkColorProductAddedInCart() {
		return EveryDayBundleKing72x72x8PinkColorProductAddedInCart;
	}

	// Xpath for Campus bundle product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CB-ORG-75X36X6-CLP-S-CFCOMF-90X60']")
	private WebElement CampusBundleSingle75X36X6CoffeeColorProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CB-ORG-78X36X6-CLP-S-CFCOMF-90X60']")
	private WebElement CampusBundleSingle78X36X6CoffeeColorProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-CB-ORG-72X36X6-CLP-S-CFCOMF-90X60']")
	private WebElement CampusBundleSingle72X36X6CoffeeColorProductAddedInCart;

	// Webelement for Campus bundle product added in cart slider
	public WebElement campusBundleSingle75X36X6CoffeeColorProductAddedInCart() {
		return CampusBundleSingle75X36X6CoffeeColorProductAddedInCart;
	}

	public WebElement campusBundleSingle78X36X6CoffeeColorProductAddedInCart() {
		return CampusBundleSingle78X36X6CoffeeColorProductAddedInCart;
	}

	public WebElement campusBundleSingle72X36X6CoffeeColorProductAddedInCart() {
		return CampusBundleSingle72X36X6CoffeeColorProductAddedInCart;
	}

	// Xpath for Baby Starter bundle product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BYSRP-MTHPCOMFCRSBLP-52X28X4']")
	private WebElement BabyStarterBundleSingle52X28X4ProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BYSRP-MTHPCOMFCRSBLP-48X24X4']")
	private WebElement BabyStarterBundleSingle48X24X4ProductAddedInCart;

	// Webelement for Baby Starter bundle product added in cart slider
	public WebElement babyStarterBundleSingle52X28X4ProductAddedInCart() {
		return BabyStarterBundleSingle52X28X4ProductAddedInCart;
	}

	public WebElement babyStarterBundleSingle48X24X4ProductAddedInCart() {
		return BabyStarterBundleSingle48X24X4ProductAddedInCart;
	}

	// Xpath for Shop Now button in cart slider
	@FindBy(xpath = "(//p[@class='return-to-shop']//a[@href='/products/'])")
	private WebElement ShopNowButtonInCartSlider;

	// Webelement for Shop Now button in cart slider
	public WebElement shopNowButtonInCartSlider() {
		return ShopNowButtonInCartSlider;
	}

	// Fitted Bed Sheet product in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DGRFTDSHEET-K-78x72']")
	private WebElement DolPhinGrayColorKingFittedBedSheetProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-TBLFTDSHEET-K-78x72']")
	private WebElement TwilightBlueColorKingFittedBedSheetProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BCRFTDSHEET-K-78x72']")
	private WebElement ButterScoutchCreamColorKingFittedBedSheetProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DGRFTDSHEET-Q-78x60']")
	private WebElement DolPhinGrayColorQueenFittedBedSheetProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-TBLFTDSHEET-Q-78x60']")
	private WebElement TwilightBlueColorQueenFittedBedSheetProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BCRFTDSHEET-Q-78x60']")
	private WebElement ButterScoutchCreamColorQueenFittedBedSheetProductAddedInCart;

	// Webelement for Fitted Bed Sheet product
	public WebElement dolPhinGrayColorKingFittedBedSheetProductAddedInCart() {
		return DolPhinGrayColorKingFittedBedSheetProductAddedInCart;
	}

	public WebElement twilightBlueColorKingFittedBedSheetProductAddedInCart() {
		return TwilightBlueColorKingFittedBedSheetProductAddedInCart;
	}

	public WebElement butterScoutchCreamColorKingFittedBedSheetProductAddedInCart() {
		return ButterScoutchCreamColorKingFittedBedSheetProductAddedInCart;
	}

	public WebElement dolPhinGrayColorQueenFittedBedSheetProductAddedInCart() {
		return DolPhinGrayColorQueenFittedBedSheetProductAddedInCart;
	}

	public WebElement twilightBlueColorQueenFittedBedSheetProductAddedInCart() {
		return TwilightBlueColorQueenFittedBedSheetProductAddedInCart;
	}

	public WebElement butterScoutchCreamColorQueenFittedBedSheetProductAddedInCart() {
		return ButterScoutchCreamColorQueenFittedBedSheetProductAddedInCart;
	}

	// Cross selling section for Fitted Bed Sheet Product in Cart slider
	// Xpath for category Type field of Fitted Bed Sheet cross selling product
	// section
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='fitted_bedsheet']//div[@data-name='scategory']")
	private WebElement CrossSellFittedBedSheetCategoryFieldInCartSlider;

	// Webelement option for category Type field of Fitted Bed Sheet cross selling
	// product section
	public WebElement crossSellFittedBedSheetCategoryFieldInCartSlider() {
		return CrossSellFittedBedSheetCategoryFieldInCartSlider;
	}

	// Xpath for different category field of Fitted Bed Sheet cross selling product
	// section
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='fitted_bedsheet']//li[@data-value='Queen']")
	private WebElement CrossSellFittedBedSheetQueenCategoryFieldInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='fitted_bedsheet']//li[@data-value='King']")
	private WebElement CrossSellFittedBedSheetKingCategoryFieldInCartSlider;

	// Webelement option for category of Fitted Bed Sheet cross selling product
	// section
	public WebElement crossSellFittedBedSheetQueenCategoryFieldInCartSlider() {
		return CrossSellFittedBedSheetQueenCategoryFieldInCartSlider;
	}

	public WebElement crossSellFittedBedSheetKingCategoryFieldInCartSlider() {
		return CrossSellFittedBedSheetKingCategoryFieldInCartSlider;
	}

	// Xpath for Different Color Option for fitted bed sheet in cross selling
	// product section
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='fitted_bedsheet']//li[@data-value='dolphingrey']")
	private WebElement CrossSellFittedBedSheetDolphinGrayColorInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='fitted_bedsheet']//li[@data-value='twilightblue']")
	private WebElement CrossSellFittedBedSheetTwilightBlueColorInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='fitted_bedsheet']//li[@data-value='butterscotchcream']")
	private WebElement CrossSellFittedBedSheetButterScoutchCreamColorInCartSlider;

	// Webelement for Different Color Option for fitted bed sheet in cross selling
	// product section
	public WebElement crossSellFittedBedSheetDolphinGrayColorInCartSlider() {
		return CrossSellFittedBedSheetDolphinGrayColorInCartSlider;
	}

	public WebElement crossSellFittedBedSheetTwilightBlueColorInCartSlider() {
		return CrossSellFittedBedSheetTwilightBlueColorInCartSlider;
	}

	public WebElement crossSellFittedBedSheetButterScoutchCreamColorInCartSlider() {
		return CrossSellFittedBedSheetButterScoutchCreamColorInCartSlider;
	}

	// Xpath for Add to cart button for different Fitted Bed sheet product variation
	// in cross selling product section in cart
	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-DGRFTDSHEET-K-78x72']")
	private WebElement CrossSellAddToCartButtonForKingFittedBedSheetDolphinGrayInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-TBLFTDSHEET-K-78x72']")
	private WebElement CrossSellAddToCartButtonForKingFittedBedSheetTwilightBlueInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-BCRFTDSHEET-K-78x72']")
	private WebElement CrossSellAddToCartButtonForKingFittedBedSheetButterScoutchCreamInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-DGRFTDSHEET-Q-78x60']")
	private WebElement CrossSellAddToCartButtonForQueenFittedBedSheetDolphinGrayInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-DGRFTDSHEET-Q-72x60']")
	private WebElement CrossSellAddToCartButtonForQueen72x60FittedBedSheetDolphinGrayInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-TBLFTDSHEET-Q-78x60']")
	private WebElement CrossSellAddToCartButtonForQueenFittedBedSheetTwilightBlueInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-BCRFTDSHEET-Q-78x60']")
	private WebElement CrossSellAddToCartButtonForQueenFittedBedSheetButterScoutchCreamInCartSlider;

	// Webelement for Add to cart button for different Fitted Bed sheet product
	// variation in cross selling product section in cart
	public WebElement crossSellAddToCartButtonForKingFittedBedSheetDolphinGrayInCartSlider() {
		return CrossSellAddToCartButtonForKingFittedBedSheetDolphinGrayInCartSlider;
	}

	public WebElement crossSellAddToCartButtonForKingFittedBedSheetTwilightBlueInCartSlider() {
		return CrossSellAddToCartButtonForKingFittedBedSheetTwilightBlueInCartSlider;
	}

	public WebElement crossSellAddToCartButtonForKingFittedBedSheetButterScoutchCreamInCartSlider() {
		return CrossSellAddToCartButtonForKingFittedBedSheetButterScoutchCreamInCartSlider;
	}

	public WebElement crossSellAddToCartButtonForQueenFittedBedSheetDolphinGrayInCartSlider() {
		return CrossSellAddToCartButtonForQueenFittedBedSheetDolphinGrayInCartSlider;
	}

	public WebElement crossSellAddToCartButtonForQueen72x60FittedBedSheetDolphinGrayInCartSlider() {
		return CrossSellAddToCartButtonForQueen72x60FittedBedSheetDolphinGrayInCartSlider;
	}

	public WebElement crossSellAddToCartButtonForQueenFittedBedSheetTwilightBlueInCartSlider() {
		return CrossSellAddToCartButtonForQueenFittedBedSheetTwilightBlueInCartSlider;
	}

	public WebElement crossSellAddToCartButtonForQueenFittedBedSheetButterScoutchCreamInCartSlider() {
		return CrossSellAddToCartButtonForQueenFittedBedSheetButterScoutchCreamInCartSlider;
	}

	// Cross selling section for Comforter in cart slider
	// Xpath for category Type field of comforter cross selling product section
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='comforter']//div[@data-name='scategory'])")
	private WebElement CrossSellComforterCategoryFieldInCartSlider;

	// Webelement option for category Type field of comforter cross selling product
	// section
	public WebElement crossSellComforterCategoryFieldInCartSlider() {
		return CrossSellComforterCategoryFieldInCartSlider;
	}

	// Xpath for Double category of comforter cross selling product section
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='comforter']//span[text()='Double'])")
	private WebElement CrossSellDoubleCategoryComforterInCartSlider;

	// Webelement option for Double category of comforter cross selling product
	// section
	public WebElement crossSellDoubleCategoryComforterInCartSlider() {
		return CrossSellDoubleCategoryComforterInCartSlider;
	}

	// Xpath for Color options of Comforter on cross selling product section
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='comforter']//li[@data-value='coffee'])")
	private WebElement CrossSellComforterCoffeeColorInCartSlider;

	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='comforter']//li[@data-value='pink'])")
	private WebElement CrossSellComforterPinkColorInCartSlider;

	// Webelement for Color options of Comforter on cross selling product section
	public WebElement crossSellComforterCoffeeColorInCartSlider() {
		return CrossSellComforterCoffeeColorInCartSlider;
	}

	public WebElement crossSellComforterPinkColorInCartSlider() {
		return CrossSellComforterPinkColorInCartSlider;
	}

	// Xpath for Add to cart of Double category pink color comforter cross selling
	// product
	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-PKCOMF-D-90x100']")
	private WebElement CrossSellDoubleCategoryPinkComforterInCartSlider;

	// Webelement option for Add to cart of Double category pink color comforter
	// cross selling product
	public WebElement crossSellDoubleCategoryPinkComforterInCartSlider() {
		return CrossSellDoubleCategoryPinkComforterInCartSlider;
	}

	// Xpath for Add to cart of Double category Coffee color comforter cross selling
	// product
	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-CFCOMF-D-90x100']")
	private WebElement CrossSellAddToCartButtonForDoubleCategoryCoffeeComforterInCartSlider;

	// Webelement option for Add to cart of Double category Coffee color comforter
	// cross selling product
	public WebElement crossSellAddToCartButtonForDoubleCategoryCoffeeComforterInCartSlider() {
		return CrossSellAddToCartButtonForDoubleCategoryCoffeeComforterInCartSlider;
	}

	// SoftTouchMemory foam pillow product in cross selling product section in cart
	// slider
	// Xpath for category field for Memory foam pillow
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='pillow']//div[@data-name='scategory'])")
	private WebElement CrossSellSoftTouchMemoryPillowCategoryFieldInCartSlider;

	// Webelement for category field for Original mattress
	public WebElement crossSellSoftTouchMemoryPillowCategoryFieldInCartSlider() {
		return CrossSellSoftTouchMemoryPillowCategoryFieldInCartSlider;
	}

	// Xpath for category options for Memory foam pillow
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='pillow']//li[@data-value='Standard'])")
	private WebElement CrossSellSoftTouchMemoryPillowStandardCategoryInCartSlider;

	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='pillow']//li[@data-value='President'])")
	private WebElement CrossSellSoftTouchMemoryPillowPresidentCategoryInCartSlider;

	// Webelement for category options for Memory foam pillow
	public WebElement CrossSellSoftTouchMemoryPillowStandardCategoryInCartSlider() {
		return CrossSellSoftTouchMemoryPillowStandardCategoryInCartSlider;
	}

	public WebElement crossSellSoftTouchMemoryPillowPresidentCategoryInCartSlider() {
		return CrossSellSoftTouchMemoryPillowPresidentCategoryInCartSlider;
	}

	// Xpath for Pack field for Memory foam pillow
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='pillow']//div[@data-name='pack'])")
	private WebElement CrossSellSoftTouchMemoryPillowPackFieldInCartSlider;

	// Webelement for Pack field for Memory foam pillow
	public WebElement crossSellSoftTouchMemoryPillowPackFieldInCartSlider() {
		return CrossSellSoftTouchMemoryPillowPackFieldInCartSlider;
	}

	// Xpath for different Pack options for Memory pillow when President category is
	// selected
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='pillow']//li[@value='pillow-2'])")
	private WebElement CrossSellSoftTouchMemoryPillowPackOfTwoInCartSlider;

	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='pillow']//li[@value='pillow-4'])")
	private WebElement CrossSellSoftTouchMemoryPillowPackOfFourInCartSlider;

	// Webelement for different Pack options for Memory pillow when President
	// category is selected
	public WebElement crossSellSoftTouchMemoryPillowPackOfTwoInCartSlider() {
		return CrossSellSoftTouchMemoryPillowPackOfTwoInCartSlider;
	}

	public WebElement crossSellSoftTouchMemoryPillowPackOfFourInCartSlider() {
		return CrossSellSoftTouchMemoryPillowPackOfFourInCartSlider;
	}

	// Xpath for Add to cart button for Memory foam when standard category is
	// selected and Pack is four
	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-MFPILWSET4-BAM-S-25x16']")
	private WebElement CrossSellSoftTouchAddToCartStandardMemoryPillowPackOfFourInCartSlider;

	// Webelement for Add to cart button for Memory foam when President category is
	// selected and Pack is two
	public WebElement crossSellSoftTouchAddToCartStandardMemoryPillowPackOfFourInCartSlider() {
		return CrossSellSoftTouchAddToCartStandardMemoryPillowPackOfFourInCartSlider;
	}

	// Xpath for Add to cart button for Memory foam when President category is
	// selected and Pack is two
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@id='slideout_cart']//span[@data-sku='SC-MFPILWSET2-P-28x18']")
	private WebElement CrossSellSoftTouchAddToCartPresidentMemoryPillowPackTwoInCartSlider;

	// Webelement for Add to cart button for Memory foam when President category is
	// selected and Pack is two
	public WebElement crossSellSoftTouchAddToCartPresidentMemoryPillowPackTwoInCartSlider() {
		return CrossSellSoftTouchAddToCartPresidentMemoryPillowPackTwoInCartSlider;
	}

	// Cross selling cloud pillow section in cart slider
	// Xpath for category field of cloud pillow cross selling product section
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//div[@data-name='scategory'])")
	private WebElement CrossSellCartCloudPillowCategoryFieldInCartSlider;

	// Webelement for category field of cloud pillow cross selling product section
	public WebElement crossSellCartCloudPillowCategoryFieldInCartSlider() {
		return CrossSellCartCloudPillowCategoryFieldInCartSlider;
	}

	// Xpath for President category of cloud pillow cross selling product section
	@FindBy(xpath = "(//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//li[@data-value='President'])")
	private WebElement CrossSellPresidentCategoryCloudPillowInCartSlider;

	// Webelement option for President category of cloud pillow cross selling
	// product section
	public WebElement crossSellPresidentCategoryCloudPillowInCartSlider() {
		return CrossSellPresidentCategoryCloudPillowInCartSlider;
	}

	// Xpath for pack field of cloud pillow in cross selling product section
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//div[@data-name='pack']")
	private WebElement CrossSellPackFieldOfCloudPillowInCartSlider;

	// Webelement option for pack field of cloud pillow in cross selling product
	// section
	public WebElement crossSellPackFieldOfCloudPillowInCartSlider() {
		return CrossSellPackFieldOfCloudPillowInCartSlider;
	}

	// Xpath for pack field of cloud pillow in cross selling product section
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//li[text()='Pack of 2']")
	private WebElement CrossSellPackTwoOfCloudPillowInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//li[text()='Pack of 4']")
	private WebElement CrossSellPackFourOfCloudPillowInCartSlider;

	// Webelement option for pack field of cloud pillow in cross selling product
	// section
	public WebElement crossSellPackTwoOfCloudPillowInCartSlider() {
		return CrossSellPackTwoOfCloudPillowInCartSlider;
	}

	public WebElement crossSellPackFourOfCloudPillowInCartSlider() {
		return CrossSellPackFourOfCloudPillowInCartSlider;
	}

	// Xpath for Add to cart button of cloud pillow in cross selling product section
	// of cart slider when category is President
	@FindBy(xpath = "//div[@id='slideout_cart']//span[@data-sku='SC-CLPILWSET4-P-32x20']")
	private WebElement CrossSellAddToCartButtonForPresidentPackOfFourCloudPillowInCartSlider;

	// Webelement option for pack field of cloud pillow in cross selling product
	// section
	public WebElement crossSellAddToCartButtonForPresidentPackOfFourCloudPillowInCartSlider() {
		return CrossSellAddToCartButtonForPresidentPackOfFourCloudPillowInCartSlider;
	}

	// Xpath for increment and decrement product quantity icon of cloud pillow in
	// cross selling product section
	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//input[@class='plus']")
	private WebElement CrossSellCloudPillowIncrementQuantityInCartSlider;

	@FindBy(xpath = "//div[@id='slideout_cart']//div[@data-producttype='cloud_pillow']//input[@class='minus']")
	private WebElement CrossSellCartPillowDecreaseQuantityInCartSlider;

	// Webelement option for increment and decrement product quantity icon of cloud
	// pillow in cross selling product section
	public WebElement crossSellCloudPillowIncrementQuantityInCartSlider() {
		return CrossSellCloudPillowIncrementQuantityInCartSlider;
	}

	public WebElement crossSellCartPillowDecreaseQuantityInCartSlider() {
		return CrossSellCartPillowDecreaseQuantityInCartSlider;
	}

	// Xpath for different mattress products added in cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='89654']")
	private WebElement HybridLatexMattressProductAddedInCartSlider;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='629264']")
	private WebElement UltimaMattressProductAddedInCartSlider;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='629227']")
	private WebElement OriginalMattressProductAddedInCartSlider;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='2172134']")
	private WebElement OriginalSpringMattressProductAddedInCartSlider;

	// Webelement option for increment and decrement product quantity icon of cloud
	// pillow in cross selling product section
	public WebElement hybridLatexMattressProductAddedInCartSlider() {
		return HybridLatexMattressProductAddedInCartSlider;
	}

	public WebElement ultimaMattressProductAddedInCartSlider() {
		return UltimaMattressProductAddedInCartSlider;
	}

	public WebElement originalMattressProductAddedInCartSlider() {
		return OriginalMattressProductAddedInCartSlider;
	}

	public WebElement originalSpringMattressProductAddedInCartSlider() {
		return OriginalSpringMattressProductAddedInCartSlider;
	}

	// Xpath for different Pillow products added in cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='214583']")
	private WebElement CloudPillowProductAddedInCartSlider;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='2096307']")
	private WebElement HybridPillowProductAddedInCartSlider;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='98749']")
	private WebElement SoftTouchMemoryFoamPillowProductAddedInCartSlider;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='2096528']")
	private WebElement CoolTecMemoryFoamPillowProductAddedInCartSlider;

	// Webelement for different Pillow products added in cart
	public WebElement cloudPillowProductAddedInCartSlider() {
		return CloudPillowProductAddedInCartSlider;
	}

	public WebElement hybridPillowProductAddedInCartSlider() {
		return HybridPillowProductAddedInCartSlider;
	}

	public WebElement softTouchMemoryFoamPillowProductAddedInCartSlider() {
		return SoftTouchMemoryFoamPillowProductAddedInCartSlider;
	}

	public WebElement coolTecMemoryFoamPillowProductAddedInCartSlider() {
		return CoolTecMemoryFoamPillowProductAddedInCartSlider;
	}

	// Duvet Cover product in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DGRDVTCOVER-D-90x100']")
	private WebElement DolPhinGrayColorDoubleDuvetCoverProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-TBLDVTCOVER-D-90x100']")
	private WebElement TwilightBlueColorDoubleDuvetCoverProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-BCRDVTCOVER-D-90x100']")
	private WebElement ButterScoutchCreamColorDoubleDuvetCoverProductAddedInCart;

	// Webelement for Fitted Bed Sheet product
	public WebElement dolPhinGrayColorDoubleDuvetCoverProductAddedInCart() {
		return DolPhinGrayColorDoubleDuvetCoverProductAddedInCart;
	}

	public WebElement twilightBlueColorDoubleDuvetCoverProductAddedInCart() {
		return TwilightBlueColorDoubleDuvetCoverProductAddedInCart;
	}

	public WebElement butterScoutchCreamColorDoubleDuvetCoverProductAddedInCart() {
		return ButterScoutchCreamColorDoubleDuvetCoverProductAddedInCart;
	}

	// Protector Products added in cart
	// Xpath for Single Category Protector product is added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-PROT-S-72x36']")
	private WebElement SingleCategoryProtector72x36ProductAddedInCart;

	// Webelement for Single Category Protector product is added in cart slider
	public WebElement singleCategoryProtector72x36ProductAddedInCart() {
		return SingleCategoryProtector72x36ProductAddedInCart;
	}

	// Xpath for add to cart button
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ULTM-Q-78x60x8']")
	private WebElement QueenCategoryUltimaMattress78x60x8ProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-ORIG-Q-78x60x6']")
	private WebElement QueenCategoryOriginalMattress78x60x6ProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-HYB-LATEX-Q-78x60x6']")
	private WebElement QueenCategoryLatexMattress78x60x6ProductAddedInCart;

	// Webelement for add to cart button
	public WebElement queenCategoryUltimaMattress78x60x8ProductAddedInCart() {
		return QueenCategoryUltimaMattress78x60x8ProductAddedInCart;
	}

	public WebElement queenCategoryOriginalMattress78x60x6ProductAddedInCart() {
		return QueenCategoryOriginalMattress78x60x6ProductAddedInCart;
	}

	public WebElement queenCategoryLatexMattress78x60x6ProductAddedInCart() {
		return QueenCategoryLatexMattress78x60x6ProductAddedInCart;
	}

	// Satin Pillow case product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-WNRDSTNPLWCS-S-28x18']")
	private WebElement WineRedColorSatinPillowcaseProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-DSPLSTNPLWCS-S-28x18']")
	private WebElement DuskPearlColorSatinPillowcaseProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-OLGRSTNPLWCS-S-28x18']")
	private WebElement OliveGreenColorSatinPillowcaseProductAddedInCart;

	// Webelement for add to cart button
	public WebElement wineRedColorSatinPillowcaseProductAddedInCart() {
		return WineRedColorSatinPillowcaseProductAddedInCart;
	}

	public WebElement duskPearlColorSatinPillowcaseProductAddedInCart() {
		return DuskPearlColorSatinPillowcaseProductAddedInCart;
	}

	public WebElement oliveGreenColorSatinPillowcaseProductAddedInCart() {
		return OliveGreenColorSatinPillowcaseProductAddedInCart;
	}

	// Sleep Gummies product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-SLPGUMMIES-STD']")
	private WebElement SleepGummiesProductAddedInCart;

	// Webelement for Sleep Gummies product added in cart slider
	public WebElement sleepGummiesProductAddedInCart() {
		return SleepGummiesProductAddedInCart;
	}

	// Couple Pillow product added in cart slider
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-LHCUPLPILW-SP-S-26x16']")
	private WebElement LeftHandCouplePillowProductAddedInCart;

	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_sku='SC-RHCUPLPILW-SP-S-26x16']")
	private WebElement RightHandCouplePillowProductAddedInCart;

	// Webelement for Sleep Gummies product added in cart slider
	public WebElement leftHandCouplePillowProductAddedInCart() {
		return LeftHandCouplePillowProductAddedInCart;
	}

	public WebElement rightHandCouplePillowProductAddedInCart() {
		return RightHandCouplePillowProductAddedInCart;
	}

	// Xpath for petbed products added in cart
	@FindBy(xpath = "//div[@class='cart_item_mid']//div[@data-product_id='750272']")
	private WebElement PetBedProductAddedInCartSlider;

	// Webelement option for petbed products
	public WebElement petBedProductAddedInCartSlider() {
		return PetBedProductAddedInCartSlider;
	}

	public CartSlider(RemoteWebDriver driver) throws Exception {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

}
