package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Header {

	static RemoteWebDriver driver;

	public Header(RemoteWebDriver driver) throws Exception {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Xpath for login Menu links
	@FindBy(xpath = "(//div[@class='headerMenuSVGIcon']//a[@href='/login'])[2]")
	private WebElement LoginIcon;

	// Webelement for login Menu links
	public WebElement loginIcon() {
		return LoginIcon;
	}

	// Mattress and its products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[text()='Mattress'])")
	private WebElement MattressHeader;

	// @FindBy(xpath = "//a[text()='Original Mattress – 6″']")
	@FindBy(xpath = "(//a[@href='/mattresses/original-mattress/'])[1]")
	private WebElement OriginalMattressMenu;

	// @FindBy(xpath = "//a[text()='Latex Mattress – 7″']")
	@FindBy(xpath = "(//a[@href='/mattresses/latex-mattress/'])[1]")
	private WebElement HybridLatexMattressMenu;

	// @FindBy(xpath = "//a[text()='Plus Mattress – 8″ & 10″']")
	@FindBy(xpath = "(//a[@href='/mattresses/plus-mattress/'])[1]")
	private WebElement UltimaMattressMenu;

	@FindBy(xpath = "(//a[@href='/baby-bedding-sets-and-pillows/baby-mattress/'])[1]")
	private WebElement BabyMattressMenu;

	@FindBy(xpath = "(//h3[text()='Compare all mattresses'])")
	private WebElement CompareMattressMenu;

	@FindBy(xpath = "(//a[@href='/mattress-recommender/'])[1]")
	private WebElement MattressRecommenderMenu;

	@FindBy(xpath = "(//a[@href='/mattresses/original-spring-mattress/'])[1]")
	private WebElement OriginalSpringMattressMenu;

	// Webelements for Mattress and its products dropdown links
	public WebElement mattressHeader() {
		return MattressHeader;
	}

	public WebElement originalMattressMenu() {
		return OriginalMattressMenu;
	}

	public WebElement hybridLatexMattressMenu() {
		return HybridLatexMattressMenu;
	}

	public WebElement ultimaMattressMenu() {
		return UltimaMattressMenu;
	}

	public WebElement babyMattressMenu() {
		return BabyMattressMenu;
	}

	public WebElement compareMattressMenu() {
		return CompareMattressMenu;
	}

	public WebElement mattressRecommenderMenu() {
		return MattressRecommenderMenu;
	}

	public WebElement originalSpringMattressMenu() {
		return OriginalSpringMattressMenu;
	}

	// Xpath for Track order option in header
	@FindBy(xpath = "(//a[@href='/track-order/'])")
	private WebElement TrackOrder;

	// Webelements for Track order option in header
	public WebElement trackOrder() {
		return TrackOrder;
	}

	// Xpath for Review option in header
	@FindBy(xpath = "(//div[text()='More'])")
	private WebElement More;

	@FindBy(xpath = "(//a[@href='/reviews/'])")
	private WebElement Review;

	// Webelements for Review option in header
	public WebElement more() {
		return More;
	}

	public WebElement review() {
		return Review;
	}

	// Xpath for FAQ option in header
	@FindBy(xpath = "(//a[@href='/faq/'])[7]")
	private WebElement Faq;

	// Webelements for FAQ option in header
	public WebElement faq() {
		return Faq;
	}

	// Xpath for Contact option in header
	@FindBy(xpath = "(//a[@href='/contact/'])[7]")
	private WebElement Contact;

	// Webelements for Contact option in header
	public WebElement contact() {
		return Contact;
	}

	// Xpath for cart icon
	@FindBy(xpath = "(//div[@class='headerMenuSVGIcon crticn'])[2]")
	private WebElement CartIcon;

	// Webelement Xpath for cart icon
	public WebElement cartIcon() {
		return CartIcon;
	}

	// Xpath for Bedding and its products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[text()='Bedding'])")
	private WebElement BeddingMenu;

	@FindBy(xpath = "(//a[@href='/bedding/mattress-protector/'])[1]")
	private WebElement ProtectorMenu;

	@FindBy(xpath = "(//a[@href='/bedding/reversible-comforter/?attribute_season=all%20season'])[1]")
	private WebElement ComforterMenu;

	@FindBy(xpath = "(//a[@href='/bedding/weighted-blanket/'])[1]")
	private WebElement WeightedBlanketMenu;

	@FindBy(xpath = "(//a[@href='/bedding/muslin-throw/'])[1]")
	private WebElement MuslinMenu;

	@FindBy(xpath = "(//a[@href='/bedding/knitted-throw/'])[1]")
	private WebElement KnittedThrowMenu;

	@FindBy(xpath = "(//a[@href='/bedding/luxe-comforter/'])[1]")
	private WebElement LuxeComforterMenu;

	@FindBy(xpath = "//h3[text()='View all bedding']")
	private WebElement ViewAllBeddingmenu;

	// Webelements for Bedding products dropdown links
	public WebElement beddingMenu() {
		return BeddingMenu;
	}

	public WebElement protectorMenu() {
		return ProtectorMenu;
	}

	public WebElement comforterMenu() {
		return ComforterMenu;
	}

	public WebElement weightedBlanketMenu() {
		return WeightedBlanketMenu;
	}

	public WebElement muslinMenu() {
		return MuslinMenu;
	}

	public WebElement knittedThrowMenu() {
		return KnittedThrowMenu;
	}

	public WebElement luxeComforterMenu() {
		return LuxeComforterMenu;
	}

	public WebElement viewAllBeddingmenu() {
		return ViewAllBeddingmenu;
	}

	// Xpath for Pillow products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[text()='Pillows'])")
	private WebElement PillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/cooltec-memory-foam-pillow/'])[1]")
	private WebElement CoolTecMemoryFoamMenu;

	@FindBy(xpath = "(//a[@href='/pillow/memory-foam-pillow/'])[1]")
	private WebElement SoftTouchMemoryFoamMenu;

	@FindBy(xpath = "(//a[@href='/pillow/cloud-microfiber-pillow/'])[1]")
	private WebElement CloudPillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/pregnancy-body-pillow/'])[1]")
	private WebElement CuddlePillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/slim-pillow/'])[1]")
	private WebElement SlimPillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/hybrid-pillow/'])[1]")
	private WebElement HybridPillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/pillow-cases/'])[1]")
	private WebElement PillowCaseMenu;

	@FindBy(xpath = "(//a[@href='/pillow/contour-softtouch-memory-foam-pillow/'])[1]")
	private WebElement ContourSoftTouchMemoryFoamPillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/contour-cooltec-memory-foam-pillow/'])[1]")
	private WebElement ContourCoolTecMemoryFoamPillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/nap-pillow/'])[1]")
	private WebElement NapPillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/adjustable-foam-pillow/'])[1]")
	private WebElement AdjustablePillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow/couple-pillow/'])[1]")
	private WebElement CouplePillowMenu;

	@FindBy(xpath = "(//a[@href='/pillow-recommender/'])")
	private WebElement PillowRecommenderMenu;

	// Webelements for Pillow products dropdown links
	public WebElement pillowMenu() {
		return PillowMenu;
	}

	public WebElement contourSoftTouchMemoryFoamPillowMenu() {
		return ContourSoftTouchMemoryFoamPillowMenu;
	}

	public WebElement contourCoolTecMemoryFoamPillowMenu() {
		return ContourCoolTecMemoryFoamPillowMenu;
	}

	public WebElement coolTecMemoryFoamMenu() {
		return CoolTecMemoryFoamMenu;
	}

	public WebElement softTouchMemoryFoamMenu() {
		return SoftTouchMemoryFoamMenu;
	}

	public WebElement cloudPillowMenu() {
		return CloudPillowMenu;
	}

	public WebElement slimPillowMenu() {
		return SlimPillowMenu;
	}

	public WebElement hybridPillowMenu() {
		return HybridPillowMenu;
	}

	public WebElement pillowCaseMenu() {
		return PillowCaseMenu;
	}

	public WebElement cuddlePillowMenu() {
		return CuddlePillowMenu;
	}

	public WebElement napPillowMenu() {
		return NapPillowMenu;
	}

	public WebElement couplePillowMenu() {
		return CouplePillowMenu;
	}

	public WebElement adjustablePillowMenu() {
		return AdjustablePillowMenu;
	}

	public WebElement pillowRecommenderMenu() {
		return PillowRecommenderMenu;
	}

	// Xpath for Bed products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[text()='Bed'])")
	private WebElement BedMenu;

	@FindBy(xpath = "(//a[@href='/bed/ohayo-bed/'])[1]")
	private WebElement OhayoBedMenu;

	@FindBy(xpath = "//ul[@class='sub-menu']//a[text()='Metal Bed Frame']")
	private WebElement MetalBedFrameMenu;

	@FindBy(xpath = "(//a[@href='/bed/ohayo-day-bed/'])[1]")
	private WebElement OhayoDayBedMenu;

	@FindBy(xpath = "(//a[@href='/bed/ohayo-bed-tray/'])[1]")
	private WebElement OhayoBedTrayMenu;

	@FindBy(xpath = "//h3[text()='Pet Bed - Original']")
	private WebElement PetBedMenu;

	@FindBy(xpath = "//h3[text()='View all beds']")
	private WebElement ShopAllBedsMenu;

	// Webelements for Bed products dropdown links
	public WebElement bedMenu() {
		return BedMenu;
	}

	public WebElement ohayoBedMenu() {
		return OhayoBedMenu;
	}

	public WebElement metalBedFrameMenu() {
		return MetalBedFrameMenu;
	}

	public WebElement ohayoDayBedMenu() {
		return OhayoDayBedMenu;
	}

	public WebElement ohayoBedTrayMenu() {
		return OhayoBedTrayMenu;
	}

	public WebElement petBedMenu() {
		return PetBedMenu;
	}

	public WebElement shopAllBedsMenu() {
		return ShopAllBedsMenu;
	}

	// Xpath for Baby products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[text()='Baby Range'])")
	private WebElement BabyMenu;

	@FindBy(xpath = "//h3[text()='Baby Head Pillow']")
	private WebElement BabyHeadPillowMenu;

	@FindBy(xpath = "//h3[text()='Baby Bolster Pillow']")
	private WebElement BabyBolsterPillowMenu;

	@FindBy(xpath = "//h3[text()='Baby Super Soft Comforter']")
	private WebElement BabyComforterMenu;

	@FindBy(xpath = "//h3[text()='Baby Crib Fitted Sheet']")
	private WebElement BabyCribSheetMenu;

	@FindBy(xpath = "//h3[text()='View all baby products']")
	private WebElement ShopAllBabyRangMenu;

	// Webelements for Baby products dropdown links
	public WebElement babyMenu() {
		return BabyMenu;
	}

	public WebElement babyHeadPillowMenu() {
		return BabyHeadPillowMenu;
	}

	public WebElement babyBolsterPillowMenu() {
		return BabyBolsterPillowMenu;
	}

	public WebElement babyComforterMenu() {
		return BabyComforterMenu;
	}

	public WebElement babyCribSheetMenu() {
		return BabyCribSheetMenu;
	}

	public WebElement shopAllBabyRangMenu() {
		return ShopAllBabyRangMenu;
	}

	// Xpath for Baby products dropdown links
	@FindBy(xpath = "(//a[text()='Supportive Pillows'])[1]")
	private WebElement SupportivePillowMenu;

	@FindBy(xpath = "(//a[text()='Luxury Pillows'])[1]")
	private WebElement LuxuryPillowMenu;

	@FindBy(xpath = "(//a[text()='CoolTec™ Pillows'])[1]")
	private WebElement CoolTecPillowMenu;

	@FindBy(xpath = "(//a[text()='On The Move Pillow'])[1]")
	private WebElement OnTheMovePillowMenu;

	// Webelements for Baby products dropdown links
	public WebElement supportivePillowMenu() {
		return SupportivePillowMenu;
	}

	public WebElement luxuryPillowMenu() {
		return LuxuryPillowMenu;
	}

	public WebElement coolTecPillowMenu() {
		return CoolTecPillowMenu;
	}

	public WebElement onTheMovePillowMenu() {
		return OnTheMovePillowMenu;
	}

	// Xpath for Land and MYAccount xpath section
	@FindBy(xpath = "//div[@class='desktop_header']//div[3]")
	private WebElement BannerDiscountText;

	@FindBy(xpath = "//a[text()='My Account']")
	private WebElement MyAccount;

	// Webelement for LandTxt and myaccount link
	public WebElement bannerDiscountText() {
		return BannerDiscountText;
	}

	public WebElement myAccount() {
		return MyAccount;
	}

	// Xpath for DogBed products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[6])")
	private WebElement DogBedMenu;

	@FindBy(xpath = "(//a[@href='/bed/dog-beds/?attribute_scategory=original'])[1]")
	private WebElement DogBedOriginalMenu;

	@FindBy(xpath = "(//a[@href='/bed/dog-beds/?attribute_scategory=orthopedic'])[1]")
	private WebElement DogBedOrthopedicMenu;

	// Webelements for DogBed products dropdown links
	public WebElement dogBedMenu() {
		return DogBedMenu;
	}

	public WebElement dogBedOriginalMenu() {
		return DogBedOriginalMenu;
	}

	public WebElement dogBedOrthopedicMenu() {
		return DogBedOrthopedicMenu;
	}

	// Xpath for Bundle products dropdown links
	@FindBy(xpath = "//div[text()='Bundles']")
	private WebElement BundleMenu;

	@FindBy(xpath = "(//a[@href='/bundle/everyday-bundle/'])[2]")
	private WebElement EverydayBundleMenu;

	@FindBy(xpath = "(//a[@href='/bundle/luxury-bundle/'])[2]")
	private WebElement LuxuryBundleMenu;

	@FindBy(xpath = "(//a[@href='/bundle/accessories-bundle/'])[3]")
	private WebElement AccessoriesBundleMenu;

	@FindBy(xpath = "(//a[@href='/bundle/bachelor-bundle/'])[2]")
	private WebElement BachelorBundleMenu;

	@FindBy(xpath = "(//a[@href='/bundle/baby-starter-pack/'])[2]")
	private WebElement BabyStarterPackBundleMenu;

	// Webelements for Bundle products dropdown links
	public WebElement bundleMenu() {
		return BundleMenu;
	}

	public WebElement everydayBundleMenu() {
		return EverydayBundleMenu;
	}

	public WebElement luxuryBundleMenu() {
		return LuxuryBundleMenu;
	}

	public WebElement accessoriesBundleMenu() {
		return AccessoriesBundleMenu;
	}

	public WebElement bachelorBundleMenu() {
		return BachelorBundleMenu;
	}

	public WebElement babyStarterPackBundleMenu() {
		return BabyStarterPackBundleMenu;
	}

	// Xpath for Limited Edition products dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[8])")
	private WebElement LimitedEditionMenu;

	@FindBy(xpath = "(//a[@href='/limited-edition/satin-pillowcases/'])[1]")
	private WebElement SatinPillowCaseMenu;

	@FindBy(xpath = "(//a[@href='/limited-edition/sleep-gummies/'])[1]")
	private WebElement SleepGummiesMenu;

	// Webelements for Limited Edition products dropdown links
	public WebElement limitedEditionMenu() {
		return LimitedEditionMenu;
	}

	public WebElement satinPillowCaseMenu() {
		return SatinPillowCaseMenu;
	}

	public WebElement sleepGummiesMenu() {
		return SleepGummiesMenu;
	}

	// Xpath for Help me choose dropdown links
	@FindBy(xpath = "(//div[@id='headerMenuGridBottom']//div[9])")
	private WebElement HelpMeChooseMenu;

	// Webelements for Help me choose dropdown links
	public WebElement helpMeChooseMenu() {
		return HelpMeChooseMenu;
	}

	public void mattHeader() {
		// WebElement scrollmatt =
		// driver.findElement(By.xpath("(//a[text()='Mattress'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(MattressHeader).build().perform();
	}

	public void pillowHeader() {
		// WebElement scrollpillow =
		// driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(PillowMenu).build().perform();

	}

	public void dogBedHeader() {
		// WebElement scrollbedding = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(DogBedMenu).build().perform();

	}

	public void bedHeader() {
		// WebElement scrollbedding = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(BedMenu).build().perform();

	}

	public void beddingHeader() {
		// WebElement scrollbedding =
		// driver.findElement(By.xpath("(//a[text()='Bedding'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(BeddingMenu).build().perform();

	}

	public void babyHeader() {
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(BabyMenu).build().perform();
	}

	public void bundleHeader() {
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(BundleMenu).build().perform();
	}

	public void limitedEditionHeader() {
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(LimitedEditionMenu).build().perform();
	}

	public void helpMeChooseHeader() {
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(HelpMeChooseMenu).build().perform();
	}

	public void moreHeader() {
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(More).build().perform();
	}

	public void originalMattressProduct() {
		WebElement scrollmatt = driver.findElement(By.xpath("(//a[text()='Mattress'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollmatt).build().perform();
		OriginalMattressMenu.click();
	}

	public void hybridLatexMattressProduct() {
		WebElement scrollmatt = driver.findElement(By.xpath("(//a[text()='Mattress'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollmatt).build().perform();
		HybridLatexMattressMenu.click();
	}

	public void ultimaMattressProduct() {
		WebElement scrollmatt = driver.findElement(By.xpath("(//a[text()='Mattress'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollmatt).build().perform();
		UltimaMattressMenu.click();
	}

	public void babyMattressProduct() {
		// WebElement scrollmatt =
		// driver.findElement(By.xpath("(//a[text()='Mattress'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(MattressHeader).click().build().perform();
		// BabyMattressMenu.click();
	}

	public void mattressRecommenderProduct() {
		WebElement scrollmatt = driver.findElement(By.xpath("(//a[text()='Mattress'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollmatt).build().perform();
		MattressRecommenderMenu.click();
	}

	public void protectorProducts() {
		WebElement scrollbedding = driver.findElement(By.xpath("(//a[text()='Bedding'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbedding).build().perform();
		ProtectorMenu.click();
	}

	public void comforterProduct() {
		WebElement scrollbedding = driver.findElement(By.xpath("(//a[text()='Bedding'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbedding).build().perform();
		ComforterMenu.click();

	}

	public void weightedBlanketProduct() {
		WebElement scrollbedding = driver.findElement(By.xpath("(//a[text()='Bedding'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbedding).build().perform();
		WeightedBlanketMenu.click();

	}

	public void knittedThrowProduct() {
		WebElement scrollbedding = driver.findElement(By.xpath("(//a[text()='Bedding'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbedding).build().perform();
		KnittedThrowMenu.click();

	}

	public void luxeComforterProduct() {
		WebElement scrollbedding = driver.findElement(By.xpath("(//a[text()='Bedding'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbedding).build().perform();
		LuxeComforterMenu.click();

	}

	public void cloudPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(LuxuryPillowMenu).build().perform();
		CloudPillowMenu.click();

	}

	public void CoolTecMemoryFoamPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(CoolTecPillowMenu).build().perform();
		CoolTecMemoryFoamMenu.click();
	}

	public void SoftTouchMemoryFoamPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(SupportivePillowMenu).build().perform();
		SoftTouchMemoryFoamMenu.click();
	}

	public void contourCoolTecPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(CoolTecPillowMenu).build().perform();
		ContourCoolTecMemoryFoamPillowMenu.click();

	}

	public void contourSoftTouchPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(SupportivePillowMenu).build().perform();
		ContourSoftTouchMemoryFoamPillowMenu.click();

	}

	public void cuddlePillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(SupportivePillowMenu).build().perform();
		CuddlePillowMenu.click();

	}

	public void napPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(OnTheMovePillowMenu).build().perform();
		NapPillowMenu.click();

	}

	public void adjustablePillowProduct() {
		// WebElement scrollpillow =
		// driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(PillowMenu).click().build().perform();
		// hovermenu.moveToElement(SupportivePillowMenu).build().perform();
		// AdjustablePillowMenu.click();

	}

	public void slimPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(SupportivePillowMenu).build().perform();
		SlimPillowMenu.click();
	}

	public void hybridPillowProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		hovermenu.moveToElement(LuxuryPillowMenu).build().perform();
		HybridPillowMenu.click();
	}

	public void pillowCaseProduct() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		PillowCaseMenu.click();
	}

	public void pillowRecommender() {
		WebElement scrollpillow = driver.findElement(By.xpath("(//a[text()='Pillows'])[1]"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollpillow).build().perform();
		PillowRecommenderMenu.click();

	}

	public void ohayoBedProduct() {
		WebElement scrollbed = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbed).build().perform();
		OhayoBedMenu.click();
	}

	public void metalBedFrameProduct() {
		WebElement scrollbedding = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbedding).build().perform();
		MetalBedFrameMenu.click();
	}

	public void ohayoDayBedProduct() {
		WebElement scrollbed = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbed).build().perform();
		OhayoDayBedMenu.click();
	}

	public void ohayoBedTrayProduct() {
		WebElement scrollbed = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbed).build().perform();
		OhayoBedTrayMenu.click();
	}

	public void petBedProduct() {
		WebElement scrollbed = driver.findElement(By.xpath("//a[text()='Bed']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollbed).build().perform();
		PetBedMenu.click();

	}

	public void pillowMenulinkOnHeader() {
		WebElement scrollToPillowMenu = driver.findElement(By.xpath("//a[text()='Pillows']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToPillowMenu).build().perform();
		scrollToPillowMenu.click();
	}

	public void compareMenuLinkOnHeader() {
		WebElement scrollmatt = driver.findElement(By.xpath("//a[text()='Mattress']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollmatt).build().perform();
		CompareMattressMenu.click();
	}

	public void babyHeadpillowMenulinkOnHeader() {
		WebElement scrollToBabyMenu = driver.findElement(By.xpath("//a[text()='Baby Range']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBabyMenu).build().perform();
		BabyHeadPillowMenu.click();
	}

	public void babyBolsterpillowMenulinkOnHeader() {
		WebElement scrollToBabyMenu = driver.findElement(By.xpath("//a[text()='Baby Range']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBabyMenu).build().perform();
		BabyBolsterPillowMenu.click();
	}

	public void babyComforterMenulinkOnHeader() {
		WebElement scrollToBabyMenu = driver.findElement(By.xpath("//a[text()='Baby Range']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBabyMenu).build().perform();
		BabyComforterMenu.click();
	}

	public void babyCribSheetMenulinkOnHeader() {
		WebElement scrollToBabyMenu = driver.findElement(By.xpath("//a[text()='Baby Range']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBabyMenu).build().perform();
		BabyCribSheetMenu.click();
	}

	public void everyDayBundleMenulinkOnHeader() {
		WebElement scrollToBundleMenu = driver.findElement(By.xpath("//a[text()='Bundles']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBundleMenu).build().perform();
		EverydayBundleMenu.click();
	}

	public void luxuryBundleMenulinkOnHeader() {
		WebElement scrollToBundleMenu = driver.findElement(By.xpath("//a[text()='Bundles']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBundleMenu).build().perform();
		LuxuryBundleMenu.click();
	}

	public void accessoriesBundleMenulinkOnHeader() {
		WebElement scrollToBundleMenu = driver.findElement(By.xpath("//a[text()='Bundles']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBundleMenu).build().perform();
		AccessoriesBundleMenu.click();
	}

	public void campusBundleMenulinkOnHeader() {
		WebElement scrollToBundleMenu = driver.findElement(By.xpath("//a[text()='Bundles']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBundleMenu).build().perform();
		BachelorBundleMenu.click();
	}

	public void babyStarterPackBundleMenulinkOnHeader() {
		WebElement scrollToBundleMenu = driver.findElement(By.xpath("//a[text()='Bundles']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToBundleMenu).build().perform();
		BabyStarterPackBundleMenu.click();
	}

	public void reviewMenulinkOnHeader() {
		WebElement scrollToMoreMenu = driver.findElement(By.xpath("//a[text()='More']"));
		Actions hovermenu = new Actions(driver);
		hovermenu.moveToElement(scrollToMoreMenu).build().perform();
		Review.click();
	}

}
