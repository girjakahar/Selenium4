package Utility;

import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;


public class LinkVerification {
	
	static RemoteWebDriver driver;
	
	public static Logger log =LogManager.getLogger(LinkVerification.class);
	
	public LinkVerification(RemoteWebDriver driver) throws Exception
    {
      this.driver = driver; 
      PageFactory.initElements(driver, this);
    }

	
	public static void verifyLinkActive(String linkUrl)
	{
        try 
        {
           URL url = new URL(linkUrl);//creating object of url which is coming from the website
           
           HttpURLConnection httpURLConnect=(HttpURLConnection)url.openConnection();//First creating the connection using url and then it will retrun the HttpURLConnection object
           
           httpURLConnect.setConnectTimeout(3000);
           
           httpURLConnect.connect();
           
           if(httpURLConnect.getResponseCode()==200)
           {
               log.info(linkUrl+" - "+httpURLConnect.getResponseMessage());
               log.info("link is working properly");
     
            }else if(httpURLConnect.getResponseCode()==HttpURLConnection.HTTP_NOT_FOUND)  
             {
               log.info(linkUrl+" - "+httpURLConnect.getResponseMessage() + " - "+ HttpURLConnection.HTTP_NOT_FOUND);
               log.error("link is not working properly");
             }else
             {
                 log.error(linkUrl+" - "+httpURLConnect.getResponseMessage());
             }
        } catch (Exception e) {
        	
        	log.error("link is broken  " +e);
        }
        
	}
}	
	

