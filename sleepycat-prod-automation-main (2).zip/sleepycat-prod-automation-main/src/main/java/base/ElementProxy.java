package base;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import jdk.internal.org.jline.utils.Log;

public class ElementProxy implements InvocationHandler {
	
	static WebDriver driver;
    private final WebElement element;
	public static Logger log =LogManager.getLogger(ElementProxy.class);

    public ElementProxy(WebElement element) {
        this.element = element;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        //before invoking actual method check for the popup
        this.closeOfferModal();
        //at this point, popup would have been closed if it had appeared. element action can be called safely now.
        Object result = method.invoke(element, args);
        return result;
    }
    
    WebElement OfferModalCrossIcon = driver.findElement(By.xpath("//*[@class='soundest-form-without-image-close ']"));

    public void closeOfferModal() throws Exception {
		try {                                                       // get upto 30% modal
			OfferModalCrossIcon.click();
			log.info("Clicked on First modal cross icon");
             
		} catch (Exception e) 
		{
			log.error("Model 1 error :" + e);
		}
		try {                                                       // liked what you saw
			OfferModalCrossIcon.click();
			log.info("Clicked on Second modal cross icon");
			
		} catch (Exception e)
		{
			log.error("Model 2 error :" + e);
		}

	}
    
}
